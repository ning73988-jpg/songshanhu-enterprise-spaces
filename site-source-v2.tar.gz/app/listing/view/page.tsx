"use client";

import { useEffect, useState } from "react";
import { Building2, ChevronLeft, MapPin } from "lucide-react";
import { getPublished, LiveListing } from "@/lib/backend";
import { sitePath } from "@/lib/site-path";

export default function LiveDetail() {
  const [item, setItem] = useState<LiveListing | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("id");
    if (!id) { setLoading(false); return; }
    getPublished(id).then(setItem).catch(() => {}).finally(() => setLoading(false));
  }, []);
  const show = (value: string | number | null) => value === null || value === "" ? "待补充" : value;
  return <div className="site-shell"><header className="site-header"><a className="brand" href={sitePath("/")}><span className="brand-mark"><Building2 size={23}/></span><span><strong>松山湖产业招商</strong><small>园区与产业空间</small></span></a><span className="preview-pill">实拍房源</span></header><main className="detail-main"><a href={sitePath("/")} className="back-link"><ChevronLeft size={18}/>返回房源列表</a>{loading ? <p>正在加载房源…</p> : !item ? <p>这条房源暂未发布或已经下架。</p> : <div className="detail-layout"><div><div className="detail-image"><img src={item.images[0]} alt={`${item.title}实拍照片`}/></div>{item.images.length > 1 && <div className="detail-gallery">{item.images.slice(1).map((src,i)=><img key={src} src={src} alt={`${item.title}实拍照片 ${i+2}`}/>)}</div>}{item.videos.length > 0 && <div className="detail-videos">{item.videos.map(src=><video key={src} src={src} controls playsInline/>)}</div>}<section className="detail-section"><h2>房源信息</h2><div className="facts"><div><span>业态</span><strong>{item.category}</strong></div><div><span>所在园区</span><strong>{show(item.park)}</strong></div><div><span>楼栋 / 房号</span><strong>{show(item.unit)}</strong></div><div><span>楼层</span><strong>{show(item.floor)}</strong></div><div><span>面积</span><strong>{item.area === null ? "待补充" : `${item.area}㎡`}</strong></div><div><span>装修</span><strong>{show(item.decoration)}</strong></div><div><span>朝向</span><strong>{show(item.facing)}</strong></div><div><span>格局</span><strong>{show(item.layout)}</strong></div></div>{item.description && <p className="detail-description">{item.description}</p>}</section></div><aside className="detail-summary"><span className="eyebrow">实拍房源 · {item.category}</span><h1>{item.title}</h1><p className="park-name"><MapPin size={16}/>{item.park || "园区待补充"}</p><div className="detail-price">{item.price === null ? <strong className="price-pending">租金待补充</strong> : <><strong>¥{item.price}</strong><span> /㎡·月</span></>}</div><p>{item.fee === null ? "物业费待补充" : `物业费 ¥${item.fee}/㎡·月`}</p><div className="detail-alert">房源资料由管理员发布，具体在租状态与价格请以实际沟通为准。</div></aside></div>}</main><footer>松山湖产业招商</footer></div>;
}
