import { notFound } from "next/navigation";
import { Building2, ChevronLeft, MapPin } from "lucide-react";
import data from "@/data/listings.json";
import { sitePath } from "@/lib/site-path";

export function generateStaticParams() {
  return data.map(item => ({ id: item.id }));
}

export default async function ListingDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = data.find(x => x.id === id);
  if (!item) notFound();
  const real = item.source === "用户提供实拍";
  const title = item.park ? `${item.park} · ${item.unit}` : item.unit;
  const display = (value: string | number | null) => value === null || value === "" || value === "-" ? "待补充" : value;

  return <div className="site-shell">
    <header className="site-header"><a className="brand" href={sitePath("/")}><span className="brand-mark"><Building2 size={23}/></span><span><strong>松山湖产业招商</strong><small>园区与产业空间</small></span></a><span className="preview-pill">网站评审版</span></header>
    <main className="detail-main">
      <a href={sitePath("/")} className="back-link"><ChevronLeft size={18}/>返回房源列表</a>
      <div className="detail-layout">
        <div>
          <div className="detail-image"><img src={sitePath(item.image)} alt={real ? `${title}实拍照片` : `${title}示意图`}/></div>
          <div className="detail-note">{real ? "用户提供的房源实拍照片。园区、面积、租金等资料尚待补充。" : "此图为项目原有占位素材，并非该房源实拍。"}</div>
          <section className="detail-section"><h2>房源信息</h2><div className="facts">
            <div><span>业态</span><strong>{display(item.category)}</strong></div>
            <div><span>所在园区</span><strong>{display(item.park)}</strong></div>
            <div><span>房号</span><strong>{real ? "待补充" : display(item.unit)}</strong></div>
            <div><span>楼层</span><strong>{display(item.floor)}</strong></div>
            <div><span>面积</span><strong>{item.area === null ? "待补充" : `${item.area.toLocaleString("zh-CN")}㎡`}</strong></div>
            <div><span>装修</span><strong>{display(item.decoration)}</strong></div>
            <div><span>朝向</span><strong>{display(item.facing)}</strong></div>
            <div><span>格局</span><strong>{display(item.layout)}</strong></div>
          </div></section>
        </div>
        <aside className="detail-summary"><span className="eyebrow">{real ? "实拍房源" : "演示房源"} · {item.category}</span><h1>{title}</h1><p className="park-name"><MapPin size={16}/>{item.park || "园区待补充"}</p><div className="detail-price">{item.price === null ? <strong className="price-pending">租金待补充</strong> : <><strong>¥{item.price}</strong><span> /㎡·月</span></>}</div><p>{item.fee === null ? "物业费待补充" : `物业费 ¥${item.fee}/㎡·月`}</p><div className="detail-alert">{real ? "照片来自用户。其余房源信息仍待补充和核实，详情请以实际沟通为准。" : `该条信息来自 ${item.source}，尚未核实真实在租状态与价格。`}</div></aside>
      </div>
    </main>
    <footer>松山湖产业招商 · 网站评审版</footer>
  </div>;
}
