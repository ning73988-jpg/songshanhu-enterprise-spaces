"use client";

import { useEffect, useState } from "react";
import { ArrowLeft, ImagePlus, LogOut, Plus, Save, Trash2, Upload } from "lucide-react";
import { accessToken, backendReady, deleteListing, isAdmin, LiveListing, loadAll, readSession, saveListing, signIn, signOut, uploadMedia } from "@/lib/backend";
import { sitePath } from "@/lib/site-path";

const blank = (): LiveListing => ({ id: crypto.randomUUID(), title: "", category: "写字楼", park: null, unit: null, floor: null, area: null, price: null, fee: null, facing: null, layout: null, decoration: null, description: null, images: [], videos: [], status: "draft" });
const textFields: { key: keyof LiveListing; label: string; placeholder?: string }[] = [
  { key: "park", label: "园区名称" }, { key: "unit", label: "楼栋 / 房号" }, { key: "floor", label: "楼层" },
  { key: "facing", label: "朝向" }, { key: "layout", label: "格局" }, { key: "decoration", label: "装修" },
];
const numberFields: { key: "area" | "price" | "fee"; label: string; suffix: string }[] = [
  { key: "area", label: "面积", suffix: "㎡" }, { key: "price", label: "租金", suffix: "元/㎡·月" }, { key: "fee", label: "物业费", suffix: "元/㎡·月" },
];

export default function AdminPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [checking, setChecking] = useState(true);
  const [items, setItems] = useState<LiveListing[]>([]);
  const [editing, setEditing] = useState<LiveListing | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!backendReady || !readSession()) { setChecking(false); return; }
    isAdmin().then(async ok => {
      if (ok) { setAuthorized(true); setItems(await loadAll()); }
      else signOut();
    }).catch(e => setError(e instanceof Error ? e.message : "连接失败")).finally(() => setChecking(false));
  }, []);

  async function login(event: React.FormEvent) {
    event.preventDefault(); setError(""); setChecking(true);
    try {
      await signIn(email, password);
      if (!await isAdmin()) { signOut(); throw new Error("此账号没有管理权限"); }
      setAuthorized(true); setItems(await loadAll()); setPassword("");
    } catch (e) { setError(e instanceof Error ? e.message : "登录失败"); }
    finally { setChecking(false); }
  }
  function change<K extends keyof LiveListing>(key: K, value: LiveListing[K]) { setEditing(current => current ? { ...current, [key]: value } : null); }
  async function addFiles(files: FileList | null) {
    if (!files || !editing) return;
    setSaving(true); setError(""); setMessage("上传中…");
    try {
      const images = [...editing.images], videos = [...editing.videos];
      for (const file of Array.from(files)) {
        if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) throw new Error(`不支持的文件类型：${file.name}`);
        const url = await uploadMedia(file);
        if (file.type.startsWith("image/")) images.push(url); else videos.push(url);
      }
      setEditing({ ...editing, images, videos }); setMessage("文件已上传，请点击“保存房源”完成发布。上传的文件已占用云存储空间。");
    } catch (e) { setError(e instanceof Error ? e.message : "上传失败"); setMessage(""); }
    finally { setSaving(false); }
  }
  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (!editing) return;
    if (!editing.title.trim()) { setError("请填写房源标题"); return; }
    if (editing.status === "published" && editing.images.length === 0) { setError("发布前请至少上传一张照片"); return; }
    setSaving(true); setError(""); setMessage("");
    try {
      await saveListing(editing);
      setItems(await loadAll()); setEditing(null); setMessage(editing.status === "published" ? "房源已发布，展示页刷新后可见。" : "草稿已保存。");
    } catch (e) { setError(e instanceof Error ? e.message : "保存失败"); }
    finally { setSaving(false); }
  }
  async function remove(item: LiveListing) {
    if (!window.confirm(`确定删除“${item.title}”吗？页面记录会删除；已上传的文件仍需在存储后台清理。`)) return;
    setSaving(true); setError("");
    try { await deleteListing(item.id); setItems(await loadAll()); setEditing(null); setMessage("房源已删除。"); }
    catch (e) { setError(e instanceof Error ? e.message : "删除失败"); }
    finally { setSaving(false); }
  }
  function logout() { signOut(); setAuthorized(false); setItems([]); setEditing(null); setMessage(""); }

  return <div className="admin-shell">
    <header className="admin-header"><a href={sitePath("/")}><ArrowLeft size={18}/>返回网站</a><strong>松山湖产业招商 · 房源管理</strong>{authorized && <button onClick={logout}><LogOut size={17}/>退出</button>}</header>
    {!backendReady ? <main className="admin-center"><div className="admin-panel"><h1>管理后台待开通</h1><p>房源展示页已经可以显示实拍照片。网页内上传和跨设备管理需要先连接数据库与文件存储服务；当前网站尚未配置该服务。</p><p>开通后，此处可以登录并上传照片、视频，填写房源资料，保存草稿或发布。</p></div></main> : checking ? <main className="admin-center"><div className="admin-panel"><p>正在连接管理后台…</p></div></main> : !authorized ? <main className="admin-center"><form className="admin-panel" onSubmit={login}><h1>管理员登录</h1><p>使用已授权的管理账号登录。</p><label>邮箱<input type="email" required autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>密码<input type="password" required autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="admin-primary" type="submit">登录</button>{error && <p className="admin-error" role="alert">{error}</p>}</form></main> : <main className="admin-main">
      <div className="admin-title"><div><span>房源管理</span><h1>我的房源</h1><p>上传实拍照片与视频，补全资料后发布到展示页。</p></div><button className="admin-primary" onClick={()=>{setEditing(blank());setMessage("");setError("");}}><Plus size={18}/>新增房源</button></div>
      {message && <div className="admin-message" role="status">{message}</div>}{error && <div className="admin-error" role="alert">{error}</div>}
      {editing ? <form className="admin-editor" onSubmit={save}><div className="admin-editor-heading"><h2>{items.some(x=>x.id===editing.id) ? "编辑房源" : "新增房源"}</h2><button type="button" onClick={()=>setEditing(null)}>返回列表</button></div><div className="admin-form-grid"><label className="admin-wide">房源标题 *<input required value={editing.title} onChange={e=>change("title",e.target.value)} placeholder="例如：光大We谷 A区 804"/></label><label>业态<select value={editing.category} onChange={e=>change("category",e.target.value)}>{["写字楼","厂房","研发办公","仓储"].map(x=><option key={x}>{x}</option>)}</select></label>{textFields.map(f=><label key={f.key}>{f.label}<input value={String(editing[f.key] ?? "")} onChange={e=>change(f.key,e.target.value || null)} placeholder={f.placeholder || "可稍后填写"}/></label>)}{numberFields.map(f=><label key={f.key}>{f.label}（{f.suffix}）<input type="number" min="0" step="0.01" value={editing[f.key] ?? ""} onChange={e=>change(f.key,e.target.value===""?null:Number(e.target.value))} placeholder="可稍后填写"/></label>)}<label className="admin-wide">房源说明<textarea rows={4} value={editing.description ?? ""} onChange={e=>change("description",e.target.value || null)} placeholder="交通、配套、看房说明等"/></label></div>
      <div className="admin-upload"><h3><ImagePlus size={20}/>照片与视频</h3><p>第一张照片会作为列表封面。可一次选择多个文件；视频大小受云存储套餐限制。</p><label className="admin-upload-button"><Upload size={18}/>选择照片或视频<input type="file" accept="image/*,video/*" multiple onChange={e=>{void addFiles(e.target.files);e.target.value="";}} disabled={saving}/></label><div className="admin-media-grid">{editing.images.map((url,i)=><div className="admin-media" key={url}><img src={url} alt={`房源照片 ${i+1}`}/><button type="button" onClick={()=>change("images",editing.images.filter((_,index)=>index!==i))}>从房源移除</button></div>)}{editing.videos.map((url,i)=><div className="admin-media" key={url}><video src={url} controls/><button type="button" onClick={()=>change("videos",editing.videos.filter((_,index)=>index!==i))}>从房源移除</button></div>)}</div></div>
      <div className="admin-actions"><label>状态<select value={editing.status} onChange={e=>change("status",e.target.value as LiveListing["status"])}><option value="draft">草稿（不展示）</option><option value="published">发布（公开展示）</option></select></label><button className="admin-primary" type="submit" disabled={saving}><Save size={18}/>{saving?"处理中…":"保存房源"}</button>{items.some(x=>x.id===editing.id) && <button className="admin-danger" type="button" onClick={()=>void remove(editing)} disabled={saving}><Trash2 size={17}/>删除</button>}</div></form> : <div className="admin-list">{items.length===0 ? <div className="admin-empty">还没有后台房源。点击“新增房源”开始上传。</div> : items.map(item=><button className="admin-list-item" key={item.id} onClick={()=>{setEditing(item);setMessage("");setError("");}}>{item.images[0] ? <img src={item.images[0]} alt=""/> : <span className="admin-no-image">暂无照片</span>}<span className="admin-list-text"><strong>{item.title}</strong><small>{item.park || "园区待补充"} · {item.area === null ? "面积待补充" : `${item.area}㎡`}</small></span><span className={item.status==="published"?"admin-published":"admin-draft"}>{item.status==="published"?"已发布":"草稿"}</span></button>)}</div>}
    </main>}
  </div>;
}
