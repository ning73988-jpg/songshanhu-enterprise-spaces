export type LiveListing = {
  id: string;
  title: string;
  category: string;
  park: string | null;
  unit: string | null;
  floor: string | null;
  area: number | null;
  price: number | null;
  fee: number | null;
  facing: string | null;
  layout: string | null;
  decoration: string | null;
  description: string | null;
  images: string[];
  videos: string[];
  status: "draft" | "published";
  created_at?: string;
};

type Session = { access_token: string; refresh_token: string; expires_at: number; user: { id: string; email?: string } };
const storageKey = "songshanhu_admin_session";
export const backendUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.replace(/\/$/, "") || "";
export const backendKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
export const backendReady = Boolean(backendUrl && backendKey);

export function readSession(): Session | null {
  if (typeof window === "undefined") return null;
  try { return JSON.parse(window.localStorage.getItem(storageKey) || "null"); } catch { return null; }
}
function saveSession(value: Session | null) {
  if (typeof window === "undefined") return;
  if (value) window.localStorage.setItem(storageKey, JSON.stringify(value));
  else window.localStorage.removeItem(storageKey);
}
async function parseResponse(response: Response) {
  const result = await response.json().catch(() => null);
  if (!response.ok) throw new Error(result?.message || result?.error_description || result?.error || `请求失败 (${response.status})`);
  return result;
}
export async function signIn(email: string, password: string) {
  const response = await fetch(`${backendUrl}/auth/v1/token?grant_type=password`, {
    method: "POST", headers: { apikey: backendKey, "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const result = await parseResponse(response);
  const session: Session = { access_token: result.access_token, refresh_token: result.refresh_token, expires_at: Date.now() + result.expires_in * 1000, user: result.user };
  saveSession(session);
  return session;
}
export function signOut() { saveSession(null); }
export async function isAdmin(): Promise<boolean> {
  const session = readSession();
  if (!session) return false;
  const token = await accessToken();
  const response = await fetch(`${backendUrl}/rest/v1/admin_users?select=user_id&user_id=eq.${encodeURIComponent(session.user.id)}`, { headers: headers(token), cache: "no-store" });
  const rows = await parseResponse(response);
  return rows.length > 0;
}
export async function accessToken(): Promise<string> {
  const current = readSession();
  if (!current) throw new Error("请先登录管理后台");
  if (current.expires_at > Date.now() + 60_000) return current.access_token;
  const response = await fetch(`${backendUrl}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST", headers: { apikey: backendKey, "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: current.refresh_token }),
  });
  const result = await parseResponse(response);
  const session: Session = { access_token: result.access_token, refresh_token: result.refresh_token, expires_at: Date.now() + result.expires_in * 1000, user: result.user };
  saveSession(session);
  return session.access_token;
}
function headers(token?: string) { return { apikey: backendKey, Authorization: `Bearer ${token || backendKey}` }; }
export async function loadPublished(): Promise<LiveListing[]> {
  if (!backendReady) return [];
  const response = await fetch(`${backendUrl}/rest/v1/listings?select=*&status=eq.published&order=created_at.desc`, { headers: headers(), cache: "no-store" });
  return parseResponse(response);
}
export async function getPublished(id: string): Promise<LiveListing | null> {
  if (!backendReady) return null;
  const response = await fetch(`${backendUrl}/rest/v1/listings?select=*&id=eq.${encodeURIComponent(id)}&status=eq.published&limit=1`, { headers: headers(), cache: "no-store" });
  const rows = await parseResponse(response);
  return rows[0] || null;
}
export async function loadAll(): Promise<LiveListing[]> {
  const token = await accessToken();
  const response = await fetch(`${backendUrl}/rest/v1/listings?select=*&order=created_at.desc`, { headers: headers(token), cache: "no-store" });
  return parseResponse(response);
}
export async function saveListing(listing: LiveListing) {
  const token = await accessToken();
  const response = await fetch(`${backendUrl}/rest/v1/listings?on_conflict=id`, {
    method: "POST", headers: { ...headers(token), "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify(listing),
  });
  return parseResponse(response);
}
export async function deleteListing(id: string) {
  const token = await accessToken();
  const response = await fetch(`${backendUrl}/rest/v1/listings?id=eq.${encodeURIComponent(id)}`, { method: "DELETE", headers: headers(token) });
  if (!response.ok) await parseResponse(response);
}
export async function uploadMedia(file: File) {
  const token = await accessToken();
  const extension = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "bin";
  const path = `${readSession()?.user.id}/${crypto.randomUUID()}.${extension}`;
  const response = await fetch(`${backendUrl}/storage/v1/object/listing-media/${path}`, {
    method: "POST", headers: { ...headers(token), "Content-Type": file.type || "application/octet-stream", "x-upsert": "false" }, body: file,
  });
  await parseResponse(response);
  return `${backendUrl}/storage/v1/object/public/listing-media/${path}`;
}
