-- Run once in the Supabase SQL editor. Then add your own auth user UUID to admin_users.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admin_users enable row level security;
create policy "admins can see their own membership" on public.admin_users
  for select to authenticated using (user_id = auth.uid());

create or replace function public.is_site_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.admin_users where user_id = auth.uid()); $$;
revoke all on function public.is_site_admin() from public;
grant execute on function public.is_site_admin() to authenticated;

create table if not exists public.listings (
  id uuid primary key,
  title text not null,
  category text not null default '写字楼',
  park text,
  unit text,
  floor text,
  area numeric,
  price numeric,
  fee numeric,
  facing text,
  layout text,
  decoration text,
  description text,
  images jsonb not null default '[]'::jsonb,
  videos jsonb not null default '[]'::jsonb,
  status text not null default 'draft' check (status in ('draft','published')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.listings enable row level security;
create policy "visitors can read published listings" on public.listings
  for select to anon, authenticated using (status = 'published' or (auth.role() = 'authenticated' and public.is_site_admin()));
create policy "admins can insert listings" on public.listings
  for insert to authenticated with check (public.is_site_admin());
create policy "admins can update listings" on public.listings
  for update to authenticated using (public.is_site_admin()) with check (public.is_site_admin());
create policy "admins can delete listings" on public.listings
  for delete to authenticated using (public.is_site_admin());
grant select on public.listings to anon, authenticated;
grant insert, update, delete on public.listings to authenticated;
grant select on public.admin_users to authenticated;

insert into storage.buckets (id, name, public)
values ('listing-media', 'listing-media', true)
on conflict (id) do update set public = true;
create policy "visitors can view listing media" on storage.objects
  for select to anon, authenticated using (bucket_id = 'listing-media');
create policy "admins can upload listing media" on storage.objects
  for insert to authenticated with check (bucket_id = 'listing-media' and public.is_site_admin());
create policy "admins can remove listing media" on storage.objects
  for delete to authenticated using (bucket_id = 'listing-media' and public.is_site_admin());
