# 房源管理后台开通

网站继续托管在 GitHub Pages。Supabase 提供登录、房源数据库、照片和视频存储。管理员在 `/admin/` 登录后新增房源并发布；已发布房源由展示页实时读取。

1. 创建 Supabase 项目，在 SQL Editor 运行 `setup.sql`。
2. 在 Authentication → Users 创建自己的管理员账号。复制该用户的 UUID，在 SQL Editor 执行：`insert into public.admin_users (user_id) values ('这里填 UUID');`。
3. 在 GitHub 仓库 Settings → Secrets and variables → Actions 添加 `NEXT_PUBLIC_SUPABASE_URL` 和 `NEXT_PUBLIC_SUPABASE_ANON_KEY`。值来自 Supabase Project Settings → API；只使用公开的 anon/publishable key，不能用 service_role key。
4. 在 GitHub Actions 中重新运行 Pages 工作流，让网页构建时读取这两个值。
5. 打开网站 `/admin/` 登录。不要启用公开注册；只在 Supabase 后台创建管理员用户。

文件存入 Supabase Storage 的 `listing-media` bucket；房源文字及媒体链接存入 `public.listings`。GitHub 仓库只存网页代码和目前这四张初始照片。视频体积较大时需按 Supabase 套餐和上传限制选择合适的方案。
