-- Run once in the Supabase SQL editor. Then add your own auth user UUID to admin_users.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'park_admin' check (role in ('superadmin','park_admin')),
  park text,
  active boolean not null default true,
  check ((role = 'superadmin' and park is null) or (role = 'park_admin' and park is not null))
);
create unique index if not exists one_superadmin on public.admin_users (role) where role = 'superadmin';
alter table public.admin_users enable row level security;

create or replace function public.is_superadmin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.admin_users where user_id = auth.uid() and role = 'superadmin' and active); $$;
revoke all on function public.is_superadmin() from public;
grant execute on function public.is_superadmin() to authenticated;

create or replace function public.is_site_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.admin_users where user_id = auth.uid() and active); $$;
revoke all on function public.is_site_admin() from public;
grant execute on function public.is_site_admin() to authenticated;

create or replace function public.can_manage_park(target_park text)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.admin_users where user_id = auth.uid() and active and (role = 'superadmin' or park = target_park)); $$;
revoke all on function public.can_manage_park(text) from public;
grant execute on function public.can_manage_park(text) to authenticated;

drop policy if exists "admins can see their own membership" on public.admin_users;
create policy "admins can see own or superadmin all" on public.admin_users
  for select to authenticated using (user_id = auth.uid() or public.is_superadmin());
create policy "superadmin manages admin accounts" on public.admin_users
  for all to authenticated using (public.is_superadmin()) with check (public.is_superadmin());

create table if not exists public.listings (
  id uuid primary key,
  title text not null,
  category text not null default '写字楼',
  park text,
  unit text,
  floor text,
  area numeric,
  price numeric,
  fee numeric,
  facing text,
  layout text,
  decoration text,
  description text,
  free_rent_period text,
  supporting_facilities text,
  compatible_industries text,
  factory_height text,
  factory_load text,
  factory_power text,
  fire_rating text,
  environmental_requirements text,
  internal_code text,
  owner_floor_price numeric,
  channel_notes text,
  followup_notes text,
  images jsonb not null default '[]'::jsonb,
  videos jsonb not null default '[]'::jsonb,
  status text not null default 'draft' check (status in ('draft','published')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint publish_requires_complete_public_record check (
    status <> 'published' or (
      park is not null and length(trim(park)) > 0 and
      jsonb_array_length(images) >= 5 and
      position(lower(park) in lower(title)) = 0 and
      position(lower(park) in lower(coalesce(unit, ''))) = 0 and
      position(lower(park) in lower(coalesce(description, ''))) = 0 and
      position(lower(park) in lower(coalesce(supporting_facilities, ''))) = 0
    )
  )
);
alter table public.listings enable row level security;
-- The base table contains private park and owner fields. It is never exposed to visitors.
create policy "admins can read their own parks" on public.listings
  for select to authenticated using (public.can_manage_park(park));
create policy "admins can insert listings" on public.listings
  for insert to authenticated with check (public.can_manage_park(park));
create policy "admins can update listings" on public.listings
  for update to authenticated using (public.can_manage_park(park)) with check (public.can_manage_park(park));
create policy "admins can delete listings" on public.listings
  for delete to authenticated using (public.can_manage_park(park));
revoke all on public.listings from anon;
grant select on public.listings to authenticated;
grant insert, update, delete on public.listings to authenticated;
grant select on public.admin_users to authenticated;

-- Only the following whitelisted columns are ever returned to the public website.
create or replace view public.public_listings with (security_barrier=true) as
select id, title, category, unit, floor, area, price, fee, facing, layout,
       decoration, description, free_rent_period, supporting_facilities,
       compatible_industries, factory_height, factory_load, factory_power,
       fire_rating, environmental_requirements, images, videos, status, created_at
from public.listings where status = 'published';
grant select on public.public_listings to anon, authenticated;

create table if not exists public.inquiries (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  request_text text,
  company text not null,
  contact text not null,
  phone text not null,
  viewing_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.inquiries enable row level security;
create policy "visitors can submit inquiry" on public.inquiries
  for insert to anon, authenticated with check (length(company) between 1 and 80 and length(contact) between 1 and 40 and phone ~ '^1[0-9]{10}$');
create policy "admins can read inquiry for their park" on public.inquiries
  for select to authenticated using (
    public.is_superadmin() or exists (
      select 1 from public.listings l where l.id = listing_id and public.can_manage_park(l.park)
    )
  );
grant insert on public.inquiries to anon, authenticated;
grant select on public.inquiries to authenticated;

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  listing_id uuid,
  actor_id uuid,
  action text not null,
  old_record jsonb,
  new_record jsonb,
  created_at timestamptz not null default now()
);
alter table public.audit_logs enable row level security;
create policy "superadmin reads audit logs" on public.audit_logs
  for select to authenticated using (public.is_superadmin());
grant select on public.audit_logs to authenticated;
create or replace function public.log_listing_change()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.audit_logs(listing_id, actor_id, action, old_record, new_record)
  values (case when tg_op = 'DELETE' then old.id else new.id end, auth.uid(), tg_op,
          case when tg_op = 'INSERT' then null else to_jsonb(old) end,
          case when tg_op = 'DELETE' then null else to_jsonb(new) end);
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;
drop trigger if exists listings_audit on public.listings;
create trigger listings_audit after insert or update or delete on public.listings
  for each row execute function public.log_listing_change();

insert into storage.buckets (id, name, public)
values ('listing-media', 'listing-media', true)
on conflict (id) do update set public = true;
create policy "visitors can view listing media" on storage.objects
  for select to anon, authenticated using (bucket_id = 'listing-media');
create policy "admins can upload listing media" on storage.objects
  for insert to authenticated with check (bucket_id = 'listing-media' and public.is_site_admin());
create policy "admins can remove listing media" on storage.objects
  for delete to authenticated using (bucket_id = 'listing-media' and public.is_superadmin());
