// Public map proxy only: no database access or Supabase admin credential.
// Deploy this function with JWT verification disabled; JS API does not send a Supabase JWT.
const publicKey = 'de9fc97ee0239254bd8384f02b06dfa4';
const allowedOrigin = 'https://ning73988-jpg.github.io';

Deno.serve(async (request: Request) => {
  const cors = {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'content-type',
    'Vary': 'Origin',
    'X-Content-Type-Options': 'nosniff',
  };
  const reply = (message: string, status: number) => new Response(message, {
    status, headers: { ...cors, 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
  });
  let source = request.headers.get('origin');
  if (!source) {
    try { source = new URL(request.headers.get('referer') || '').origin; } catch { source = null; }
  }
  if (source !== allowedOrigin) return reply('Map request origin is not allowed.', 403);
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (request.method !== 'GET') return reply('Method not allowed.', 405);
  // Accept the existing dashboard entry, whose name was entered as the public Key.
  const secret = Deno.env.get('AMAP_SECURITY_JSCODE') || Deno.env.get(publicKey);
  if (!secret) return reply('Map proxy is not configured.', 503);

  const incoming = new URL(request.url);
  const prefix = '/amap-proxy/_AMapService/';
  const start = incoming.pathname.indexOf(prefix);
  if (start < 0) return reply('Unknown map route.', 404);
  const path = incoming.pathname.slice(start + prefix.length);
  if (!/^v[1-5]\/[a-zA-Z0-9/_-]+$/.test(path) || path.includes('..')) return reply('Unknown map route.', 404);
  // Keep the proxy bound to our own JS Key and fixed official upstream hosts.
  if (incoming.searchParams.get('key') !== publicKey) return reply('Map Key is not allowed.', 403);
  const host = path === 'v4/map/styles' ? 'webapi.amap.com' : 'restapi.amap.com';
  const target = new URL('https://' + host + '/' + path);
  target.search = incoming.search;
  target.searchParams.set('key', publicKey);
  target.searchParams.set('jscode', secret);
  try {
    const upstream = await fetch(target, { redirect: 'error', signal: AbortSignal.timeout(15000) });
    return new Response(upstream.body, {
      status: upstream.status,
      headers: {
        ...cors,
        'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
      },
    });
  } catch {
    // Never log the upstream URL: it contains the security code.
    return reply('Map upstream is temporarily unavailable.', 502);
  }
});
