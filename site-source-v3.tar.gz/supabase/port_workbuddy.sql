-- Apply once in the existing Supabase project's SQL Editor.
-- Keeps every existing listing and inquiry. Adds the public fields used by the
-- WorkBuddy-style website. Run this only after confirming that park/location/
-- contact information should be public.

alter table public.listings add column if not exists address text;
alter table public.listings add column if not exists latitude numeric;
alter table public.listings add column if not exists longitude numeric;
alter table public.listings add column if not exists contact_name text;
alter table public.listings add column if not exists contact_phone text;
alter table public.listings add column if not exists tag text;
alter table public.listings add column if not exists views integer not null default 0;

alter table public.listings drop constraint if exists publish_requires_complete_public_record;
alter table public.listings add constraint publish_requires_public_record check (
  status <> 'published' or (
    park is not null and length(trim(park)) > 0 and
    jsonb_array_length(images) >= 1
  )
);

-- PostgreSQL permits appending columns to an existing view without dropping it.
create or replace view public.public_listings with (security_barrier=true) as
select id, title, category, unit, floor, area, price, fee, facing, layout,
       decoration, description, free_rent_period, supporting_facilities,
       compatible_industries, factory_height, factory_load, factory_power,
       fire_rating, environmental_requirements, images, videos, status, created_at,
       park, address, latitude, longitude, contact_name, contact_phone, tag, views
from public.listings where status = 'published';
grant select on public.public_listings to anon, authenticated;
