# 网站数据后台开通

当前网页托管在 GitHub Pages，房源与留言使用已有 Supabase 项目。网站首页采用 WorkBuddy 版本的布局与主要访客交互；上传和发布仍通过本站的安全管理后台完成。

## 已有项目升级

在现有 Supabase 项目的 SQL Editor 执行 [port_workbuddy.sql](port_workbuddy.sql)，保留原有房源与留言。它会增加公开园区、位置和联系方式字段，并把发布条件改为至少 1 张房源照片与园区名称。随后等待 GitHub Pages 重新发布，进入 `/admin/` 编辑房源。

## 开通步骤

1. 由网站所有者创建 Supabase 项目。进入 SQL Editor，执行 [setup.sql](setup.sql)。该脚本按全新项目编写，请不要直接覆盖已有生产数据库。
2. 在 Authentication → Users 创建第一个管理员邮箱账号。复制该用户 UUID，在 SQL Editor 执行：

   ```sql
   insert into public.admin_users (user_id, role, park, active)
   values ('这里填管理员 UUID', 'superadmin', null, true);
   ```

3. 在 GitHub 仓库 Settings → Secrets and variables → Actions 增加 `NEXT_PUBLIC_SUPABASE_URL` 与 `NEXT_PUBLIC_SUPABASE_ANON_KEY`。只使用项目的公开 anon/publishable key，绝不把 service_role key 放进网页或 GitHub 构建变量。
4. 重新运行 Pages 工作流。访问网站 `/admin/` 登录，新增房源并上传至少 1 张实拍照片；资料不足时先保存为草稿。
5. 发布前核对园区名称、详细地址与联系电话，这些字段会公开展示。底价、内部编号、渠道和跟进备注仍只在后台可见。

## 当前边界

- 管理员权限：唯一超管可管理所有园区；园区管理员在数据库行级权限下只可管理其被指定的园区。管理员账号分配目前由超管在 SQL Editor 完成，网页人员管理界面尚未接入。
- 线上预约：访客可提交需求，管理员可在网站后台的“咨询与预约”查看。运营前仍需配置反垃圾保护和隐私告知。
- 会员手机号验证、精准地图、企业供需审核与产业 AI 匹配尚未接通，不向访客展示私密内容。不能用前端隐藏代替后端授权。
- 网站与微信小程序可以共用后端业务数据，但小程序接入与正式公开发布还需单独完成主体类目、备案和平台审核。
