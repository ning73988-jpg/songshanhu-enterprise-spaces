"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, Building2, Factory, Image as ImageIcon, Search, Sparkles, SlidersHorizontal } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { InquiryDialog } from "@/components/InquiryDialog";
import { MobileNavigation, SiteHeader } from "@/components/SiteNavigation";
import { backendReady, loadPublished, PublicListing } from "@/lib/backend";
import { sitePath } from "@/lib/site-path";
import seed from "@/data/listings.json";

type Sample = { id: string; image: string; source: string };
const samples = (seed as Sample[]).filter(item => item.source === "用户提供实拍");
const categories = ["全部", "写字楼", "厂房", "研发办公", "仓储"];
type SearchRule = { category: string; minArea: number | null; maxArea: number | null; maxPrice: number | null; decoration: string };
const emptyRule: SearchRule = { category: "全部", minArea: null, maxArea: null, maxPrice: null, decoration: "" };

function readRule(text: string): SearchRule {
  const category = categories.find(item => item !== "全部" && text.includes(item)) || "全部";
  const range = text.match(/(\d+)\s*(?:-|~|到|至)\s*(\d+)\s*(?:㎡|平)/);
  const min = text.match(/(\d+)\s*(?:㎡|平)\s*(?:以上|起)/);
  const max = text.match(/(\d+)\s*(?:㎡|平)\s*(?:以内|以下)/);
  const price = text.match(/(\d+)\s*元/);
  const decoration = ["带家具精装", "精装修", "精装", "简装", "毛坯"].find(item => text.includes(item)) || "";
  return { category, minArea: range ? Number(range[1]) : min ? Number(min[1]) : null, maxArea: range ? Number(range[2]) : max ? Number(max[1]) : null, maxPrice: price ? Number(price[1]) : null, decoration };
}

export default function Home() {
  const [listings, setListings] = useState<PublicListing[]>([]);
  const [loading, setLoading] = useState(true);
  const [rule, setRule] = useState<SearchRule>(emptyRule);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("默认排序");
  const [smartOpen, setSmartOpen] = useState(false);
  const [smartText, setSmartText] = useState("");
  const [requestText, setRequestText] = useState("");
  const [inquiryOpen, setInquiryOpen] = useState(false);

  useEffect(() => { if (!backendReady) { setLoading(false); return; } loadPublished().then(setListings).catch(() => setListings([])).finally(() => setLoading(false)); }, []);
  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    const result = listings.filter(item =>
      (rule.category === "全部" || item.category === rule.category) &&
      (rule.minArea === null || (item.area !== null && item.area >= rule.minArea)) &&
      (rule.maxArea === null || (item.area !== null && item.area <= rule.maxArea)) &&
      (rule.maxPrice === null || (item.price !== null && item.price <= rule.maxPrice)) &&
      (!rule.decoration || (item.decoration || "").includes(rule.decoration)) &&
      (!q || [item.title, item.category, item.floor, item.layout, item.decoration, item.description].join(" ").toLowerCase().includes(q))
    );
    if (sort === "租金从低到高") result.sort((a,b) => (a.price ?? Infinity) - (b.price ?? Infinity));
    if (sort === "面积从大到小") result.sort((a,b) => (b.area ?? -1) - (a.area ?? -1));
    return result;
  }, [listings, query, rule, sort]);

  function applySmart() {
    const text = smartText.trim();
    if (!text) return;
    setRule(readRule(text)); setQuery(""); setRequestText(text); setSmartOpen(false);
    document.getElementById("listings")?.scrollIntoView({ behavior: "smooth" });
  }
  function quickSearch(value: string) {
    setQuery(""); setRule(readRule(value)); setRequestText(value);
    document.getElementById("listings")?.scrollIntoView({ behavior: "smooth" });
  }

  return <div className="site-shell">
    <div className="blue-stage"><SiteHeader/><section className="home-hero">
      <div className="hero-topline">写字楼 · 厂房 · 产业资源</div>
      <h1>找到适合企业的<br/>下一处空间</h1>
      <p className="hero-lead">浏览松山湖周边产业空间，按面积、租金和业态寻找合适的房源。</p>
      <div className="hero-entries">
        <button className="hero-entry" onClick={()=>quickSearch("写字楼")}><Building2 size={26}/><strong>写字楼</strong><span>办公与研发空间</span></button>
        <button className="hero-entry" onClick={()=>quickSearch("厂房")}><Factory size={26}/><strong>厂房</strong><span>生产与配套空间</span></button>
        <a className="hero-entry" href={sitePath("/industry")}><Sparkles size={26}/><strong>产业资源</strong><span>企业供需与合作</span></a>
      </div>
      <div className="hero-stats"><div><strong>{listings.length}</strong><span>已发布房源</span></div><div><strong>{samples.length}</strong><span>组实拍资料</span></div><div><strong>2</strong><span>核心业态</span></div></div>
    </section></div>
    <main>
      <section className="searchbar" aria-label="搜索房源"><div className="search-row"><label className="search-input"><Search size={20}/><input aria-label="搜索房源" placeholder="搜索楼层、格局或装修" value={query} onChange={e=>setQuery(e.target.value)}/></label><button className="ai-btn" onClick={()=>setSmartOpen(true)}><Sparkles size={17}/>智能找房</button></div><div className="search-hot">{["写字楼", "厂房", "100-200㎡", "精装修", "50元以内"].map(x=><button key={x} onClick={()=>quickSearch(x)}>{x}</button>)}</div></section>
      <section className="listing-area" id="listings"><div className="filter-bar"><span className="filter-label"><SlidersHorizontal size={17}/>筛选</span><select aria-label="业态" value={rule.category} onChange={e=>setRule(current=>({...current,category:e.target.value}))}>{categories.map(x=><option key={x} value={x}>{x === "全部" ? "业态不限" : x}</option>)}</select><select aria-label="排序" value={sort} onChange={e=>setSort(e.target.value)}><option>默认排序</option><option>租金从低到高</option><option>面积从大到小</option></select><button className="reset-filter" onClick={()=>{setRule(emptyRule);setQuery("");setSort("默认排序");setRequestText("");}}>清除条件</button></div>
        <div className="section-title"><h2>在租房源</h2><span>{loading ? "正在加载" : `共 ${shown.length} 条已发布房源`}</span></div>
        {shown.length > 0 ? <div className="listing-list">{shown.map(item=><a className="lcard" href={sitePath(`/listing/view?id=${encodeURIComponent(item.id)}`)} key={item.id}><div className="lcard-image">{item.images[0] ? <img src={item.images[0]} alt={`${item.title}房源照片`}/> : <span className="image-placeholder"><ImageIcon size={28}/>暂无照片</span>}<span className="new-tag real-tag">已上架</span></div><div className="lcard-body"><span className="lcard-park">{item.category}</span><h3>{item.title}</h3><p>{[item.floor, item.area === null ? "面积待补充" : `${item.area}㎡`, item.facing].filter(Boolean).join(" · ")}</p><div className="lcard-tags">{item.layout && <span>{item.layout}</span>}{item.decoration && <span>{item.decoration}</span>}</div><div className="lcard-bottom"><div className="lcard-price">{item.price === null ? <strong className="price-pending">租金面议</strong> : <><strong>{item.price}</strong><span> 元/㎡·月</span></>}</div>{item.fee !== null && <small>物业 {item.fee} 元/㎡·月</small>}</div></div></a>)}</div> : !loading && <div className="empty-results"><Search size={30}/><h3>{backendReady ? "暂无符合条件的已上架房源" : "房源发布服务正在接入"}</h3><p>{backendReady ? "换个条件试试，或留下你的选址需求。" : "下方可查看已收到的实拍资料；房源参数核实后由管理员正式发布。"}</p>{backendReady && <button className="primary-action" onClick={()=>setInquiryOpen(true)}>留下需求</button>}</div>}
      </section>
      <section className="sample-section"><div className="section-title"><h2>实拍资料</h2><span>四组照片分别来自不同房源，参数待补充</span></div><div className="sample-grid">{samples.map((item,index)=><a href={sitePath(`/listing/${item.id}`)} className="sample-card" key={item.id}><div><img src={sitePath(item.image)} alt={`第 ${index+1} 套房源的室内实拍`}/><span>实拍 {String(index+1).padStart(2,"0")}</span></div><strong>房源资料 {index+1}</strong><small>面积、租金及位置待核实 <ArrowRight size={15}/></small></a>)}</div></section>
      <section className="industry-teaser"><div><span className="eyebrow">产业资源</span><h2>空间之外，连接企业合作</h2><p>企业简介、供应采购与项目合作将集中在产业资源板块。资料审核通过后才会对会员开放。</p></div><a href={sitePath("/industry")}>了解产业资源 <ArrowRight size={17}/></a></section>
    </main>
    <footer>松山湖产业招商 · 房源信息以管理员发布和实际沟通为准 <a className="admin-footer-link" href={sitePath("/admin")}>管理后台</a></footer>
    <MobileNavigation active="home"/>
    <Dialog open={smartOpen} onOpenChange={setSmartOpen}><DialogContent className="smart-dialog"><DialogHeader><DialogTitle>智能找房</DialogTitle><DialogDescription>输入面积、租金、业态或装修要求。当前按条件解析已上架房源，语义 AI 服务仍在开发。</DialogDescription></DialogHeader><input className="smart-input" value={smartText} onChange={e=>setSmartText(e.target.value)} onKeyDown={e=>{if(e.key === "Enter") applySmart();}} placeholder="例如：100到200平的精装写字楼，50元以内"/><button className="primary-action" onClick={applySmart}>查看匹配结果</button></DialogContent></Dialog>
    <InquiryDialog open={inquiryOpen} onOpenChange={setInquiryOpen} requestText={requestText || query}/>
  </div>;
}
