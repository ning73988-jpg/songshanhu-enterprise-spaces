"use client";

import { useEffect, useState } from "react";
import { ArrowLeft, ImagePlus, LogOut, Plus, Save, Trash2, Upload } from "lucide-react";
import { adminProfile, backendReady, deleteListing, LiveListing, loadAll, loadInquiries, readSession, SavedInquiry, saveListing, signIn, signOut, uploadMedia } from "@/lib/backend";
import { sitePath } from "@/lib/site-path";

const blank = (): LiveListing => ({ id: crypto.randomUUID(), title: "", category: "写字楼", park: null, unit: null, floor: null, area: null, price: null, fee: null, facing: null, layout: null, decoration: null, description: null, address: null, latitude: null, longitude: null, contact_name: null, contact_phone: null, tag: null, images: [], videos: [], status: "draft" });
const textFields: { key: keyof LiveListing; label: string; placeholder?: string }[] = [
  { key: "park", label: "园区名称（公开展示）" }, { key: "internal_code", label: "房源内部编号（仅后台）" },
  { key: "unit", label: "楼栋 / 房号" }, { key: "floor", label: "楼层" },
  { key: "address", label: "详细地址（公开展示）" }, { key: "contact_name", label: "招商联系人（公开展示）" },
  { key: "contact_phone", label: "联系电话（公开展示）" }, { key: "tag", label: "推荐标签（热门、特价或新上）" },
  { key: "facing", label: "朝向" }, { key: "layout", label: "格局" }, { key: "decoration", label: "装修" },
  { key: "free_rent_period", label: "免租期" }, { key: "supporting_facilities", label: "园区配套（公开）" },
  { key: "compatible_industries", label: "适配行业" }, { key: "factory_height", label: "厂房层高" },
  { key: "factory_load", label: "厂房承重" }, { key: "factory_power", label: "厂房配电" },
  { key: "fire_rating", label: "消防条件" }, { key: "environmental_requirements", label: "环评适配" },
  { key: "channel_notes", label: "渠道信息（仅后台）" }, { key: "followup_notes", label: "跟进备注（仅后台）" },
];
const numberFields: { key: "area" | "price" | "fee" | "owner_floor_price" | "latitude" | "longitude"; label: string; suffix: string }[] = [
  { key: "area", label: "面积", suffix: "㎡" }, { key: "price", label: "租金", suffix: "元/㎡·月" }, { key: "fee", label: "物业费", suffix: "元/㎡·月" },
  { key: "owner_floor_price", label: "业主底价（仅后台）", suffix: "元/㎡·月" },
  { key: "latitude", label: "纬度（地图定位）", suffix: "°" }, { key: "longitude", label: "经度（地图定位）", suffix: "°" },
];

export default function AdminPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [role, setRole] = useState<"superadmin" | "park_admin" | null>(null);
  const [checking, setChecking] = useState(true);
  const [items, setItems] = useState<LiveListing[]>([]);
  const [inquiries, setInquiries] = useState<SavedInquiry[]>([]);
  const [section, setSection] = useState<"listings" | "inquiries">("listings");
  const [editing, setEditing] = useState<LiveListing | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!backendReady || !readSession()) { setChecking(false); return; }
    adminProfile().then(async profile => {
      if (profile) { setRole(profile.role); setEmail(readSession()?.user.email || ""); setAuthorized(true); await refreshData(); }
      else signOut();
    }).catch(e => setError(e instanceof Error ? e.message : "连接失败")).finally(() => setChecking(false));
  }, []);

  async function refreshData() {
    const results = await Promise.allSettled([loadAll(), loadInquiries()]);
    if (results[0].status === "fulfilled") setItems(results[0].value);
    if (results[1].status === "fulfilled") setInquiries(results[1].value);
    const failure = results.find(result => result.status === "rejected");
    if (failure?.status === "rejected") setError(`已登录，但部分数据加载失败：${failure.reason instanceof Error ? failure.reason.message : "请检查网络后重试"}`);
  }

  async function login(event: React.FormEvent) {
    event.preventDefault(); setError(""); setChecking(true);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("请填写完整的管理员邮箱，例如 name@qq.com；这里不能填写 admin 用户名。"); setChecking(false); return;
    }
    if (!password) { setError("请填写管理员密码。"); setChecking(false); return; }
    try {
      await signIn(email, password);
      const profile = await adminProfile();
      if (!profile) { signOut(); throw new Error("该邮箱尚未开通管理权限，或权限已停用，请联系网站负责人。"); }
      setRole(profile.role); setAuthorized(true); setPassword(""); await refreshData();
    } catch (e) { setError(e instanceof Error ? e.message : "登录失败"); }
    finally { setChecking(false); }
  }
  function change<K extends keyof LiveListing>(key: K, value: LiveListing[K]) {
    setEditing(current => current ? { ...current, [key]: value } : null);
    setError("");
  }
  async function addFiles(files: FileList | null) {
    if (!files || !editing) return;
    const listingId = editing.id;
    const selected = Array.from(files);
    let uploaded = 0;
    const failures: string[] = [];
    setSaving(true); setError("");
    try {
      for (const [index, file] of selected.entries()) {
        setMessage(`正在上传 ${index + 1}/${selected.length}：${file.name}`);
        try {
          if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) throw new Error("请选择图片或视频文件");
          if (/\.(heic|heif)$/i.test(file.name)) throw new Error("请先在手机中导出为 JPG，或选择 JPEG/PNG 照片，以便客户浏览器正常查看");
          const url = await uploadMedia(file);
          const key = file.type.startsWith("image/") ? "images" : "videos";
          setEditing(current => current?.id === listingId ? { ...current, [key]: [...current[key], url] } : current);
          uploaded++;
        } catch (e) { failures.push(`${file.name}：${e instanceof Error ? e.message : "上传失败，请检查网络"}`); }
      }
      setMessage(uploaded ? `已上传 ${uploaded} 个文件。请点击“保存草稿”或“发布房源”保存资料。` : "");
      if (failures.length) setError(`以下文件未上传，已成功的文件仍保留在表单中：${failures.join("；")}`);
    }
    finally { setSaving(false); }
  }
  async function save(event: React.FormEvent) {
    event.preventDefault();
    if (!editing) return;
    const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null;
    const status = submitter?.value === "published" ? "published" : "draft";
    if (!editing.title.trim()) { setError("请填写房源标题"); return; }
    if (status === "published" && editing.images.length < 1) { setError("发布前请至少上传 1 张真实房源照片；资料不足时可先存草稿。"); return; }
    if (status === "published" && !editing.park?.trim()) { setError("发布前请填写园区名称。园区名称会在网站公开展示。"); return; }
    setSaving(true); setError(""); setMessage("");
    try {
      const saved = await saveListing({ ...editing, title: editing.title.trim(), status });
      setItems(current => [saved[0], ...current.filter(item => item.id !== editing.id)]); setEditing(null); setMessage(status === "published" ? "房源已发布，展示页刷新后可见。" : "草稿已保存，仅管理员可见。");
    } catch (e) { setError(e instanceof Error ? e.message : "保存失败"); }
    finally { setSaving(false); }
  }
  async function remove(item: LiveListing) {
    if (!window.confirm(`确定删除“${item.title}”吗？页面记录会删除；已上传的文件仍需在存储后台清理。`)) return;
    setSaving(true); setError("");
    try { await deleteListing(item.id); setItems(await loadAll()); setEditing(null); setMessage("房源已删除。"); }
    catch (e) { setError(e instanceof Error ? e.message : "删除失败"); }
    finally { setSaving(false); }
  }
  function logout() { signOut(); setAuthorized(false); setRole(null); setItems([]); setInquiries([]); setEditing(null); setMessage(""); setError(""); }

  return <div className="admin-shell">
    <header className="admin-header"><a href={sitePath("/")}><ArrowLeft size={18}/>返回网站</a><strong>松山湖产业招商 · 房源管理</strong>{authorized && <button onClick={logout}><LogOut size={17}/>退出</button>}</header>
    {!backendReady ? <main className="admin-center"><div className="admin-panel"><h1>管理后台待开通</h1><p>房源展示页已经可以显示实拍照片。网页内上传和跨设备管理需要先连接数据库与文件存储服务；当前网站尚未配置该服务。</p><p>开通后，此处可以登录并上传照片、视频，填写房源资料，保存草稿或发布。</p></div></main> : checking ? <main className="admin-center"><div className="admin-panel"><p>正在连接管理后台…</p></div></main> : !authorized ? <main className="admin-center"><form className="admin-panel" onSubmit={login} noValidate><h1>管理员登录</h1><p>请用本站已开通的管理员邮箱登录，不能填写 admin，也不能使用 WorkBuddy 的账号密码。</p><label>管理员邮箱<input type="email" required autoComplete="username" inputMode="email" autoCapitalize="none" spellCheck={false} placeholder="例如 name@qq.com" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>密码<input type="password" required autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="admin-primary" type="submit">登录</button>{error && <p className="admin-error" role="alert">{error}</p>}</form></main> : <main className="admin-main">
      <div className="admin-title"><div><span>{role === "superadmin" ? "超级管理员 · 全部房源权限" : "园区管理员"}</span><p className="admin-account">{email}</p><h1>{section === "listings" ? "我的房源" : "咨询与预约"}</h1><p>{section === "listings" ? "上传实拍照片与视频，补全资料后发布到展示页。" : "查看客户提交的选址需求和预约信息。"}</p></div>{section === "listings" && <button className="admin-primary" onClick={()=>{setEditing(blank());setMessage("");setError("");}}><Plus size={18}/>新增房源</button>}</div>
      <div className="admin-tabs"><button type="button" onClick={()=>{setError("");void refreshData();}}>刷新数据</button><button className={section === "listings" ? "active" : ""} onClick={()=>{setSection("listings");setEditing(null);}}>房源管理</button><button className={section === "inquiries" ? "active" : ""} onClick={()=>{setSection("inquiries");setEditing(null);}}>咨询与预约 <span>{inquiries.length}</span></button></div>
      {message && <div className="admin-message" role="status">{message}</div>}{error && !editing && <div className="admin-error" role="alert">{error}</div>}
      {section === "inquiries" ? <div className="admin-list">{inquiries.length === 0 ? <div className="admin-empty">暂时没有咨询或预约。</div> : inquiries.map(inquiry=><article className="admin-inquiry" key={inquiry.id}><div><strong>{inquiry.company}</strong><span>{new Date(inquiry.created_at).toLocaleString("zh-CN")}</span></div><p>联系人：{inquiry.contact} · 电话：{inquiry.phone}</p>{inquiry.request_text && <p>选址需求：{inquiry.request_text}</p>}{inquiry.viewing_at && <p>希望看房：{new Date(inquiry.viewing_at).toLocaleString("zh-CN")}</p>}</article>)}</div> : editing ? <form className="admin-editor" onSubmit={save}><div className="admin-editor-heading"><h2>{items.some(x=>x.id===editing.id) ? "编辑房源" : "新增房源"}</h2><button type="button" disabled={saving} onClick={()=>setEditing(null)}>返回列表</button></div><p className="admin-privacy-note">园区名称、地址、定位及招商联系电话会公开展示。内部编号、底价、渠道和跟进备注仅在后台保存。</p><fieldset className="admin-fields" disabled={saving}><div className="admin-form-grid"><label className="admin-wide">对外房源标题 *<input required value={editing.title} onChange={e=>change("title",e.target.value)} placeholder="例如：光大We谷 · A栋804"/></label><label>业态<select value={editing.category} onChange={e=>change("category",e.target.value)}>{["写字楼","厂房","研发办公","仓储"].map(x=><option key={x}>{x}</option>)}</select></label>{textFields.map(f=><label key={f.key}>{f.label}<input value={String(editing[f.key] ?? "")} onChange={e=>change(f.key,e.target.value || null)} placeholder={f.placeholder || "可稍后填写"}/></label>)}{numberFields.map(f=><label key={f.key}>{f.label}（{f.suffix}）<input type="number" min="0" step="0.01" value={editing[f.key] ?? ""} onChange={e=>change(f.key,e.target.value===""?null:Number(e.target.value))} placeholder="可稍后填写"/></label>)}<label className="admin-wide">房源说明（公开）<textarea rows={4} value={editing.description ?? ""} onChange={e=>change("description",e.target.value || null)} placeholder="交付条件、交通、园区配套和看房说明；请勿填写内部底价或客户隐私"/></label></div>
      <div className="admin-upload"><h3><ImagePlus size={20}/>照片与视频</h3><p>第一张照片会作为列表封面。可一次选择多个文件；支持 JPG、PNG、WebP 和视频。iPhone 的 HEIC 照片请先导出为 JPG；大视频请先压缩。上传后还需保存或发布房源。</p><label className="admin-upload-button"><Upload size={18}/>选择照片或视频<input type="file" accept="image/*,video/*" multiple onChange={e=>{void addFiles(e.target.files);e.target.value="";}} disabled={saving}/></label><div className="admin-media-grid">{editing.images.map((url,i)=><div className="admin-media" key={url}><img src={url} alt={`房源照片 ${i+1}`}/><button type="button" onClick={()=>change("images",editing.images.filter((_,index)=>index!==i))}>从房源移除</button></div>)}{editing.videos.map((url,i)=><div className="admin-media" key={url}><video src={url} controls/><button type="button" onClick={()=>change("videos",editing.videos.filter((_,index)=>index!==i))}>从房源移除</button></div>)}</div></div>
      <div className="admin-actions"><span className="admin-state">当前：{editing.status === "published" ? "已发布" : "草稿"}</span><button type="submit" name="action" value="draft" className="admin-secondary" disabled={saving}><Save size={18}/>{editing.status === "published" ? "下架并保存草稿" : "保存草稿"}</button><button className="admin-primary" type="submit" name="action" value="published" disabled={saving}><Upload size={18}/>{saving ? "处理中…" : editing.status === "published" ? "保存并发布" : "发布房源"}</button>{items.some(x=>x.id===editing.id) && <button className="admin-danger" type="button" onClick={()=>void remove(editing)} disabled={saving}><Trash2 size={17}/>删除</button>}</div>
      <p className="admin-publish-hint">发布需填写标题、园区名称，至少上传 1 张该房源的真实照片（当前 {editing.images.length} 张）。资料未齐时可先保存草稿；点击“发布房源”后，客户才可在展示页看到。</p></fieldset>
      {error && <div className="admin-error" role="alert">{error}</div>}
      </form> : <div className="admin-list">{items.length===0 ? <div className="admin-empty">还没有后台房源。点击“新增房源”开始上传。</div> : items.map(item=><button className="admin-list-item" key={item.id} onClick={()=>{setEditing(item);setMessage("");setError("");}}>{item.images[0] ? <img src={item.images[0]} alt=""/> : <span className="admin-no-image">暂无照片</span>}<span className="admin-list-text"><strong>{item.title}</strong><small>{item.park || "园区待补充"} · {item.area === null ? "面积待补充" : `${item.area}㎡`}</small></span><span className={item.status==="published"?"admin-published":"admin-draft"}>{item.status==="published"?"已发布":"草稿"}</span></button>)}</div>}
    </main>}
  </div>;
}
