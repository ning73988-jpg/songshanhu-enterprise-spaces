"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowLeft, CheckCircle2, ChevronLeft, ChevronRight, ImagePlus, LoaderCircle, LogOut, Plus, Save, Trash2, Upload } from "lucide-react";
import { adminProfile, backendReady, deleteListing, LiveListing, loadAll, loadInquiries, readSession, SavedInquiry, saveListing, signIn, signOut, uploadMedia } from "@/lib/backend";
import { sitePath } from "@/lib/site-path";

const blank = (): LiveListing => ({ id: crypto.randomUUID(), title: "", category: "写字楼", park: null, unit: null, floor: null, area: null, price: null, fee: null, facing: null, layout: null, decoration: null, description: null, address: null, latitude: null, longitude: null, contact_name: null, contact_phone: null, tag: null, images: [], videos: [], status: "draft" });
const textFields: { key: keyof LiveListing; label: string; placeholder?: string }[] = [
  { key: "park", label: "园区名称（公开展示）" }, { key: "internal_code", label: "房源内部编号（仅后台）" },
  { key: "unit", label: "楼栋 / 房号" }, { key: "floor", label: "楼层" },
  { key: "address", label: "详细地址（公开展示）" }, { key: "contact_name", label: "招商联系人（公开展示）" },
  { key: "contact_phone", label: "联系电话（公开展示）" }, { key: "tag", label: "推荐标签（热门、特价或新上）" },
  { key: "facing", label: "朝向" }, { key: "layout", label: "格局" }, { key: "decoration", label: "装修" },
  { key: "free_rent_period", label: "免租期" }, { key: "supporting_facilities", label: "园区配套（公开）" },
  { key: "compatible_industries", label: "适配行业" }, { key: "factory_height", label: "厂房层高" },
  { key: "factory_load", label: "厂房承重" }, { key: "factory_power", label: "厂房配电" },
  { key: "fire_rating", label: "消防条件" }, { key: "environmental_requirements", label: "环评适配" },
  { key: "channel_notes", label: "渠道信息（仅后台）" }, { key: "followup_notes", label: "跟进备注（仅后台）" },
];
const numberFields: { key: "area" | "price" | "fee" | "owner_floor_price" | "latitude" | "longitude"; label: string; suffix: string }[] = [
  { key: "area", label: "面积", suffix: "㎡" }, { key: "price", label: "租金", suffix: "元/㎡·月" }, { key: "fee", label: "物业费", suffix: "元/㎡·月" },
  { key: "owner_floor_price", label: "业主底价（仅后台）", suffix: "元/㎡·月" },
  { key: "latitude", label: "纬度（地图定位）", suffix: "°" }, { key: "longitude", label: "经度（地图定位）", suffix: "°" },
];

type UploadEntry = { id: string; name: string; percent: number; state: "queued" | "uploading" | "success" | "error"; error?: string };

export default function AdminPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [role, setRole] = useState<"superadmin" | "park_admin" | null>(null);
  const [checking, setChecking] = useState(true);
  const [items, setItems] = useState<LiveListing[]>([]);
  const [inquiries, setInquiries] = useState<SavedInquiry[]>([]);
  const [section, setSection] = useState<"listings" | "inquiries">("listings");
  const [editing, setEditing] = useState<LiveListing | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploads, setUploads] = useState<UploadEntry[]>([]);
  const [busyAction, setBusyAction] = useState<"upload" | "draft" | "published" | "delete" | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string,string>>({});
  const draggedPhoto = useRef<number | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!backendReady || !readSession()) { setChecking(false); return; }
    adminProfile().then(async profile => {
      if (profile) { setRole(profile.role); setEmail(readSession()?.user.email || ""); setAuthorized(true); await refreshData(); }
      else signOut();
    }).catch(e => setError(e instanceof Error ? e.message : "连接失败")).finally(() => setChecking(false));
  }, []);

  async function refreshData() {
    const results = await Promise.allSettled([loadAll(), loadInquiries()]);
    if (results[0].status === "fulfilled") setItems(results[0].value);
    if (results[1].status === "fulfilled") setInquiries(results[1].value);
    const failure = results.find(result => result.status === "rejected");
    if (failure?.status === "rejected") setError(`已登录，但部分数据加载失败：${failure.reason instanceof Error ? failure.reason.message : "请检查网络后重试"}`);
  }

  async function login(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setChecking(true);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("请填写完整的管理员邮箱，例如 name@qq.com；这里不能填写 admin 用户名。"); setChecking(false); return;
    }
    if (!password) { setError("请填写管理员密码。"); setChecking(false); return; }
    try {
      await signIn(email, password);
      const profile = await adminProfile();
      if (!profile) { signOut(); throw new Error("该邮箱尚未开通管理权限，或权限已停用，请联系网站负责人。"); }
      setRole(profile.role); setAuthorized(true); setPassword(""); await refreshData();
    } catch (e) { setError(e instanceof Error ? e.message : "登录失败"); }
    finally { setChecking(false); }
  }
  function change<K extends keyof LiveListing>(key: K, value: LiveListing[K]) {
    setEditing(current => current ? { ...current, [key]: value } : null);
    setError("");
    setFieldErrors(errors => { const next={...errors}; delete next[key]; return next; });
  }
  function movePhoto(from: number, to: number) {
    if (saving || !editing || from === to || to < 0 || to >= editing.images.length) return;
    const positions = new Map(Array.from(document.querySelectorAll<HTMLElement>(".admin-media[data-photo-key]")).map(node=>[node.dataset.photoKey,node.getBoundingClientRect()]));
    const images=[...editing.images]; const [photo]=images.splice(from,1); images.splice(to,0,photo); change("images",images);
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches) requestAnimationFrame(()=>{
      document.querySelectorAll<HTMLElement>(".admin-media[data-photo-key]").forEach(node=>{
        const old=positions.get(node.dataset.photoKey), current=node.getBoundingClientRect();
        if(old) node.animate([{transform:`translate(${old.left-current.left}px,${old.top-current.top}px)`},{transform:"translate(0,0)"}],{duration:240,easing:"cubic-bezier(.22,1,.36,1)"});
      });
    });
  }
  function validation(errors: Record<string,string>) {
    setFieldErrors(errors); setError("请检查标出的项目，已填写的内容会保留。");
    requestAnimationFrame(() => { const field=document.getElementById(`listing-${Object.keys(errors)[0]}`); field?.focus({preventScroll:true}); field?.scrollIntoView({block:"center",behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"}); });
  }
  async function addFiles(files: FileList | null) {
    if (!files || !editing || saving) return;
    const listingId = editing.id;
    const selected = Array.from(files);
    if (!selected.length) return;
    const entries = selected.map(file => ({ id:crypto.randomUUID(), name:file.name, percent:0, state:"queued" as const }));
    setUploads(entries);
    const update = (id: string, value: Partial<UploadEntry>) => setUploads(current => current.map(item => item.id === id ? {...item,...value} : item));
    let uploaded = 0;
    const failures: string[] = [];
    setSaving(true); setBusyAction("upload"); setError(""); setFieldErrors(current=>({...current,images:""}));
    try {
      for (const [index, file] of selected.entries()) {
        setMessage(`正在上传 ${index + 1}/${selected.length}：${file.name}`);
        try {
          if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) throw new Error("请选择图片或视频文件");
          if (/\.(heic|heif)$/i.test(file.name)) throw new Error("请先在手机中导出为 JPG，或选择 JPEG/PNG 照片，以便客户浏览器正常查看");
          update(entries[index].id,{state:"uploading"});
          const url = await uploadMedia(file,percent => update(entries[index].id,{percent}));
          update(entries[index].id,{state:"success",percent:100});
          const key = file.type.startsWith("image/") ? "images" : "videos";
          setEditing(current => current?.id === listingId ? { ...current, [key]: [...current[key], url] } : current);
          uploaded++;
        } catch (e) { const detail=e instanceof Error ? e.message : "上传失败，请检查网络"; update(entries[index].id,{state:"error",error:detail}); failures.push(`${file.name}：${detail}`); }
      }
      setMessage(uploaded ? `已上传 ${uploaded} 个文件。请点击“保存草稿”或“发布房源”保存资料。` : "");
      if (failures.length) setError(`以下文件未上传，已成功的文件仍保留在表单中：${failures.join("；")}`);
    }
    finally { setSaving(false); setBusyAction(null); }
  }
  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editing || saving) return;
    const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null;
    const status = submitter?.value === "published" ? "published" : "draft";
    const errors: Record<string,string> = {};
    if (!editing.title.trim()) errors.title="请填写房源标题";
    if (status === "published" && !editing.park?.trim()) errors.park="发布前请填写园区名称，名称会公开展示。";
    if (status === "published" && editing.images.length < 1) errors.images="请至少上传 1 张真实照片，也可以先保存草稿。";
    if (Object.keys(errors).length) { validation(errors); return; }
    if (!event.currentTarget.checkValidity()) { event.currentTarget.reportValidity(); return; }
    setFieldErrors({}); setBusyAction(status);
    setSaving(true); setError(""); setMessage("");
    try {
      const saved = await saveListing({ ...editing, title: editing.title.trim(), status });
      setItems(current => [saved[0], ...current.filter(item => item.id !== editing.id)]); setEditing(null); setMessage(status === "published" ? "房源已发布，展示页刷新后可见。" : "草稿已保存，仅管理员可见。");
    } catch (e) { setError(e instanceof Error ? e.message : "保存失败"); }
    finally { setSaving(false); setBusyAction(null); }
  }
  async function remove(item: LiveListing) {
    if (!window.confirm(`确定删除“${item.title}”吗？页面记录会删除；已上传的文件仍需在存储后台清理。`)) return;
    setSaving(true); setBusyAction("delete"); setError("");
    try { await deleteListing(item.id); setItems(await loadAll()); setEditing(null); setMessage("房源已删除。"); }
    catch (e) { setError(e instanceof Error ? e.message : "删除失败"); }
    finally { setSaving(false); setBusyAction(null); }
  }
  function logout() { signOut(); setAuthorized(false); setRole(null); setItems([]); setInquiries([]); setEditing(null); setMessage(""); setError(""); }

  return <div className="admin-shell">
    <header className="admin-header"><a href={sitePath("/")}><ArrowLeft size={18}/>返回网站</a><strong>松山湖产业招商 · 房源管理</strong>{authorized && <button disabled={saving} onClick={logout}><LogOut size={17}/>退出</button>}</header>
    {!backendReady ? <main className="admin-center"><div className="admin-panel"><h1>管理后台待开通</h1><p>房源展示页已经可以显示实拍照片。网页内上传和跨设备管理需要先连接数据库与文件存储服务；当前网站尚未配置该服务。</p><p>开通后，此处可以登录并上传照片、视频，填写房源资料，保存草稿或发布。</p></div></main> : checking ? <main className="admin-center"><div className="admin-panel"><p>正在连接管理后台…</p></div></main> : !authorized ? <main className="admin-center"><form className="admin-panel" onSubmit={login} noValidate><h1>管理员登录</h1><p>请用本站已开通的管理员邮箱登录，不能填写 admin，也不能使用 WorkBuddy 的账号密码。</p><label>管理员邮箱<input type="email" required autoComplete="username" inputMode="email" autoCapitalize="none" spellCheck={false} placeholder="例如 name@qq.com" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>密码<input type="password" required autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="admin-primary" type="submit">登录</button>{error && <p className="admin-error" role="alert">{error}</p>}</form></main> : <main className="admin-main">
      <div className="admin-title"><div><span>{role === "superadmin" ? "超级管理员 · 全部房源权限" : "园区管理员"}</span><p className="admin-account">{email}</p><h1>{section === "listings" ? "我的房源" : "咨询与预约"}</h1><p>{section === "listings" ? "上传实拍照片与视频，补全资料后发布到展示页。" : "查看客户提交的选址需求和预约信息。"}</p></div>{section === "listings" && <button className="admin-primary" disabled={saving} onClick={()=>{setEditing(blank());setUploads([]);setFieldErrors({});setMessage("");setError("");}}><Plus size={18}/>新增房源</button>}</div>
      <div className="admin-tabs"><button disabled={saving} type="button" onClick={()=>{setError("");void refreshData();}}>刷新数据</button><button disabled={saving} className={section === "listings" ? "active" : ""} onClick={()=>{setSection("listings");setEditing(null);}}>房源管理</button><button disabled={saving} className={section === "inquiries" ? "active" : ""} onClick={()=>{setSection("inquiries");setEditing(null);}}>咨询与预约 <span>{inquiries.length}</span></button></div>
      {message && <div className={`admin-message ${saving ? "" : "success-note"}`} role="status">{saving ? <LoaderCircle className="feedback-spinner" size={20}/> : <CheckCircle2 className="success-check"/>}<span>{message}</span></div>}{error && !editing && <div className="admin-error" role="alert">{error}</div>}
      {section === "inquiries" ? <div className="admin-list">{inquiries.length === 0 ? <div className="admin-empty">暂时没有咨询或预约。</div> : inquiries.map(inquiry=><article className="admin-inquiry" key={inquiry.id}><div><strong>{inquiry.company}</strong><span>{new Date(inquiry.created_at).toLocaleString("zh-CN")}</span></div><p>联系人：{inquiry.contact} · 电话：{inquiry.phone}</p>{inquiry.request_text && <p>选址需求：{inquiry.request_text}</p>}{inquiry.viewing_at && <p>希望看房：{new Date(inquiry.viewing_at).toLocaleString("zh-CN")}</p>}</article>)}</div> : editing ? <form className="admin-editor" onSubmit={save} noValidate aria-busy={saving}><div className="admin-editor-heading"><h2>{items.some(x=>x.id===editing.id) ? "编辑房源" : "新增房源"}</h2><button type="button" disabled={saving} onClick={()=>setEditing(null)}>返回列表</button></div><p className="admin-privacy-note">园区名称、地址、定位及招商联系电话会公开展示。内部编号、底价、渠道和跟进备注仅在后台保存。</p><fieldset className="admin-fields" disabled={saving}><div className="admin-form-grid"><label className="admin-wide">对外房源标题 *<input id="listing-title" aria-invalid={Boolean(fieldErrors.title)} aria-describedby={fieldErrors.title ? "listing-title-error" : undefined} required value={editing.title} onChange={e=>change("title",e.target.value)} placeholder="例如：光大We谷 · A栋804"/>{fieldErrors.title && <span className="admin-field-error" id="listing-title-error">{fieldErrors.title}</span>}</label><label>业态<select value={editing.category} onChange={e=>change("category",e.target.value)}>{["写字楼","厂房","研发办公","仓储"].map(x=><option key={x}>{x}</option>)}</select></label>{textFields.map(f=><label key={f.key}>{f.label}<input id={`listing-${f.key}`} aria-invalid={Boolean(fieldErrors[f.key])} aria-describedby={fieldErrors[f.key] ? `listing-${f.key}-error` : undefined} value={String(editing[f.key] ?? "")} onChange={e=>change(f.key,e.target.value || null)} placeholder={f.placeholder || "可稍后填写"}/>{fieldErrors[f.key] && <span className="admin-field-error" id={`listing-${f.key}-error`}>{fieldErrors[f.key]}</span>}</label>)}{numberFields.map(f=><label key={f.key}>{f.label}（{f.suffix}）<input type="number" min="0" step="0.01" value={editing[f.key] ?? ""} onChange={e=>change(f.key,e.target.value===""?null:Number(e.target.value))} placeholder="可稍后填写"/></label>)}<label className="admin-wide">房源说明（公开）<textarea rows={4} value={editing.description ?? ""} onChange={e=>change("description",e.target.value || null)} placeholder="交付条件、交通、园区配套和看房说明；请勿填写内部底价或客户隐私"/></label></div>
      <div className="admin-upload" id="listing-images" tabIndex={-1}><h3><ImagePlus size={20}/>照片与视频</h3><p>第一张照片会作为列表封面。可一次选择多个文件；支持 JPG、PNG、WebP 和视频。iPhone 的 HEIC 照片请先导出为 JPG；大视频请先压缩。上传后还需保存或发布房源。</p><label className="admin-upload-button"><Upload size={18}/>选择照片或视频<input type="file" accept="image/*,video/*" multiple onChange={e=>{void addFiles(e.target.files);e.target.value="";}} disabled={saving}/></label>{fieldErrors.images && <p className="admin-field-error" role="alert">{fieldErrors.images}</p>}
      {uploads.length > 0 && <div className="upload-queue" aria-label="文件上传进度">{uploads.map(file=><div className={`upload-row ${file.state}`} key={file.id}><div className="upload-row-label"><span title={file.name}>{file.name}</span><small>{file.state === "success" ? "上传成功" : file.state === "error" ? "上传失败" : file.state === "queued" ? "等待上传" : file.percent >= 99 ? "云端确认中…" : `${file.percent}%`}</small></div><div className="upload-progress" role="progressbar" aria-label={file.name} aria-valuenow={file.percent} aria-valuemin={0} aria-valuemax={100}><i style={{width:`${file.percent}%`}}/></div>{file.error && <p className="admin-field-error">{file.error}</p>}</div>)}</div>}
      <p className="admin-media-hint">第一张为封面。电脑可拖动照片排序，也可用箭头调整；手机可点“设为封面”。</p>
      <div className="admin-media-grid">{editing.images.map((url,i)=><div className="admin-media" key={url} data-photo-key={url} draggable={!saving} onDragStart={event=>{draggedPhoto.current=i;event.dataTransfer.effectAllowed="move";event.dataTransfer.setData("text/plain",String(i));}} onDragEnd={()=>{draggedPhoto.current=null;}} onDragOver={event=>{if(draggedPhoto.current!==null)event.preventDefault();}} onDrop={event=>{event.preventDefault();if(draggedPhoto.current!==null)movePhoto(draggedPhoto.current,i);draggedPhoto.current=null;}}><div className="admin-media-visual media-frame"><img src={url} alt={`房源照片 ${i+1}`} draggable={false}/>{i===0 && <span className="admin-cover-badge">封面</span>}</div><div className="admin-photo-tools"><button type="button" disabled={saving || i===0} onClick={()=>movePhoto(i,i-1)} aria-label={`照片 ${i+1} 前移`}><ChevronLeft size={16}/></button>{i>0 ? <button type="button" disabled={saving} onClick={()=>movePhoto(i,0)}>设为封面</button> : <span>第 1 张</span>}<button type="button" disabled={saving || i===editing.images.length-1} onClick={()=>movePhoto(i,i+1)} aria-label={`照片 ${i+1} 后移`}><ChevronRight size={16}/></button></div><button type="button" onClick={()=>change("images",editing.images.filter((_,index)=>index!==i))}>从房源移除</button></div>)}{editing.videos.map((url,i)=><div className="admin-media" key={url}><video src={url} controls preload="metadata"/><button type="button" onClick={()=>change("videos",editing.videos.filter((_,index)=>index!==i))}>从房源移除</button></div>)}</div></div>
      <div className="admin-actions"><span className="admin-state">当前：{editing.status === "published" ? "已发布" : "草稿"}</span><button type="submit" name="action" value="draft" className="admin-secondary" disabled={saving}>{busyAction === "draft" ? <LoaderCircle size={18} className="feedback-spinner"/> : <Save size={18}/>} {busyAction === "draft" ? "保存中…" : editing.status === "published" ? "下架并保存草稿" : "保存草稿"}</button><button className="admin-primary" type="submit" name="action" value="published" disabled={saving}>{busyAction === "published" ? <LoaderCircle size={18} className="feedback-spinner"/> : <Upload size={18}/>} {busyAction === "published" ? "发布中…" : editing.status === "published" ? "保存并发布" : "发布房源"}</button>{items.some(x=>x.id===editing.id) && <button className="admin-danger" type="button" onClick={()=>void remove(editing)} disabled={saving}><Trash2 size={17}/>删除</button>}</div>
      <p className="admin-publish-hint">发布需填写标题、园区名称，至少上传 1 张该房源的真实照片（当前 {editing.images.length} 张）。资料未齐时可先保存草稿；点击“发布房源”后，客户才可在展示页看到。</p></fieldset>
      {error && <div className="admin-error" role="alert">{error}</div>}
      </form> : <div className="admin-list">{items.length===0 ? <div className="admin-empty">还没有后台房源。点击“新增房源”开始上传。</div> : items.map(item=><button className="admin-list-item" key={item.id} onClick={()=>{setEditing(item);setUploads([]);setFieldErrors({});setMessage("");setError("");}}>{item.images[0] ? <img src={item.images[0]} alt=""/> : <span className="admin-no-image">暂无照片</span>}<span className="admin-list-text"><strong>{item.title}</strong><small>{item.park || "园区待补充"} · {item.area === null ? "面积待补充" : `${item.area}㎡`}</small></span><span className={item.status==="published"?"admin-published":"admin-draft"}>{item.status==="published"?"已发布":"草稿"}</span></button>)}</div>}
    </main>}
  </div>;
}
