import { LockKeyhole, MapPinned, Navigation } from "lucide-react";
import { MobileNavigation, SiteHeader } from "@/components/SiteNavigation";
import { sitePath } from "@/lib/site-path";

export default function MapPage() {
  return <div className="site-shell"><SiteHeader/><main className="feature-main"><div className="feature-heading"><span className="eyebrow">选址地图</span><h1>以地图了解产业空间</h1><p>精准园区点位仅对已验证会员开放。游客无法查看点位或园区名称。</p></div>
    <div className="locked-map"><div className="map-pattern"/><div className="map-lock-card"><span className="feature-icon"><MapPinned size={29}/></span><LockKeyhole size={19}/><h2>地图点位需会员权限</h2><p>完成会员验证后，可查看已发布园区的精准位置及对应在租房源。</p><a href={sitePath("/me")}>查看会员入口</a></div><span className="map-corner"><Navigation size={16}/> 松山湖 · 东莞</span></div>
    <div className="feature-footnote">当前位置数据不会在游客页面加载；地图服务和会员身份核验接入后开放。</div>
  </main><footer>松山湖产业招商</footer><MobileNavigation active="map"/></div>;
}
