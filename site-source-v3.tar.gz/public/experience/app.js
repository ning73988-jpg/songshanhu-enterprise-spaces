/* ============================================================
 * 松山湖写字楼招商小程序 · 视图与交互层
 * 角色：游客（浏览 / 留言咨询 / 拨打电话）+ 管理员（房源上下架 / 数据看板）
 * ============================================================ */

/* ---------------- 通用片段 ---------------- */
/* 园区列表统一入口：后台"园区管理"可增删改，存于 db.parks */
function parksAll() { return Api.db.parks || PARKS; }

/* 照片地址：三件事一起做 ——
   ① demo: 短标记 → 即时生成演示图（演示图不进本机缓存，省空间）
   ② /api/photo/ 服务器相对路径 → 补成可访问的绝对地址（浏览器可缓存、HTML 更小）
   ③ data:/assets/ 等原样返回 */
function photoURL(p) {
  if (!p) return '';
  const real = (typeof expandPhoto === 'function') ? expandPhoto(p) : p;
  if (/^\/api\//.test(real)) return (typeof SHARE_BASE === 'string' ? SHARE_BASE : '') + real;
  return real;
}

/* ---------------- 存量 base64 照片迁移（自动、幂等） ----------------
   老版本把实拍照片以 base64 塞在房源数据里，是"手机本地存储不足"的根因
   （10 套房 + 5 份整库备份就能到 70MB，远超浏览器 5MB 上限）。

   处理顺序（安全第一）：
   ① 先把 base64 照片**上传到服务器**（本地文件 + 云端 photos 表双备份）
   ② 确认该房源照片已全部上云成功，才把本机 photos 换成服务器短地址
   ③ 全部处理完置 meta.photoBackedUp = true，之后 slimLocalPhotos() 才允许剥离

   任何一步失败都保持原样，绝不出现"本机删了、服务器又没有"的丢图情况。 */
async function migratePhotosToServer() {
  if (!Api.db || !Api.db.listings || !Api.db.listings.length) return;
  if (!Api.db.meta) Api.db.meta = {};
  if (Api.db.meta.photoMigrated) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;

  const hasB64 = l => (l.photos || []).some(p => /^data:image\/(jpeg|jpg|png|webp)/i.test(p));
  const targets = Api.db.listings.filter(hasB64);
  if (!targets.length) {
    /* 没有本机 base64 照片，直接标记安全（此时剥离是空操作） */
    Api.db.meta.photoMigrated = true;
    Api.db.meta.photoBackedUp = true;
    Api.save();
    return;
  }

  if (typeof toast === 'function') toast('正在把照片搬到服务器，首次约需一会儿…');
  let doneCount = 0;
  for (const l of targets) {
    const cur = (l.photos || []).slice(0, 3);
    const out = [];
    let ok = true;
    for (let i = 0; i < cur.length; i++) {
      const p = cur[i];
      if (/^\/api\/photo\//.test(p)) { out.push(p); continue; }
      if (!/^data:image\//.test(p)) { out.push(p); continue; }
      try {
        const blob = await (await fetch(p)).blob();
        const r = await fetch('/api/photo/' + encodeURIComponent(l.id) + '/' + i + '?t=' + Date.now(), {
          method: 'POST', headers: { 'Content-Type': blob.type || 'image/jpeg' }, body: blob
        });
        const j = await r.json();
        if (j && j.url) { out.push(j.url); }
        else { ok = false; break; }
      } catch (e) { console.warn('照片上传失败', l.id, i, e); ok = false; break; }
    }
    /* 只有整组都成功了才替换，否则保持本机原图不动 */
    if (ok && out.length === cur.length) {
      l.photos = out;
      l.photosLoaded = false;
      doneCount++;
      try { if (Cloud.ready) await Cloud.pushRow('listings', l); } catch (e) { }
    }
  }

  Api.db.meta.photoMigrated = doneCount === targets.length;
  /* 全部房源都成功上云，才允许后续剥离本机副本 */
  if (Api.db.meta.photoMigrated) Api.db.meta.photoBackedUp = true;
  Api.save();
  if (doneCount) {
    if (typeof toast === 'function') toast('已把 ' + doneCount + ' 套房源的照片搬到服务器');
    /* 上云确认后立刻剥离本机 base64，把空间真正腾出来 */
    const n = Api.slimLocalPhotos(true);
    if (n && typeof toast === 'function') setTimeout(() => toast('已释放本机空间（' + n + ' 张照片转为在线加载）'), 1600);
  }
}

const TAG_META = { '特价': { cls: '' }, '热门': { cls: 'hot' }, '新上': { cls: 'new' } };

function listingCard(l) {
  const img = photoURL((l.photos && l.photos[0]) || photoURI('facade', 0));
  const tagCls = l.tag && TAG_META[l.tag] ? TAG_META[l.tag].cls : '';
  return `
  <div class="lcard" data-act="open:listing" data-id="${l.id}">
    <div class="lcard-wrap">
      <div class="lcard-img">
        <img src="${img}" alt="${esc(l.parkName)}">
        ${l.tag ? `<span class="lcard-badge ${tagCls}">${esc(l.tag)}</span>` : ''}
        ${l.status === 'offline' ? '<span class="badge-offline">已下架</span>' : ''}
      </div>
      <div class="lcard-main">
        <div class="lcard-title">${esc(l.parkName)} · ${esc(l.building)}</div>
        <div class="lcard-sub">${esc(l.floor)} · ${l.area}㎡ · ${esc(l.orientation)}向</div>
        <div class="lcard-tags">
          <span class="tag blue">${esc(l.layout)}</span>
          <span class="tag">${esc(l.decoration)}</span>
        </div>
        <div class="lcard-price">
          <span class="price-num">${l.rent == null ? '面议' : l.rent}</span>
          <span class="price-unit">元/㎡·月</span>
          <span class="price-unit" style="margin-left:auto">${l.propertyFee == null ? '物业面议' : '物业 ' + l.propertyFee + ' 元'}</span>
        </div>
      </div>
    </div>
  </div>`;
}

function statusPill(s) {
  return s === 'online'
    ? '<span class="status-pill on">在租中</span>'
    : '<span class="status-pill off">已下架</span>';
}

/* ---------------- 首页 ---------------- */
function renderHome() {
  const online = onlineListings();
  const filtered = applyFilters(online, State.filters);
  const totalArea = online.reduce((s, l) => s + l.area, 0);
  const parkCount = new Set(online.map(l => l.parkName)).size;
  const f = State.filters;
  const activeCount = ['park', 'rent', 'area', 'orientation', 'decoration', 'layout'].filter(k => f[k] !== '全部').length;

  return `
  <div class="home-hero">
    <div class="hero-entries">
      <div class="hero-entry" data-act="entry:usage" data-v="写字楼">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 21V5a1 1 0 011-1h9a1 1 0 011 1v16"/><path d="M15 9h4a1 1 0 011 1v11"/><path d="M8 8h2M8 12h2M8 16h2M11.5 21v-3.5h2.5V21M2 21h20"/></svg>
        <b>写字楼</b><span> ${online.filter(l => (l.usage || '写字楼') === '写字楼').length} 套在租</span>
      </div>
      <div class="hero-entry" data-act="entry:usage" data-v="厂房">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 20h20"/><path d="M3 20V9l6 4V9l6 4V4h5v16"/><path d="M17 13h1M17 16h1M17 8h1"/></svg>
        <b>厂房</b><span> ${online.filter(l => l.usage === '厂房').length} 套在租</span>
      </div>
      <div class="hero-entry" data-act="open:resources">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
        <b>产业资源</b><span> 企业 · 需求 · 服务</span>
      </div>
    </div>
    <div class="hero-sub">园区直租 · 免佣看房 · 政策申报一站式服务</div>
    <div class="hero-stats">
      <div class="hero-stat"><b>${online.length}</b><span>在租房源</span></div>
      <div class="hero-stat"><b>${parkCount}</b><span>覆盖园区</span></div>
      <div class="hero-stat"><b>${(totalArea / 10000).toFixed(2)}</b><span>万㎡可租</span></div>
    </div>
  </div>

  <div class="searchbar">
    <div class="search-row">
      <div class="search-input">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5" stroke-linecap="round"/></svg>
        <input type="text" id="homeSearch" placeholder="搜索园区 / 楼栋 / 格局，如「松湖智谷」" value="${esc(f.kw)}">
      </div>
      <button class="ai-btn" type="button" data-act="open:aiMatch">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4z" stroke-linejoin="round"/><path d="M18.5 14.5l.9 2.2 2.2.9-2.2.9-.9 2.2-.9-2.2-2.2-.9 2.2-.9z" stroke-linejoin="round"/></svg>
        AI找房
      </button>
    </div>
    <div class="search-hot">
      ${Array.from(new Set(online.map(l => l.parkName))).filter(p => p !== '园区待补充').slice(0, 2).concat(['整层', '精装修', '带家具精装', '100-200']).map(t => {
    const isRange = t === '100-200';
    return `<button class="hot-chip" type="button" data-act="hot:chip" data-v="${esc(t)}" data-range="${isRange ? 1 : 0}">${esc(t)}${isRange ? '㎡' : ''}</button>`;
  }).join('')}
    </div>
  </div>

  <div class="filter-bar">
    <button class="filter-chip ${activeCount ? 'on' : ''}" type="button" data-act="open:filter">
      <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 5h18M6 12h12M10 19h4" stroke-linecap="round"/></svg>
      筛选${activeCount ? '(' + activeCount + ')' : ''}
    </button>
    <button class="filter-chip ${f.usage !== '全部' ? 'on' : ''}" type="button" data-act="set:usage">${f.usage === '全部' ? '业态不限' : esc(f.usage)}</button>
    <button class="filter-chip ${f.park !== '全部' ? 'on' : ''}" type="button" data-act="open:parkPicker">${f.park === '全部' ? '园区不限' : esc(f.park)}</button>
    <button class="filter-chip ${f.rent !== '全部' ? 'on' : ''}" type="button" data-act="open:rentPicker">${f.rent === '全部' ? '租金不限' : f.rent.split('-')[0] + (f.rent.split('-')[1] ? '-' + f.rent.split('-')[1] : '') + '元'}</button>
    ${SORT_OPTS.filter(s => s.k === 'rent-asc' || s.k === 'area-desc' || s.k === 'new').map(s => `
      <button class="filter-chip ${f.sort === s.k ? 'on' : ''}" type="button" data-act="set:sort" data-v="${s.k}">${s.t}</button>`).join('')}
  </div>

  <div class="sec-title">
    <h2>${f.usage !== '全部' ? esc(f.usage) + '房源' : '精选房源'}</h2>
    <span class="sec-more">共 ${filtered.length} 套 · <span data-act="open:filter" style="color:var(--primary)">排序筛选</span></span>
  </div>
  <div class="listing-list">
    ${filtered.length ? filtered.map(listingCard).join('') : `
      <div class="empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="#B9C2CF" stroke-width="1.5"><path d="M3 10l9-7 9 7v10a1 1 0 01-1 1H4a1 1 0 01-1-1z"/><path d="M9 21V12h6v9"/></svg>
        没有符合条件的房源<br>试试放宽筛选条件
      </div>`}
  </div>
  <div style="text-align:center;font-size:11.5px;color:var(--text-3);padding:14px 0 4px">
    已展示 ${filtered.length} 条结果 · 房源信息由园区招商方实时维护
  </div>`;
}

/* ---------------- 地图找房 ---------------- */
/* 标签防重叠：按纵坐标排序后贪心挑选偏移量（候选顺序 = 优先下方，其次上方，再左右） */
const LABEL_CAND = [[0, .95], [0, -12.2], [0, 6.8], [-19, .95], [19, .95],
[-19, -12.2], [19, -12.2], [0, -18], [0, 12.6], [-19, 6.8], [19, 6.8]];

function layoutMarkers(groups) {
  const boxes = [];
  groups.slice().sort((a, b) => a.c.y - b.c.y || a.c.x - b.c.x).forEach(g => {
    const w = Math.min(30, g.park.name.replace('松山湖', '').length * 2.5 + 5.5);
    const h = 5.4;
    let pick = LABEL_CAND[0];
    for (let i = 0; i < LABEL_CAND.length; i++) {
      const c = LABEL_CAND[i];
      const x0 = g.c.x + c[0] - w / 2, x1 = g.c.x + c[0] + w / 2;
      const y0 = g.c.y + c[1], y1 = y0 + h;
      if (!boxes.some(b => !(x1 < b.x0 || x0 > b.x1 || y1 < b.y0 || y0 > b.y1))) { pick = c; break; }
    }
    const lx = g.c.x + pick[0], ly = g.c.y + pick[1];
    boxes.push({ x0: lx - w / 2, x1: lx + w / 2, y0: ly, y1: ly + h });
    g.label = { x: lx, y: ly };
  });
  return groups;
}

function applyMapTransform() {
  const inner = $('#mapInner');
  if (inner) inner.style.transform = `translate(${State.mapX}px,${State.mapY}px) scale(${State.mapScale})`;
}

/* 把某个园区移到地图中央并放大 */
function centerOnPark(name, scale) {
  const c = Api.parkCoord(name);
  const stage = $('#mapStage');
  const S = stage ? stage.offsetWidth : 0;
  State.mapScale = scale || 1.9;
  if (S) {
    State.mapX = S / 2 - State.mapScale * c.x / 100 * S;
    State.mapY = S / 2 - State.mapScale * c.y / 100 * S;
  }
  applyMapTransform();
}

/* ---------------- 在线地图（腾讯位置服务 GL JS · 合规底图） ----------------
   合规说明：底图使用腾讯位置服务（GCJ-02），不使用境外地图源。
   Key 由管理员在「管理后台 → 登录验证与分享」填入（https://lbs.qq.com 免费申请，并把本站域名
   加入该 Key 的「WebServiceAPI/JS API 域名白名单」）；前端代码内不预置任何 Key。
   未配置 Key 或加载失败时，自动回退到内置静态底图，功能不受影响。 */
const MapKit = {
  T: null, loading: null,
  key() { return String((Api.db.settings && Api.db.settings.tmapKey) || '').trim(); },
  has() { return !!this.key(); },
  load() {
    const k = this.key();
    if (!k) return Promise.resolve(false);
    if (this.T) return Promise.resolve(true);
    if (this.loading) return this.loading;
    this.loading = new Promise(resolve => {
      const s = document.createElement('script');
      s.src = 'https://map.qq.com/api/gljs?v=1.exp&libraries=service&key=' + encodeURIComponent(k);
      s.onload = () => { this.T = window.TMap || null; resolve(!!this.T); };
      s.onerror = () => { this.loading = null; resolve(false); };
      document.head.appendChild(s);
    });
    return this.loading;
  },
  /* 默认中心点：全部园区经纬度的平均值（松山湖片区） */
  center() {
    const ps = parksAll().filter(p => p.lat && p.lon);
    if (!ps.length) return { lat: 22.9165, lng: 113.8884 };
    return {
      lat: ps.reduce((s, p) => s + p.lat, 0) / ps.length,
      lng: ps.reduce((s, p) => s + p.lon, 0) / ps.length
    };
  },
  ll(lat, lng) { return new this.T.LatLng(lat, lng); }
};

/* 地图页分组的园区标记（含经纬度） */
function mapGroups() {
  const online = onlineListings();
  return parksAll().map(p => {
    const all = Api.db.listings.filter(l => l.parkName === p.name);
    return {
      park: p, list: online.filter(l => l.parkName === p.name), total: all.length,
      c: Api.parkCoord(p.name)
    };
  }).filter(g => g.total > 0);
}

function renderMap() {
  const online = onlineListings();
  let groups = mapGroups();
  groups = layoutMarkers(groups);

  const sel = State.mapPark;
  const selGroup = groups.find(g => g.park.name === sel);
  const custom = groups.filter(g => g.c.custom).length;
  const useOnline = MapKit.has();

  return `
  <div class="map-toolbar" style="padding-top:12px">
    <button class="filter-chip ${!sel ? 'on' : ''}" type="button" data-act="map:park" data-v="">全部园区</button>
    ${groups.map(g => `
      <button class="filter-chip ${sel === g.park.name ? 'on' : ''}" type="button" data-act="map:park" data-v="${esc(g.park.name)}">${esc(g.park.name)}</button>`).join('')}
  </div>
  <div class="map-wrap">
    <div class="map-stage" id="mapStage" data-online="${useOnline ? '1' : '0'}">
      <div class="map-host" id="mapHost">
        <div class="map-inner" id="mapInner" style="transform:translate(${State.mapX}px,${State.mapY}px) scale(${State.mapScale})">
          <img class="map-img" src="assets/songshanhu-map.jpg" alt="松山湖产业园分布图" draggable="false">
          ${groups.map(g => `
            <div class="marker ${sel === g.park.name ? 'on' : ''}" style="left:${g.c.x}%;top:${g.c.y}%"
                 data-act="map:park" data-v="${esc(g.park.name)}" title="${esc(g.park.name)}">
              <div class="marker-pin"><span>${g.total}</span></div>
            </div>
            <div class="marker-label ${sel === g.park.name ? 'on' : ''}" style="left:${g.label.x}%;top:${g.label.y}%"
                 data-act="map:park" data-v="${esc(g.park.name)}">${esc(g.park.name.replace('松山湖', ''))}</div>`).join('')}
        </div>
        <div class="map-zoom">
          <button type="button" data-act="map:zoom" data-v="1">+</button>
          <button type="button" data-act="map:zoom" data-v="-1">−</button>
          <button type="button" data-act="map:reset" style="font-size:13px">⟳</button>
        </div>
        ${sel ? `<button class="map-back" type="button" data-act="map:park" data-v="">‹ 全部园区</button>` : ''}
      </div>
      ${useOnline ? '<div class="map-loading" id="mapLoading">正在加载在线地图…</div>' : ''}
      ${useOnline ? `<div class="tmap-ui">
        <button type="button" data-act="map:zoomin">+</button>
        <button type="button" data-act="map:zoomout">−</button>
        <button type="button" data-act="map:recenter" style="font-size:12px">定位</button>
      </div>` : ''}
      ${useOnline ? `<div class="tmap-card hide" id="tmapCard"></div>` : ''}
    </div>
    <div class="map-legend">
      <span><i class="legend-dot" style="background:var(--primary)"></i>园区（数字为在租套数）</span>
      <span><i class="legend-dot" style="background:var(--price)"></i>${useOnline ? '已精准定位的房源' : '当前选中'}</span>
      <span class="muted">${useOnline ? '拖动 / 双指缩放 / 点标记查看' : '拖动 / 双指缩放地图'}</span>
    </div>
    <div class="map-tip">
      ${useOnline
      ? '底图：腾讯位置服务在线地图（合规底图）。点园区标记可按园区筛选，选中园区后<b>已精准定位的房源</b>会以橙色标记显示，点开即看房源详情。'
      : `底图：松山湖产业园分布图（内置静态图）。园区坐标为按真实经纬度标定的位置${custom ? `，其中 <b>${custom}</b> 个已由管理员手动校准` : ''}，点击园区标记可查看该园区在租房源。<br>在管理后台填入<b>腾讯位置服务 Key</b> 后，这里会切换为在线地图。`}
    </div>
  </div>

  <div class="sec-title">
    <h2>${sel ? esc(sel) : '园区房源'}</h2>
    <span class="sec-more">${selGroup ? selGroup.list.length + ' 套在租' : online.length + ' 套在租'}</span>
  </div>
  <div class="listing-list" style="padding-top:0">
    ${(selGroup ? selGroup.list : online).length
      ? (selGroup ? selGroup.list : online).map(listingCard).join('')
      : '<div class="empty">该园区暂无可租房源</div>'}
  </div>`;
}

/* ---------------- 房源详情 ---------------- */
/* 详情页照片大图在云端 listings.full 列，列表拉取不带；进入详情时单条补拉 */
function ensureListingPhotos(id) {
  return new Promise(resolve => {
    if (!Cloud.ready || !Cloud.client) return resolve(false);
    const cur = findListing(id);
    if (cur && cur.photosLoaded) return resolve(true);
    let done = false;
    const fin = v => { if (!done) { done = true; resolve(v); } };
    Cloud.client.database.from('listings').select('data,full').eq('id', id).maybeSingle()
      .then(res => {
        if (res && !res.error && res.data) {
          const l = findListing(id);
          const full = (res.data.full && res.data.full.photos) || [];
          const inRow = (res.data.data && res.data.data.photos) || [];
          const photos = full.length >= inRow.length ? full : inRow;
          if (l) {
            /* 只补更长的一组，不缩短已在本地的大图 */
            if (photos.length > (l.photos || []).length) l.photos = photos;
            l.photosLoaded = true;
            Api.save();
          }
        }
        fin(true);
      })
      .catch(() => fin(false));
    /* 弱网兜底：最多等 8 秒，避免编辑表单迟迟打不开 */
    setTimeout(() => fin(false), 8000);
  });
}

function loadListingPhotos(id) {
  ensureListingPhotos(id).then(() => {
    if (State.view === 'detail' && State.params.id === id) render();
  });
}

function renderDetail() {
  const l = findListing(State.params.id);
  if (!l && State.deepPending && Cloud.ready) {
    /* 深链房源本地暂无：云端拉取失败时给出重试入口，成功但无此房才判"不存在" */
    if (Cloud.lastPullOk === false) {
      return `
  <div class="empty" style="padding-top:88px;text-align:center">
    <div style="font-size:44px;margin-bottom:10px">📡</div>
    <p style="font-size:15px;font-weight:600;color:var(--text-1)">云端连接失败，无法确认该房源</p>
    <p style="font-size:12.5px;color:var(--text-3);margin-top:6px">请检查网络后重试</p>
    <button class="btn" style="margin-top:18px;width:auto;padding:0 34px" type="button" data-act="detail:retry">重试</button>
  </div>`;
    }
    return `
  <div class="empty" style="padding-top:96px;text-align:center">
    <div class="spinner" style="margin:0 auto 14px"></div>
    <p style="font-size:14.5px;font-weight:600;color:var(--text-1)">正在从云端加载房源…</p>
    <p style="font-size:12.5px;color:var(--text-3);margin-top:6px">网络较慢时会多等几秒</p>
  </div>`;
  }
  if (!l) return `
  <div class="empty" style="padding-top:64px;text-align:center">
    <div style="font-size:44px;margin-bottom:10px">🏢</div>
    <p style="font-size:16px;font-weight:600;color:var(--text-1)">房源不存在或已被删除</p>
    <p style="font-size:12.5px;color:var(--text-3);line-height:1.8;padding:0 30px;margin-top:6px">
      已确认云端没有编号「${esc(String(State.params.id || ''))}」的房源，可能已被下架删除。
    </p>
    <button class="btn" style="margin-top:18px;width:auto;padding:0 34px" type="button" data-act="tab" data-v="home">返回首页看在租房源</button>
    <button class="btn ghost" style="margin-top:10px;width:auto;padding:8px 22px;font-size:13px" type="button" data-act="detail:retry">刷新重试</button>
  </div>`;
  if (!l.photosLoaded) loadListingPhotos(l.id);
  const photos = (l.photos && l.photos.length ? l.photos : [photoURI('facade', 0)]).slice(0, 3);
  const monthTotal = Math.round((Number(l.area) || 0) * ((Number(l.rent) || 0) + (Number(l.propertyFee) || 0))); 
  return `
  <div class="gallery">
    <div class="gallery-track" id="galleryTrack">
      ${photos.map(p => `<img src="${photoURL(p)}" alt="${esc(l.parkName)}实拍图">`).join('')}
    </div>
    <div class="gallery-dots" id="galleryDots">
      ${photos.map((_, i) => `<i class="gdot ${i === 0 ? 'on' : ''}"></i>`).join('')}
    </div>
    <div class="gallery-count">1/${photos.length}</div>
    ${l.status === 'offline' ? '<div style="position:absolute;left:0;top:0;background:rgba(60,66,78,.86);color:#fff;font-size:12px;padding:5px 12px;border-radius:0 0 10px 0">该房源已下架</div>' : ''}
  </div>

  <div class="detail-head">
    <div class="detail-price">
      <span class="num">${l.rent == null ? '面议' : l.rent}</span><span class="unit">元/㎡·月</span>
      <span class="fee">${l.propertyFee == null ? '物业费待咨询' : '物业费 ' + l.propertyFee + ' 元/㎡·月'}</span>
    </div>
    <div class="detail-title">${esc(l.parkName)} · ${esc(l.building)} ${esc(l.floor)}</div>
    <div class="detail-tags">
      ${l.tag ? `<span class="tag ${l.tag === '热门' ? 'orange' : (l.tag === '特价' ? 'red' : 'green')}">${esc(l.tag)}</span>` : ''}
      <span class="tag blue">${esc(l.layout)}</span>
      <span class="tag">${esc(l.usage || '写字楼')}</span>
      <span class="tag">${esc(l.decoration)}</span>
      <span class="tag">${esc(l.orientation)}向</span>
      <span class="tag green">${l.area}㎡</span>
      ${l.rent == null ? '' : `<span class="tag orange">月租约 ¥${money(monthTotal)}</span>`}
    </div>
  </div>

  <div class="info-grid">
    <h3>房源参数</h3>
    <div class="info-rows">
      <div class="info-item"><span class="info-k">园区</span><span class="info-v">${esc(l.parkName)}</span></div>
      <div class="info-item"><span class="info-k">楼栋</span><span class="info-v">${esc(l.building)}</span></div>
      <div class="info-item"><span class="info-k">楼层</span><span class="info-v">${esc(l.floor)}</span></div>
      <div class="info-item"><span class="info-k">面积</span><span class="info-v">${l.area} ㎡</span></div>
      <div class="info-item"><span class="info-k">朝向</span><span class="info-v">${esc(l.orientation)}</span></div>
      <div class="info-item"><span class="info-k">装修</span><span class="info-v">${esc(l.decoration)}</span></div>
      <div class="info-item"><span class="info-k">格局</span><span class="info-v">${esc(l.layout)}</span></div>
      <div class="info-item"><span class="info-k">租金</span><span class="info-v" style="color:var(--price)">${l.rent} 元/㎡·月</span></div>
      <div class="info-item"><span class="info-k">物业费</span><span class="info-v">${l.propertyFee == null ? '面议' : l.propertyFee + ' 元/㎡·月'}</span></div>
      <div class="info-item"><span class="info-k">浏览量</span><span class="info-v">${l.views} 次</span></div>
      <div class="info-item full"><span class="info-k">挂牌时间</span><span class="info-v">${fmtDate(new Date(l.createdAt))}</span></div>
    </div>
  </div>

  <div class="park-card">
    <h3 style="font-size:14px;font-weight:700;display:flex;align-items:center;gap:6px">
      <span style="width:3px;height:13px;background:var(--primary);border-radius:2px;display:inline-block"></span>所在园区
    </h3>
    <div class="park-row">
      <div class="park-ico">${esc(l.parkName.slice(0, 1))}</div>
      <div style="flex:1;min-width:0">
        <div class="park-name">${esc(l.parkName)}</div>
        <div class="park-addr">${esc(l.address)}</div>
      </div>
      <button class="op-btn pri" type="button" data-act="map:locate" data-v="${esc(l.parkName)}">地图查看</button>
    </div>
    ${(l.lat && l.lng && MapKit.has()) ? `
    <div class="detail-map" id="detailMap" data-lat="${l.lat}" data-lng="${l.lng}">
      <div class="detail-map-loading">正在加载房源位置…</div>
    </div>
    <div class="detail-map-meta">📍 精准位置 ${(+l.lat).toFixed(6)}, ${(+l.lng).toFixed(6)}</div>` : ''}
  </div>

  <div class="detail-desc">
    <h3>房源介绍</h3>
    <p>${esc(l.desc || '暂无房源介绍，如需了解更多详情请留言咨询或电话联系招商顾问。')}</p>
  </div>

  <div class="detail-contact" style="margin:12px 14px 0">
    <div class="contact-avatar">${esc(l.contact.slice(0, 1))}</div>
    <div style="flex:1;min-width:0">
      <div class="contact-name">${esc(l.contact)}</div>
      <div class="contact-role">园区招商 · ${esc(maskPhone(l.phone))}</div>
    </div>
    <button class="btn sm" type="button" data-act="${l.phone ? 'call' : 'open:inquiry'}" data-id="${l.id}" data-v="${esc(l.phone)}">${l.phone ? '拨打电话' : '留言联系'}</button>
  </div>

  <div class="detail-actions">
    <button class="da-btn" type="button" data-act="call" data-v="${esc(l.phone)}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M5 3h3.6l1.8 4.5-2.2 1.6a12 12 0 006.7 6.7l1.6-2.2L21 15.4V19a2 2 0 01-2.2 2A16.8 16.8 0 013 5.2 2 2 0 015 3z" stroke-linejoin="round"/></svg>
      电话
    </button>
    <button class="da-btn" type="button" data-act="open:inquiry" data-id="${l.id}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M4 5h16v11H9l-5 4z" stroke-linejoin="round"/></svg>
      留言
    </button>
    <button class="da-btn" type="button" data-act="open:share" data-id="${l.id}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="M8.3 10.8 15.7 6.4M8.3 13.2l7.4 4.4"/></svg>
      分享房源
    </button>
    <button class="btn block" type="button" data-act="open:inquiry" data-id="${l.id}" data-type="预约看房">
      预约看房 / 咨询底价
    </button>
  </div>`;
}

/* ---------------- 游客留言中心 ---------------- */
function renderMessage() {
  const v = State.session.visitor;
  if (!v) {
    return `<div class="empty" style="padding-top:80px">
      <svg viewBox="0 0 24 24" fill="none" stroke="#B9C2CF" stroke-width="1.5"><path d="M4 5h16v11H9l-5 4z" stroke-linejoin="round"/></svg>
      <div style="margin-bottom:16px">填写访客资料后可查看本机咨询记录</div>
      <button class="btn" style="width:200px;margin:0 auto" type="button" data-act="open:login">填写资料</button>
    </div>`;
  }
  const list = Api.db.messages.filter(m => m.visitorId === v.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const pending = list.filter(m => m.status === 'pending').length;
  return `
  <div class="pad" style="padding-top:14px">
    <div class="card" style="padding:13px;display:flex;align-items:center;gap:12px">
      <div class="contact-avatar" style="background:linear-gradient(135deg,#4FA4FF,#1677FF)">${esc(v.nick.slice(0, 1))}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:14.5px;font-weight:600">${esc(v.nick)}，你好</div>
        <div style="font-size:11.5px;color:var(--text-3);margin-top:3px">共 ${list.length} 条咨询 · ${pending} 条待回复</div>
      </div>
    </div>
  </div>
  ${list.length ? list.map(m => {
    const l = findListing(m.listingId);
    return `
    <div class="msg-item">
      <div class="msg-top">
        <div class="msg-listing" ${l ? `data-act="open:listing" data-id="${m.listingId}"` : ''}>${l ? esc(l.parkName + ' · ' + l.building) : '（房源已删除）'}</div>
        <span class="msg-status ${m.status === 'pending' ? 'pending' : 'done'}">${m.status === 'pending' ? '待回复' : '已回复'}</span>
      </div>
      <div class="msg-body">【${esc(m.type)}】${esc(m.content)}</div>
      ${m.reply ? `<div class="msg-reply"><b>招商顾问回复：</b>${esc(m.reply)}</div>` : ''}
      <div class="msg-meta"><span>${esc(m.createdAt)}</span><span>联系方式 ${esc(maskPhone(m.phone))}</span></div>
    </div>`;
  }).join('') : '<div class="empty">还没有咨询记录，去房源列表看看吧</div>'}
  <div style="height:8px"></div>`;
}

/* ---------------- 我的 ---------------- */
function renderMine() {
  const v = curVisitor();
  const adm = State.session.admin;
  const myMsgs = v ? Api.db.messages.filter(m => m.visitorId === v.id) : [];
  const viewed = (State.session.viewed || []).length;
  return `
  <div class="mine-head">
    <div class="mine-user">
      <div class="mine-avatar">${v ? esc(v.nick.slice(0, 1)) : '游'}</div>
      <div style="flex:1;min-width:0">
        <div class="mine-name">${v ? esc(v.nick) : '尚未填写资料'}</div>
        <div class="mine-sub">${v ? esc(maskPhone(v.phone)) + ' · 本机资料' : '填写资料后可管理本机咨询记录'}</div>
      </div>
      ${v ? '' : '<button class="btn sm" style="background:#fff;color:var(--primary)" type="button" data-act="open:login">登录</button>'}
    </div>
  </div>

  <div class="mine-grid">
    <div><b>${myMsgs.length}</b><span>我的咨询</span></div>
    <div><b>${myMsgs.filter(m => m.status === 'done').length}</b><span>已回复</span></div>
    <div><b>${viewed}</b><span>浏览记录</span></div>
  </div>

  <div class="menu-list">
    <div class="menu-item" data-act="open:myCompany">
      <div class="menu-ico">🏢</div><div class="mi-text">我的企业</div>
      <div class="mi-val">${v ? ((v.company && v.company.name) ? esc(v.company.name) : '去完善') : '填写后使用'}</div><div class="mi-arrow">›</div>
    </div>
    <div class="menu-item" data-act="open:myNeeds">
      <div class="menu-ico">📋</div><div class="mi-text">我的需求</div>
      <div class="mi-val">${v ? ((v.needs && v.needs.length) ? v.needs.length + ' 项' : '去填写') : '填写后使用'}</div><div class="mi-arrow">›</div>
    </div>
    <div class="menu-item" data-act="tab" data-v="message">
      <div class="menu-ico">💬</div><div class="mi-text">我的留言咨询</div>
      <div class="mi-val">${myMsgs.filter(m => m.status === 'pending').length} 条待回复</div>
      <div class="mi-arrow">›</div>
    </div>
    <div class="menu-item" data-act="open:viewed">
      <div class="menu-ico">👁</div><div class="mi-text">浏览记录</div>
      <div class="mi-val">${viewed} 条</div><div class="mi-arrow">›</div>
    </div>
    <div class="menu-item" data-act="call" data-v="${esc(Api.db.settings.hotline)}">
      <div class="menu-ico">📞</div><div class="mi-text">招商热线</div>
      <div class="mi-val">${esc(Api.db.settings.hotline)}</div><div class="mi-arrow">›</div>
    </div>
    <div class="menu-item" data-act="open:about">
      <div class="menu-ico">ℹ️</div><div class="mi-text">关于平台</div><div class="mi-arrow">›</div>
    </div>
  </div>

  <div class="menu-list">
    ${adm ? `
      <div class="menu-item" data-act="goto:admin">
        <div class="menu-ico" style="background:#FFF3E4;color:#D97706">🛠</div>
        <div class="mi-text">进入管理后台</div>
        <div class="mi-val">${esc(adm.name)}</div><div class="mi-arrow">›</div>
      </div>
      <div class="menu-item" data-act="admin:logout">
        <div class="menu-ico" style="background:var(--danger-l);color:var(--danger)">↩</div>
        <div class="mi-text">退出管理员登录</div><div class="mi-arrow">›</div>
      </div>` : `
      <div class="menu-item" data-act="open:adminLogin">
        <div class="menu-ico" style="background:#FFF3E4;color:#D97706">🔐</div>
        <div class="mi-text">管理员登录</div>
        <div class="mi-val">房源上下架 / 数据看板</div><div class="mi-arrow">›</div>
      </div>`}
    ${v ? `<div class="menu-item" data-act="visitor:logout">
        <div class="menu-ico" style="background:#EEF1F6;color:var(--text-3)">⎋</div>
        <div class="mi-text">退出游客登录</div><div class="mi-arrow">›</div>
      </div>` : ''}
  </div>
  <div style="text-align:center;font-size:11px;color:var(--text-3);padding:18px 0 6px;line-height:1.7">
    松山湖产业招商网站<br>房源来自网站后台，访客资料保存在本机
  </div>`;
}

/* ---------------- 产业资源 ----------------
 * 内容三部分：管理员录入的产业资源（settings.indRes）+ 全部访客的企业登记 + 全部访客的需求 */
const INDRES_TYPES = ['政策资金', '产业载体', '投融资对接', '人才服务', '供应链资源', '其他'];

function renderResources() {
  const adm = State.session.admin;
  const indRes = Api.db.settings.indRes || [];
  const cos = Api.db.visitors.filter(v => v.company && v.company.name);
  const needs = [];
  Api.db.visitors.forEach(v => (v.needs || []).forEach(n => needs.push(Object.assign({ vName: v.nick }, n))));
  needs.sort((a, b) => (b.at || '').localeCompare(a.at || ''));
  return `
  <div class="home-hero" style="padding-bottom:14px">
    <div class="hero-sub" style="margin:0">产业资源对接 · ${indRes.length} 项服务资源 · ${cos.length} 家入驻企业 · ${needs.length} 条企业需求</div>
  </div>

  <div class="sec-title">
    <h2>产业服务资源</h2>
    ${adm ? '<button class="btn sm" type="button" data-act="open:indResForm">＋ 录入资源</button>' : ''}
  </div>
  ${indRes.length ? indRes.map(r => `
    <div class="res-card">
      <div class="res-head">
        <span class="res-type">${esc(r.type || '其他')}</span>
        <b>${esc(r.title)}</b>
        ${adm ? `<button class="btn sm ghost" style="color:var(--danger);margin-left:auto;flex:0 0 auto" type="button" data-act="del:indRes" data-id="${esc(r.id)}">删除</button>` : ''}
      </div>
      ${r.desc ? `<div class="res-desc">${esc(r.desc)}</div>` : ''}
      ${r.contact ? `<div class="res-contact">📞 ${esc(r.contact)}</div>` : ''}
    </div>`).join('') : '<div class="empty">暂无产业资源，管理员可在后台录入</div>'}

  <div class="sec-title"><h2>入驻企业</h2><span class="sec-more">${cos.length} 家</span></div>
  ${cos.length ? cos.map(v => {
    const c = v.company;
    return `
    <div class="res-card">
      <div class="res-head"><b>${esc(c.name)}</b>${c.industry ? `<span class="res-type">${esc(c.industry)}</span>` : ''}</div>
      ${c.product ? `<div class="res-desc"><b>产品 / 服务：</b>${esc(c.product)}</div>` : ''}
      ${c.intro ? `<div class="res-desc">${esc(c.intro)}</div>` : ''}
      <div class="res-contact">${adm ? '联系 ' + esc(v.nick) + ' ' + esc(v.phone) : '联系 ' + esc(v.nick) + ' ' + esc(maskPhone(v.phone)) + '（可留言对接）'}</div>
    </div>`;
  }).join('') : '<div class="empty">还没有企业登记，去「我的-我的企业」完善信息</div>'}

  <div class="sec-title"><h2>企业需求</h2><span class="sec-more">${needs.length} 条</span></div>
  ${needs.length ? needs.map(n => `
    <div class="res-card">
      <div class="res-head"><span class="res-type">${esc(n.type)}</span><b>${esc(n.vName || '企业用户')}</b>
        ${n.at ? `<span class="res-contact" style="margin-left:auto">${esc(n.at)}</span>` : ''}</div>
      <div class="res-desc">${esc(n.desc || '')}</div>
    </div>`).join('') : '<div class="empty">暂无企业需求，去「我的-我的需求」登记</div>'}
  <div style="height:10px"></div>`;
}

function sheetIndRes() {
  if (!State.session.admin) return toast('请先登录管理员');
  openSheet(`
    <div class="sheet-head">
      <h3>录入产业资源</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div class="field"><label>资源类型<span class="req">*</span></label>
        <select id="irType">${INDRES_TYPES.map(o => `<option>${o}</option>`).join('')}</select></div>
      <div class="field"><label>资源名称<span class="req">*</span></label>
        <input type="text" id="irTitle" maxlength="40" placeholder="如：松山湖专精特新申报辅导"></div>
      <div class="field"><label>资源说明</label>
        <textarea id="irDesc" maxlength="300" placeholder="简要说明服务内容、申报条件、对接方式等">${''}</textarea></div>
      <div class="field"><label>联系方式</label>
        <input type="text" id="irContact" maxlength="30" value="${esc(Api.db.settings.hotline || '')}" placeholder="电话 / 微信"></div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="submit:indRes">保存</button>
    </div>`);
}

function submitIndRes() {
  if (!State.session.admin) return toast('请先登录管理员');
  const title = (($('#irTitle') || {}).value || '').trim();
  if (!title) return toast('请填写资源名称');
  const st = Api.db.settings;
  st.indRes = (st.indRes || []).concat([{
    id: uid('R'),
    type: (($('#irType') || {}).value || '其他').trim(),
    title,
    desc: (($('#irDesc') || {}).value || '').trim(),
    contact: (($('#irContact') || {}).value || '').trim(),
    at: fmtDateTime(new Date())
  }]);
  Api.save();
  Cloud.markDirtyKeys(['indRes']);
  Cloud.pushMeta();
  closeSheet();
  toast('产业资源已录入');
  render();
}

function delIndRes(id) {
  if (!State.session.admin) return toast('请先登录管理员');
  const st = Api.db.settings;
  st.indRes = (st.indRes || []).filter(r => r.id !== id);
  Api.save();
  Cloud.markDirtyKeys(['indRes']);
  Cloud.pushMeta();
  toast('已删除');
  render();
}

/* ---------------- 管理后台 ---------------- */
function renderAdmin() {
  const adm = State.session.admin;
  if (!adm) return adminLoginInline();
  const tabs = [
    { k: 'listing', t: '房源' },
    { k: 'message', t: '留言' },
    { k: 'dashboard', t: '数据' },
    { k: 'map', t: '地图标注' },
    { k: 'parks', t: '园区' },
    { k: 'system', t: '设置' }
  ];
  const pending = Api.db.messages.filter(m => m.status === 'pending').length;
  return `
  <div class="admin-head">
    <div style="display:flex;align-items:center;gap:12px">
      <div class="admin-avatar ${adm.role === 'super' ? 'super' : ''}" style="width:46px;height:46px;font-size:18px">${esc(adm.name.slice(0, 1))}</div>
      <div style="flex:1;min-width:0">
        <div class="ah-name">${esc(adm.name)}</div>
        <div class="ah-role">${adm.role === 'super' ? '超级管理员 · 全部权限' : '普通管理员 · 房源与留言'}</div>
      </div>
    </div>
    <div style="display:flex;gap:22px;margin-top:14px">
      <div class="hero-stat"><b>${Api.db.listings.filter(l => l.status === 'online').length}</b><span>在租房源</span></div>
      <div class="hero-stat"><b>${pending}</b><span>待处理留言</span></div>
      <div class="hero-stat"><b>${Api.db.stats.visitors}</b><span>累计访客</span></div>
    </div>
  </div>
  <div class="admin-tabs">
    ${tabs.map(t => `<button type="button" class="${State.adminTab === t.k ? 'on' : ''}" data-act="admin:tab" data-v="${t.k}">${t.t}${t.k === 'message' && pending ? ' ·' + pending : ''}</button>`).join('')}
  </div>
  <div id="adminBody">${State.adminTab === 'listing' ? adminListingBody()
      : State.adminTab === 'message' ? adminMessageBody()
        : State.adminTab === 'dashboard' ? adminDashboardBody()
          : State.adminTab === 'map' ? adminMapBody()
            : State.adminTab === 'parks' ? adminParksBody()
              : adminSystemBody()}</div>`;
}

function adminLoginInline() {
  return `
  <div class="pad" style="padding-top:20px">
    <div class="card" style="padding:18px 16px 20px">
      <div style="text-align:center;margin-bottom:14px">
        <div class="park-ico" style="margin:0 auto 10px;width:46px;height:46px;font-size:19px;border-radius:14px">管</div>
        <div style="font-size:16px;font-weight:700">管理员登录</div>
        <div style="font-size:12px;color:var(--text-3);margin-top:5px">登录后可新增 / 上下架房源、处理留言与查看数据</div>
      </div>
      <div class="field"><label>账号</label><input type="text" id="admUser" placeholder="请输入管理员账号" autocomplete="username"></div>
      <div class="field"><label>密码</label><input type="password" id="admPwd" placeholder="请输入登录密码" autocomplete="current-password"></div>
      <button class="btn" style="margin-top:16px" type="button" data-act="admin:login">登录管理后台</button>
      <div style="font-size:11.5px;color:var(--text-3);text-align:center;margin-top:12px;line-height:1.7">
        需输入完整账号和密码才能登录，账号密码由超级管理员在后台创建与分配
      </div>
    </div>
  </div>`;
}

function adminListingBody() {
  const f = State.adminListFilter;
  const kw = State.adminKw.trim();
  let list = Api.db.listings.slice().sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  if (f === 'online') list = list.filter(l => l.status === 'online');
  if (f === 'offline') list = list.filter(l => l.status === 'offline');
  if (kw) list = list.filter(l => (l.parkName + l.building + l.floor).indexOf(kw) > -1);
  return `
  <div class="admin-toolbar">
    <div class="search-input">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5" stroke-linecap="round"/></svg>
      <input type="text" id="adminKw" placeholder="搜索园区 / 楼栋" value="${esc(State.adminKw)}">
    </div>
    <button class="btn sm" style="height:38px;padding:0 14px" type="button" data-act="admin:new">+ 新增</button>
  </div>
  <div class="filter-bar" style="padding-top:10px">
    ${[['all', '全部 ' + Api.db.listings.length],
      ['online', '在租 ' + Api.db.listings.filter(l => l.status === 'online').length],
      ['offline', '已下架 ' + Api.db.listings.filter(l => l.status === 'offline').length]]
      .map(p => `<button class="filter-chip ${f === p[0] ? 'on' : ''}" type="button" data-act="admin:filter" data-v="${p[0]}">${p[1]}</button>`).join('')}
    <button class="filter-chip" type="button" data-act="admin:export">导出 CSV</button>
  </div>
  <div style="height:2px"></div>
  ${list.length ? list.map(l => `
    <div class="admin-lrow">
      <div class="alimg"><img src="${photoURL((l.photos && l.photos[0]) || photoURI('facade', 0))}" alt=""></div>
      <div class="admin-lbody">
        <div class="admin-lname">${esc(l.parkName)} · ${esc(l.building)}</div>
        <div class="admin-lmeta">${esc(l.floor)} · ${l.area}㎡ · ${esc(l.orientation)} · ${esc(l.decoration)} · ${esc(l.layout)}</div>
        <div class="admin-lmeta" style="color:var(--price);font-weight:600">${l.rent} 元/㎡·月 · 物业 ${l.propertyFee} 元 · 浏览 ${l.views}</div>
        <div class="admin-lops">
          ${statusPill(l.status)}
          <button class="op-btn ${l.status === 'online' ? 'off' : 'on'}" type="button" data-act="admin:toggle" data-id="${l.id}">${l.status === 'online' ? '下架' : '上架'}</button>
          <button class="op-btn pri" type="button" data-act="admin:edit" data-id="${l.id}">编辑</button>
          <button class="op-btn del" type="button" data-act="admin:del" data-id="${l.id}">删除</button>
        </div>
      </div>
    </div>`).join('') : '<div class="empty">暂无房源，点击右上角「+ 新增」添加</div>'}
  <div style="height:10px"></div>`;
}

function adminMessageBody() {
  const msgs = Api.db.messages.slice().sort((a, b) =>
    (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || new Date(b.createdAt) - new Date(a.createdAt));
  const pending = msgs.filter(m => m.status === 'pending');
  return `
  <div class="pad" style="padding-top:12px">
    <div class="card" style="padding:12px;display:flex;gap:14px">
      <div style="flex:1;text-align:center"><b style="font-size:20px;color:var(--warn)">${pending.length}</b>
        <div style="font-size:11px;color:var(--text-3)">待回复</div></div>
      <div style="width:1px;background:var(--line)"></div>
      <div style="flex:1;text-align:center"><b style="font-size:20px;color:var(--success)">${msgs.length - pending.length}</b>
        <div style="font-size:11px;color:var(--text-3)">已回复</div></div>
      <div style="width:1px;background:var(--line)"></div>
      <div style="flex:1;text-align:center"><b style="font-size:20px;color:var(--primary)">${msgs.length}</b>
        <div style="font-size:11px;color:var(--text-3)">留言总数</div></div>
    </div>
  </div>
  ${msgs.length ? msgs.map(m => {
    const l = findListing(m.listingId);
    return `
    <div class="msg-item">
      <div class="msg-top">
        <div class="msg-listing">${esc(m.name)} · ${esc(m.phone)}</div>
        <span class="msg-status ${m.status === 'pending' ? 'pending' : 'done'}">${m.status === 'pending' ? '待回复' : '已回复'}</span>
      </div>
      <div style="font-size:11.5px;color:var(--text-3);margin-top:6px">
        【${esc(m.type)}】${l ? esc(l.parkName + ' · ' + l.building) : '房源已删除'}
      </div>
      <div class="msg-body">${esc(m.content)}</div>
      ${m.reply ? `<div class="msg-reply"><b>我的回复：</b>${esc(m.reply)}</div>` : ''}
      <div class="msg-meta"><span>${esc(m.createdAt)}</span></div>
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button class="op-btn pri" type="button" data-act="admin:reply" data-id="${m.id}">${m.reply ? '修改回复' : '回复'}</button>
        <button class="op-btn" type="button" data-act="call" data-v="${esc(m.phone)}">拨打电话</button>
        <button class="op-btn del" type="button" data-act="admin:delMsg" data-id="${m.id}">删除</button>
      </div>
    </div>`;
  }).join('') : '<div class="empty">暂无访客留言</div>'}
  <div style="height:10px"></div>`;
}

function adminDashboardBody() {
  const db = Api.db;
  const logs = db.visitLog.slice(-7);
  const maxV = Math.max(1, ...logs.map(x => x.v));
  const online = db.listings.filter(l => l.status === 'online').length;
  const offline = db.listings.length - online;
  const totalArea = db.listings.reduce((s, l) => s + l.area, 0);
  const rentAvg = db.listings.length ? Math.round(db.listings.reduce((s, l) => s + l.rent, 0) / db.listings.length) : 0;
  const top = db.listings.slice().sort((a, b) => b.views - a.views).slice(0, 5);
  const maxTop = Math.max(1, ...top.map(t => t.views));
  const pending = db.messages.filter(m => m.status === 'pending').length;
  const conv = db.stats.visitors ? (db.messages.length / db.stats.visitors * 100).toFixed(1) : '0.0';
  const parkStat = {};
  db.listings.forEach(l => { parkStat[l.parkName] = (parkStat[l.parkName] || 0) + 1; });
  const parkRank = Object.entries(parkStat).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const maxPark = Math.max(1, ...parkRank.map(p => p[1]));

  return `
  <div class="stat-grid">
    <div class="stat-card">
      <div class="sc-label">房源总数</div><div class="sc-val">${db.listings.length}</div>
      <div class="sc-sub">在租 ${online} · 下架 ${offline}</div>
      <div class="sc-ico" style="background:var(--primary-l);color:var(--primary)">🏢</div>
    </div>
    <div class="stat-card">
      <div class="sc-label">累计访客</div><div class="sc-val">${db.stats.visitors}</div>
      <div class="sc-sub">今日 ${db.stats.todayVisitors} 人</div>
      <div class="sc-ico" style="background:#E6F7EF;color:var(--success)">👥</div>
    </div>
    <div class="stat-card">
      <div class="sc-label">累计浏览量</div><div class="sc-val">${db.stats.views}</div>
      <div class="sc-sub">今日 ${db.stats.todayViews || 0} 次</div>
      <div class="sc-ico" style="background:#FFF3E4;color:#D97706">👁</div>
    </div>
    <div class="stat-card">
      <div class="sc-label">咨询留言</div><div class="sc-val">${db.messages.length}</div>
      <div class="sc-sub">待处理 ${pending} · 转化率 ${conv}%</div>
      <div class="sc-ico" style="background:#FDECEC;color:var(--danger)">💬</div>
    </div>
  </div>

  <div class="chart-card">
    <h3>近 7 日访客趋势 <small>单位：人次</small></h3>
    <div class="bars">
      ${logs.map(x => `
        <div class="bar-col">
          <span class="bar-val">${x.v}</span>
          <div class="bar" style="height:${Math.max(4, Math.round(x.v / maxV * 88))}%"></div>
          <span class="bar-lab">${x.d.slice(5)}</span>
        </div>`).join('')}
    </div>
  </div>

  <div class="chart-card">
    <h3>房源浏览量 TOP5 <small>累计浏览</small></h3>
    <div class="rank-list">
      ${top.map((t, i) => `
        <div class="rank-item">
          <div class="rank-no">${i + 1}</div>
          <div class="rank-name">${esc(t.parkName)} · ${esc(t.building)}</div>
          <div class="rank-bar"><i style="width:${Math.round(t.views / maxTop * 100)}%"></i></div>
          <div class="rank-val">${t.views}</div>
        </div>`).join('')}
    </div>
  </div>

  <div class="chart-card">
    <h3>园区房源分布 <small>按套数</small></h3>
    <div class="rank-list">
      ${parkRank.map(p => `
        <div class="rank-item">
          <div class="rank-name">${esc(p[0])}</div>
          <div class="rank-bar" style="width:90px;flex:0 0 90px"><i style="width:${Math.round(p[1] / maxPark * 100)}%"></i></div>
          <div class="rank-val">${p[1]} 套</div>
        </div>`).join('')}
    </div>
  </div>

  <div class="chart-card">
    <h3>经营概览 <small>数据汇总</small></h3>
    <div class="info-rows">
      <div class="info-item"><span class="info-k">可租面积</span><span class="info-v">${money(totalArea)} ㎡</span></div>
      <div class="info-item"><span class="info-k">平均租金</span><span class="info-v">${rentAvg} 元/㎡</span></div>
      <div class="info-item"><span class="info-k">登记访客</span><span class="info-v">${db.visitors.length} 人</span></div>
      <div class="info-item"><span class="info-k">管理员</span><span class="info-v">${db.admins.length} / ${db.settings.maxAdmins} 人</span></div>
      <div class="info-item full"><span class="info-k">数据更新</span><span class="info-v">${fmtDateTime(new Date())}</span></div>
    </div>
    <div style="display:flex;gap:9px;margin-top:12px">
      <button class="btn sm ghost" style="flex:1;height:36px" type="button" data-act="admin:export">导出房源 CSV</button>
      <button class="btn sm ghost" style="flex:1;height:36px" type="button" data-act="admin:exportVisitors">导出访客 CSV</button>
    </div>
  </div>
  <div style="height:10px"></div>`;
}

function adminSystemBody() {
  const db = Api.db;
  const adm = State.session.admin;
  const isSuper = adm && adm.role === 'super';
  return `
  <div class="notice-bar">
    <span>ℹ️</span>
    <span>管理员数量上限为 <b>${db.settings.maxAdmins}</b> 人，当前已创建 <b>${db.admins.length}</b> 人。仅超级管理员可新增、停用或删除管理员账号。</span>
  </div>

  <div class="chart-card" style="margin-top:12px">
    <h3>管理员账号 <small>${db.admins.length} / ${db.settings.maxAdmins}</small></h3>
    <div style="margin:0 -14px">
      ${db.admins.map(a => `
        <div class="admin-row">
          <div class="admin-avatar ${a.role === 'super' ? 'super' : (a.enabled ? '' : 'dis')}">${esc(a.name.slice(0, 1))}</div>
          <div class="admin-info">
            <div class="admin-uname">${esc(a.name)}
              ${a.role === 'super' ? '<span class="role-chip">超级管理员</span>' : ''}
              ${a.enabled ? '' : '<span class="role-chip" style="background:#EEF1F6;color:var(--text-3)">已停用</span>'}
            </div>
            <div class="admin-meta">账号 ${esc(a.username)} · ${esc(a.phone || '未填手机号')}</div>
            <div class="admin-meta">创建 ${esc(a.createdAt)} · 最近登录 ${esc(a.lastLogin || '从未登录')}</div>
          </div>
          ${(() => {
            const canToggle = isSuper && a.role !== 'super';
            const canPwd = isSuper || (adm && a.id === adm.id);
            if (!canToggle && !canPwd) return '<div style="flex:0 0 auto;color:var(--text-3);font-size:12px">—</div>';
            return `<div style="display:flex;flex-direction:column;gap:6px;flex:0 0 auto">
              ${canPwd ? `<button class="op-btn" type="button" data-act="admin:resetPwd" data-id="${a.id}">改密</button>` : ''}
              ${canToggle ? `<button class="op-btn ${a.enabled ? 'off' : 'on'}" type="button" data-act="admin:toggleAdmin" data-id="${a.id}">${a.enabled ? '停用' : '启用'}</button>
              <button class="op-btn del" type="button" data-act="admin:delAdmin" data-id="${a.id}">删除</button>` : ''}
            </div>`;
          })()}
        </div>`).join('')}
    </div>
    ${isSuper ? `<button class="btn" style="margin-top:14px" type="button" data-act="admin:newAdmin">+ 新增管理员</button>`
      : '<div style="font-size:12px;color:var(--text-3);text-align:center;padding:14px 0 4px">当前账号无管理员管理权限</div>'}
  </div>

  <div class="chart-card">
    <h3>平台参数</h3>
    <div class="field"><label>平台名称</label><input type="text" id="setSiteName" value="${esc(db.settings.siteName)}" ${isSuper ? '' : 'disabled'}></div>
    <div class="field"><label>招商热线</label><input type="text" id="setHotline" value="${esc(db.settings.hotline)}" ${isSuper ? '' : 'disabled'}></div>
    <div class="field"><label>管理员数量上限<span class="req">*</span></label>
      <input type="number" id="setMaxAdmins" min="1" max="20" value="${db.settings.maxAdmins}" ${isSuper ? '' : 'disabled'}>
    </div>
    ${isSuper ? '<button class="btn" style="margin-top:14px" type="button" data-act="admin:saveSettings">保存设置</button>'
      : '<div style="font-size:12px;color:var(--text-3);text-align:center;padding:6px 0 0">仅超级管理员可修改平台参数</div>'}
  </div>

  <div class="chart-card">
    <h3>登录验证 / 分享 / 在线地图</h3>
    <div style="font-size:12px;color:var(--text-2);line-height:1.8;margin-bottom:12px">
      游客登录需短信验证码校验。当前为演示通道，验证码直接显示在页面上；接入真实短信平台后，把 <code>data.js</code> 中 <code>Sms.send()</code> 换成后端接口即可。
    </div>
    <div class="field-row">
      <div class="field"><label>验证码有效期（秒）</label>
        <input type="number" id="setSmsTtl" min="60" max="1800" value="${(db.settings.sms || {}).ttlSec || 300}" ${isSuper ? '' : 'disabled'}></div>
      <div class="field"><label>发送间隔（秒）</label>
        <input type="number" id="setSmsCd" min="30" max="300" value="${(db.settings.sms || {}).cooldownSec || 60}" ${isSuper ? '' : 'disabled'}></div>
    </div>
    <div class="field-row">
      <div class="field"><label>最大尝试次数</label>
        <input type="number" id="setSmsMax" min="3" max="10" value="${(db.settings.sms || {}).maxTry || 5}" ${isSuper ? '' : 'disabled'}></div>
      <div class="field" style="display:flex;align-items:flex-end;padding-bottom:14px">
        <label class="remember-row" style="border:none;padding:0">
          <input type="checkbox" id="setSmsDemo" ${(db.settings.sms || {}).demoShow !== false ? 'checked' : ''} ${isSuper ? '' : 'disabled'}>
          <span>演示模式显示验证码</span></label>
      </div>
    </div>
    <div class="field"><label>微信公众号 AppID <span style="color:var(--text-3);font-weight:400">（可选，用于微信原生转发）</span></label>
      <input type="text" id="setWxAppId" value="${esc((db.settings.wx || {}).appId || '')}" placeholder="填入已认证公众号 AppID 后启用" ${isSuper ? '' : 'disabled'}>
    </div>
    <div class="field"><label>公众号 AppSecret <span style="color:var(--text-3);font-weight:400">（与 AppID 配套，转发卡片才会带房源缩略图与描述）</span></label>
      <input type="password" id="setWxSecret" value="${esc((db.settings.wx || {}).appSecret || '')}" placeholder="公众号后台-设置与开发-基本配置中获取" ${isSuper ? '' : 'disabled'}>
    </div>
    <div style="font-size:11.5px;color:var(--text-3);line-height:1.7;margin-top:4px">
      配置后，微信里点右上角「发送给朋友」的卡片将自动带房源标题、参数描述和缩略图；需在公众号后台把本站域名加入「JS接口安全域名」。
    </div>

    <div class="field" style="margin-top:14px"><label>腾讯位置服务 Key <span style="color:var(--text-3);font-weight:400">（在线地图 / 房源精准定位）</span></label>
      <input type="text" id="setTmapKey" value="${esc(db.settings.tmapKey || '')}" placeholder="填入腾讯位置服务 Key 后启用在线地图" ${isSuper ? '' : 'disabled'}>
    </div>
    <div style="font-size:11.5px;color:var(--text-3);line-height:1.7;margin-top:4px">
      到 <b>lbs.qq.com</b>（腾讯位置服务）免费申请 Key，勾选「WebServiceAPI」与「JavaScript API GL」，并把本站域名
      <code>a3083699bead4f4d9f7d2dee18fa7297.app.workbuddy.host</code> 加入白名单。留空则地图页使用内置静态底图。
    </div>
    ${isSuper ? '<button class="btn" style="margin-top:14px" type="button" data-act="admin:saveIntegrations">保存短信与分享设置</button>'
      : '<div style="font-size:12px;color:var(--text-3);text-align:center;padding:6px 0 0">仅超级管理员可修改</div>'}
  </div>

  <div class="chart-card">
    <h3>转发卡片设置</h3>
    <div style="font-size:12px;color:var(--text-2);line-height:1.8;margin-bottom:12px">
      自定义转发到微信时展示的标题、描述与封面图。留空则使用默认值；分享海报与公众号 JS-SDK 转发即时生效。
    </div>
    <div class="field"><label>转发标题</label>
      <input type="text" id="setShareTitle" value="${esc((db.settings.share || {}).title || '')}" placeholder="${esc((seedShareDefaults()).title)}" ${isSuper ? '' : 'disabled'}></div>
    <div class="field"><label>转发描述</label>
      <input type="text" id="setShareDesc" value="${esc((db.settings.share || {}).desc || '')}" placeholder="${esc((seedShareDefaults()).desc)}" ${isSuper ? '' : 'disabled'}></div>
    <div class="field"><label>封面图 <span style="color:var(--text-3);font-weight:400">（建议 500×400，5:4）</span></label>
      <div style="display:flex;align-items:center;gap:12px">
        <div id="shareImgPrev" style="width:90px;height:72px;border-radius:8px;background:#F1F5FB center/cover no-repeat;${(db.settings.share || {}).img ? `background-image:url('${(db.settings.share || {}).img}')` : ''}"></div>
        <div style="flex:1">
          <button class="btn sm ghost" type="button" data-act="admin:pickShareImg" ${isSuper ? '' : 'disabled'}>${(db.settings.share || {}).img ? '更换封面图' : '上传封面图'}</button>
          ${((db.settings.share || {}).img && isSuper) ? '<button class="btn sm ghost" style="margin-left:8px;color:var(--danger)" type="button" data-act="admin:clearShareImg">清除</button>' : ''}
        </div>
      </div>
      <input type="file" id="shareImgInput" accept="image/*" style="display:none">
    </div>
    ${isSuper ? '<button class="btn" style="margin-top:14px" type="button" data-act="admin:saveShare">保存转发设置</button>'
      : '<div style="font-size:12px;color:var(--text-3);text-align:center;padding:6px 0 0">仅超级管理员可修改</div>'}
  </div>

  <div class="chart-card">
    <h3>备份与恢复</h3>
    <div style="font-size:12px;color:var(--text-2);line-height:1.8;margin-bottom:12px">
      系统在每次打开、升级版本、恢复数据前都会自动备份快照（保留最近 5 份）。版本更新<b>不会改动</b>房源、管理员、园区、留言等任何数据。
    </div>
    <button class="btn" style="margin-bottom:12px" type="button" data-act="admin:backupNow">立即备份一份快照</button>
    <div id="backupList">${backupListHTML()}</div>
  </div>

  <div class="chart-card">
    <h3>数据管理</h3>
    <div style="font-size:12px;color:var(--text-2);line-height:1.8;margin-bottom:12px">
      「恢复演示数据」会先用快照备份你当前的数据，再还原初始示例；「清空」只清本机浏览器缓存，<b>云端数据不受影响</b>，重新打开页面会自动从云端恢复。
    </div>
    <button class="btn ghost" type="button" data-act="admin:reset">恢复演示数据</button>
    <button class="btn" style="margin-top:10px;background:var(--danger)" type="button" data-act="admin:clearAll">清空本机缓存数据</button>
  </div>
  <div style="height:10px"></div>`;
}

/* ---------------- 转发卡片自定义 ---------------- */
function fmtBackupTime(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}
function backupListHTML() {
  const list = Api.backups();
  if (!list.length) return '<div style="font-size:12px;color:var(--text-3)">暂无备份，点击上方按钮立即创建</div>';
  return list.map((b, i) => `
    <div class="anno-row" style="justify-content:space-between;align-items:center;margin-bottom:8px">
      <div style="font-size:12px;color:var(--text-2);line-height:1.6">
        <b>${fmtBackupTime(b.ts)}</b> · ${b.reason === 'manual' ? '手动' : b.reason === 'reset' ? '重置前' : b.reason === 'before-restore' ? '恢复前' : '自动'}
        <div style="color:var(--text-3)">${esc(b.counts || '')}</div>
      </div>
      <button class="btn ghost" style="padding:4px 12px;font-size:12px" type="button" data-act="admin:restoreBackup" data-i="${i}">恢复</button>
    </div>`).join('');
}
function refreshBackupList() {
  const el = $('#backupList');
  if (el) el.innerHTML = backupListHTML();
}
function seedShareDefaults() {
  return (typeof seedDB === 'function' ? seedDB().settings.share : { title: '', desc: '' }) || { title: '', desc: '' };
}

/* 房源页的页面级分享元数据：与服务器注入保持一致，
   避免页面加载后被 applyShareMeta() 的站点信息覆盖（部分平台读的是实时 DOM） */
function applyListingShareMeta(l) {
  const set = (sel, v) => {
    try {
      const el = document.querySelector(sel);
      if (el && v && typeof el.setAttribute === 'function') el.setAttribute('content', v);
    } catch (e) { }
  };
  const t = `${l.parkName} · ${l.building} ${l.area}㎡ ${l.rent}元/㎡·月`;
  const d = `${l.floor} · ${l.orientation}向 · ${l.decoration} · ${l.layout}，物业费 ${l.propertyFee} 元/㎡·月`;
  const img = (l.photos || [])[0] || SHARE_BASE + '/assets/songshanhu-map.jpg';
  set('meta[property="og:title"]', t);
  set('meta[property="og:description"]', d);
  set('meta[property="og:image"]', img);
  set('meta[property="og:url"]', shareLink({ id: l.id }));
  set('meta[name="twitter:title"]', t);
  set('meta[name="twitter:description"]', d);
  set('meta[name="twitter:image"]', img);
  set('meta[itemprop="name"]', t);
  set('meta[itemprop="description"]', d);
  set('meta[itemprop="image"]', img);
}

/* 应用转发设置到页面 meta（对 JS-SDK 与海报即时生效） */
function applyShareMeta() {
  /* 房源详情页：页面级分享信息用该房源（标题/参数/首图），不要退回站点信息 */
  if (State.view === 'detail' && State.params.id) {
    const l = findListing(State.params.id);
    if (l) return applyListingShareMeta(l);
  }
  const s = (Api.db.settings.share || {});
  const set = (sel, v) => {
    try {
      const el = document.querySelector(sel);
      if (el && v && typeof el.setAttribute === 'function') el.setAttribute('content', v);
    } catch (e) { }
  };
  set('meta[property="og:title"]', s.title);
  set('meta[property="og:description"]', s.desc);
  set('meta[property="og:image"]', s.img);
  set('meta[name="twitter:title"]', s.title);
  set('meta[name="twitter:description"]', s.desc);
  set('meta[name="twitter:image"]', s.img);
  set('meta[itemprop="name"]', s.title);
  set('meta[itemprop="image"]', s.img);
}

/* 上传转发封面：压缩到 500 宽 JPEG（约 60-90KB） */
function pickShareImage() {
  const inp = $('#shareImgInput');
  if (!inp) return;
  inp.onchange = () => {
    const file = inp.files && inp.files[0];
    inp.value = '';
    if (!file) return;
    if (!/^image\//.test(file.type)) return toast('请选择图片文件');
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const W = 500;
        const scale = Math.min(1, W / img.width);
        const cv = document.createElement('canvas');
        cv.width = Math.round(img.width * scale);
        cv.height = Math.round(img.height * scale);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        const out = cv.toDataURL('image/jpeg', 0.82);
        const prev = $('#shareImgPrev');
        if (prev) prev.style.backgroundImage = `url('${out}')`;
        if (!State.shareDraft) State.shareDraft = {};
        State.shareDraft.img = out;
        const btn = document.querySelector('[data-act="admin:pickShareImg"]');
        if (btn) btn.textContent = '更换封面图';
        toast('封面图已就绪，点「保存转发设置」生效');
      };
      img.onerror = () => toast('图片解析失败');
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  };
  inp.click();
}

function saveShareSettings() {
  const s = Api.db.settings.share || (Api.db.settings.share = {});
  const t = $('#setShareTitle'), d = $('#setShareDesc');
  if (t) s.title = t.value.trim();
  if (d) s.desc = d.value.trim();
  if (State.shareDraft && State.shareDraft.img !== undefined) s.img = State.shareDraft.img;
  Api.save();
  Cloud.markDirtyKeys(['share']);
  Cloud.pushMeta();
  applyShareMeta();
  toast('转发设置已保存，已同步到云端');
}

/* ---------------- AI 找房助手（云端大模型匹配 + 本地规则兜底） ---------------- */
let _aiModel = null;
async function aiModel() {
  if (_aiModel !== null) return _aiModel;
  try {
    if (!Cloud.ready || !Cloud.client || !Cloud.client.llm) return (_aiModel = false);
    const models = await Cloud.client.llm.models.list();
    const usable = (models || []).filter(x => x && x.disabled !== true);
    /* 优先快的非推理模型（找房是轻任务，推理模型太慢） */
    const prefer = ['hunyuan-chat', 'glm-4.7', 'glm-4.6', 'auto'];
    _aiModel = usable.find(x => prefer.indexOf(x.id) > -1) || usable[0] || false;
  } catch (e) { _aiModel = false; }
  return _aiModel;
}

function sheetAiMatch() {
  openSheet(`
    <div class="sheet-head"><h3>AI 找房助手</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body" style="padding-bottom:18px">
      <div class="ai-intro">用一句话说出你的需求，AI 从云端在租房源里帮你匹配最合适的办公室。</div>
      <div class="ai-quick">
        ${['预算50元以内，100平左右', '要整层，带家具精装', '光大We谷附近，朝南', '200平以上有隔间'].map(t =>
    `<button class="hot-chip" type="button" data-act="ai:quick" data-v="${esc(t)}">${esc(t)}</button>`).join('')}
      </div>
      <div class="ai-result" id="aiResult">
        <div class="ai-tip">👇 在下方输入需求，或点上面的快捷问题试试</div>
      </div>
      <div class="ai-row">
        <input type="text" id="aiInput" placeholder="例：预算45元左右，150平，精装，朝南" maxlength="80">
        <button class="btn" type="button" data-act="ai:ask">发送</button>
      </div>
    </div>`);
  const inp = $('#aiInput');
  if (inp) inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); aiAsk(); } };
}

function aiRenderResult(reply, ids) {
  const box = $('#aiResult');
  if (!box) return;
  const ls = (ids || []).map(findListing).filter(Boolean);
  box.innerHTML = `<div class="ai-bubble">${esc(reply)}</div>` +
    (ls.length
      ? `<div class="ai-list">${ls.map(listingCard).join('')}</div>`
      : '<div class="ai-tip">暂未匹配到合适房源，可放宽条件，或返回首页拨打招商热线直接咨询。</div>');
  box.scrollTop = 0;
}

/* 本地规则兜底：预算/面积/装修/格局/朝向/园区 关键词打分 */
function aiLocalMatch(q) {
  const nums = (q.match(/\d+(\.\d+)?/g) || []).map(Number);
  const rentT = nums.find(n => n > 5 && n < 300) || null;
  const areaT = nums.find(n => n >= 100) || null;
  const park = parksAll().find(p => q.indexOf(p.name) > -1 || (p.name.replace('松山湖', '').length > 2 && q.indexOf(p.name.replace('松山湖', '')) > -1));
  const wantDeco = /精装|带家具/.test(q) ? '精' : (/简装/.test(q) ? '简' : null);
  const wantLayout = /整层/.test(q) ? '整层' : (/有隔间|隔间/.test(q) ? '有隔间' : (/大通间|通间/.test(q) ? '大通间' : null));
  const wantSouth = /朝南|向南|南向/.test(q);
  const scored = onlineListings().map(l => {
    let s = 0;
    if (park) s += l.parkName === park.name ? 4 : -1;
    if (rentT) s += Math.max(0, 3 - Math.abs(l.rent - rentT) / 10);
    if (areaT) s += Math.max(0, 3 - Math.abs(l.area - areaT) / 60);
    if (wantDeco) s += (l.decoration || '').indexOf(wantDeco) > -1 ? 2 : -1;
    if (wantLayout) s += l.layout === wantLayout ? 2 : -0.5;
    if (wantSouth) s += (l.orientation || '').indexOf('南') > -1 ? 1.5 : -0.5;
    return { l, s };
  }).sort((a, b) => b.s - a.s).slice(0, 3);
  const parts = [];
  if (rentT) parts.push('预算约 ' + rentT + ' 元/㎡·月');
  if (areaT) parts.push('面积约 ' + areaT + '㎡');
  if (park) parts.push(park.name);
  const reply = (parts.length ? '按你要求的' + parts.join('、') + '，' : '') + '为你推荐以下 ' + scored.length + ' 套在租房源（本地智能匹配）：';
  return { reply, ids: scored.map(x => x.l.id) };
}

async function aiAsk(preset) {
  const inp = $('#aiInput');
  const q = String(preset || (inp ? inp.value : '') || '').trim();
  if (!q) return toast('先说说你的需求吧');
  if (Date.now() - (State.aiAt || 0) < 2500) return toast('手速太快，稍等一下…');
  State.aiAt = Date.now();
  if (preset && inp) inp.value = preset;
  const box = $('#aiResult');
  if (box) box.innerHTML = '<div style="text-align:center;padding:22px 0"><div class="spinner" style="margin:0 auto 10px"></div><div style="font-size:12.5px;color:var(--text-3)">AI 正在比对在租房源…</div></div>';

  const ls = onlineListings();
  const model = await aiModel();
  if (model && ls.length) {
    try {
      const list = ls.map(l => `${l.id}｜${l.parkName} ${l.building}｜${l.floor}｜${l.area}㎡｜租金${l.rent}元/㎡·月｜物业费${l.propertyFee}元｜${l.decoration}｜${l.orientation}向｜${l.layout}${l.tag ? '｜标签:' + l.tag : ''}`).join('\n');
      const sys = '你是「松山湖产业招商」的AI选房助手。根据用户需求从下列在租房源中挑选最匹配的（最多3套）。'
        + '只允许推荐列表中存在的房源编号，严禁编造。不完全匹配时就推荐最接近的并说明差距。'
        + '只返回JSON，格式：{"reply":"给用户的中文推荐说明，2-3句话","ids":["房源ID",…]}\n在租房源列表：\n' + list;
      let txt = '';
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 15000);   /* 15 秒超时，超时走本地兜底 */
      try {
        for await (const chunk of Cloud.client.llm.chat.completions.create({
          model: model.id,
          messages: [{ role: 'system', content: sys }, { role: 'user', content: q }],
          stream: true,
          signal: ctrl.signal
        })) {
          const d = chunk && chunk.choices && chunk.choices[0] && chunk.choices[0].delta;
          if (d && d.content) txt += d.content;
        }
      } finally { clearTimeout(timer); }
      let j = null;
      try { const m = txt.match(/\{[\s\S]*\}/); if (m) j = JSON.parse(m[0]); } catch (e) { /* 宽容解析 */ }
      if (j && Array.isArray(j.ids) && j.reply) {
        const ids = j.ids.filter(x => findListing(x));
        return aiRenderResult(String(j.reply).slice(0, 200), ids);
      }
      /* 输出不规范时降级：直接从回复文本里抓房源编号 */
      const idm = txt.match(/\b[A-Z]\d{2,6}\b/g);
      const ids2 = Array.from(new Set(idm || [])).filter(x => findListing(x));
      if (ids2.length) {
        const clean = txt.replace(/```[a-z]*|```/g, '').replace(/\{[\s\S]*\}/, '').trim();
        return aiRenderResult(clean.slice(0, 200) || '为你找到以下匹配房源：', ids2.slice(0, 3));
      }
      throw new Error('bad json');
    } catch (e) {
      console.warn('AI 匹配走本地兜底', e && e.message ? e.message : e);
    }
  }
  const local = aiLocalMatch(q);
  aiRenderResult(local.reply, local.ids);
}

/* ---------------- 视图切换 ---------------- */
const TAB_META = { home: '松山湖产业招商网站', map: '地图找房', message: '我的留言', mine: '我的' };
const VIEW_TITLE = { detail: '房源详情', admin: '管理后台', resources: '产业资源' };
const TAB_VIEWS = ['home', 'map', 'message', 'mine'];
const ICONS = {
  home: '<path d="M3 10l9-7 9 7v10a1 1 0 01-1 1H4a1 1 0 01-1-1z"/><path d="M9 21V12h6v9"/>',
  map: '<path d="M9 3L3 5.5v15L9 18l6 3 6-2.5v-15L15 6z"/><path d="M9 3v15M15 6v15"/>',
  message: '<path d="M4 5h16v11H9l-5 4z" stroke-linejoin="round"/>',
  mine: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/>'
};

const SITE_TITLE = '松山湖产业招商网站';

/* URL 跟随当前视图：详情页时地址栏带 ?id=房源号，
   微信里点右上角 ●··· →「发送给朋友」即可直接把本房源发给好友 */
function syncUrl() {
  try {
    const u = new URL(location.href);
    if (State.view === 'detail' && State.params.id) {
      if (u.searchParams.get('id') === State.params.id) return;
      u.searchParams.set('id', State.params.id);
    } else {
      if (!u.searchParams.has('id')) return;
      u.searchParams.delete('id');
    }
    history.replaceState(null, '', u.pathname + u.search + (u.hash || ''));
  } catch (e) { /* 某些容器不支持，静默跳过 */ }
}

/* 标题跟随：微信右上角转发卡片标题取自 document.title */
function syncTitle() {
  if (State.view === 'detail' && State.params.id) {
    const l = findListing(State.params.id);
    if (l) {
      document.title = l.parkName + ' · ' + (l.building || l.layout) + ' · ' + l.rent + '元/㎡·月';
      applyListingShareMeta(l);   /* 页面 meta 同步为房源信息 */
      /* 已接入公众号 JS-SDK 时，实时刷新转发卡片内容（标题/描述/缩略图/深链） */
      if (WxShare.ready || WxShare.pending) {
        try { WxShare.update(shareCtx('listing', l.id)); } catch (e) { }
      }
      return;
    }
  }
  document.title = SITE_TITLE;
  if (WxShare.ready || WxShare.pending) {
    try { WxShare.update(shareCtx('site')); } catch (e) { }
  }
}

function setView(name, push) {
  if (name === 'admin') { window.location.href = ((window.__SITE_BACKEND__ || {}).basePath || '') + '/admin/'; return; }
  if (push && State.view !== name) State.stack.push({ v: State.view, p: Object.assign({}, State.params) });
  State.view = name;
  const isTab = TAB_VIEWS.indexOf(name) > -1;
  $$('.view').forEach(el => el.classList.remove('active'));
  const el = $('#view-' + name);
  if (el) { el.classList.add('active'); el.scrollTop = 0; }
  if (isTab) State.tab = name;

  $('#navTitle').textContent = (name === 'admin' && State.session.admin) ? '管理后台' : (isTab ? TAB_META[name] : (VIEW_TITLE[name] || '松山湖产业招商网站'));
  $('#navBack').classList.toggle('show', !isTab);
  let navRight = '';
  if (!isTab && name === 'detail') {
    navRight = `<button class="nav-btn" type="button" data-act="open:share" data-id="${esc(State.params.id || '')}">分享</button>`
      + '<button class="nav-btn ghost" type="button" data-act="tab" data-v="home">首页</button>';
  } else if (!isTab) {
    navRight = '<button class="nav-btn ghost" type="button" data-act="tab" data-v="home">首页</button>';
  } else if (name === 'home') {
    navRight = '<button class="nav-btn ghost" type="button" data-act="open:share" data-v="site">分享</button>'
      + '<button class="nav-btn" type="button" data-act="open:parkPicker">园区</button>';
  }
  $('#navRight').innerHTML = navRight;

  renderTabbar();
  render();
  syncUrl();
  syncTitle();
}

function back() {
  const prev = State.stack.pop();
  if (prev) { State.view = prev.v; State.params = prev.p || {}; setView(prev.v, false); }
  else setView('home', false);
}

function renderTabbar() {
  const isTab = TAB_VIEWS.indexOf(State.view) > -1;
  const bar = $('#tabbar');
  bar.classList.toggle('hide', !isTab);
  if (!isTab) return;
  const pending = State.session.visitor
    ? Api.db.messages.filter(m => m.visitorId === State.session.visitor.id && m.status === 'pending').length : 0;
  const items = [
    { k: 'home', t: '首页' }, { k: 'map', t: '地图' }, { k: 'message', t: '留言' }, { k: 'mine', t: '我的' }
  ];
  bar.innerHTML = items.map(it => `
    <button class="tab-item ${State.tab === it.k ? 'on' : ''}" type="button" data-act="tab" data-v="${it.k}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round">${ICONS[it.k]}</svg>
      <span>${it.t}</span>
      ${it.k === 'message' && pending ? `<i class="tab-badge">${pending}</i>` : ''}
    </button>`).join('');
}

/* 打开房源详情（列表卡片、地图标记、留言关联等处统一复用） */
function openListing(id) {
  if (!id) return toast('房源编号缺失');
  State.params.id = id;          /* 关键：进入详情前必须带上房源 ID */
  State.deepPending = null;
  State.session.viewed = [id].concat((State.session.viewed || []).filter(x => x !== id)).slice(0, 20);
  Api.logView(id);
  saveSession();
  setView('detail', true);
}

/* 详情页：已精准定位的房源显示在线地图 */
function bindDetailMap() {
  const el = $('#detailMap');
  if (!el) return;
  const lat = num(el.dataset.lat), lng = num(el.dataset.lng);
  if (!lat || !lng) return;
  MapKit.load().then(ok => {
    if (!ok || !el.isConnected) return;
    try {
      const T = MapKit.T;
      el.innerHTML = '';
      const map = new T.Map(el, { center: new T.LatLng(lat, lng), zoom: 16 });
      const mk = new T.MultiMarker({
        map,
        styles: { default: new T.MarkerStyle({ width: 30, height: 38 }) },
        geometries: [{ id: 'l', styleId: 'default', position: new T.LatLng(lat, lng) }]
      });
      try { mk.setZIndex && mk.setZIndex(10); } catch (e) { }
      try { map.disableScrollWheelZoom && map.disableScrollWheelZoom(); } catch (e) { }
    } catch (e) {
      console.warn('详情地图初始化失败', e);
      el.innerHTML = '<div class="detail-map-loading">地图加载失败</div>';
    }
  });
}

function render() {
  const map = { home: renderHome, map: renderMap, message: renderMessage, mine: renderMine, detail: renderDetail, admin: renderAdmin, resources: renderResources };
  const fn = map[State.view];
  const el = $('#view-' + State.view);
  if (el && fn) el.innerHTML = fn();
  if (State.view === 'detail') bindGallery();
  if (State.view === 'detail') bindDetailMap();
  if (State.view === 'map') bindMap();
  if (State.view === 'home') bindHome();
  if (State.view === 'admin') bindAdmin();
  if (State.view === 'admin' && State.adminTab === 'map') bindAnnotateMap();
}
function refresh() { render(); renderTabbar(); }

/* ---------------- 局部绑定 ---------------- */
function bindHome() {
  const inp = $('#homeSearch');
  if (!inp) return;
  let t = null;
  inp.oninput = () => {
    clearTimeout(t);
    t = setTimeout(() => {
      State.filters.kw = inp.value;
      const box = $('#view-home');
      const pos = box.scrollTop;
      render();
      box.scrollTop = pos;
      const i2 = $('#homeSearch');
      if (i2) { i2.focus(); i2.setSelectionRange(i2.value.length, i2.value.length); }
    }, 320);
  };
}

function bindGallery() {
  const track = $('#galleryTrack');
  if (!track) return;
  const dots = $$('#galleryDots .gdot');
  const cnt = $('.gallery-count');
  track.onscroll = () => {
    const i = Math.max(0, Math.round(track.scrollLeft / track.clientWidth));
    dots.forEach((d, k) => d.classList.toggle('on', k === i));
    if (cnt) cnt.textContent = (i + 1) + '/' + dots.length;
  };
}

function bindMap() {
  bindStaticMapGestures();
  /* 配置了腾讯位置服务 Key 时，升级为在线地图（失败自动保留静态底图） */
  if (!MapKit.has()) return;
  MapKit.load().then(ok => { if (ok) mountTmap(); });
}

/* 在线地图挂载：园区标记 + 选中园区的已定位房源标记 */
function mountTmap() {
  const host = $('#mapHost');
  if (!host || $('#tmapCanvas')) return;
  const holder = document.createElement('div');
  holder.className = 'tmap-canvas';
  holder.id = 'tmapCanvas';
  host.innerHTML = '';
  host.appendChild(holder);
  const stage = $('#mapStage');
  if (stage) stage.classList.add('is-online');
  try {
    const T = MapKit.T, c = MapKit.center();
    const groups = mapGroups();
    const sel = State.mapPark;
    /* 视图优先级：本次点选的园区 > 上次浏览位置 > 松山湖默认中心 */
    const fp = State.tmapFocus ? groups.find(g => g.park.name === State.tmapFocus) : null;
    const focus = fp && fp.park.lat && fp.park.lon ? { lat: fp.park.lat, lng: fp.park.lon, zoom: 15 } : null;
    State.tmapFocus = null;
    const iv = focus || State.tmapView;
    const map = new T.Map(holder, {
      center: new T.LatLng(iv ? iv.lat : c.lat, iv ? iv.lng : c.lng),
      zoom: iv ? iv.zoom : 13
    });
    State.tmap = map;

    const parks = groups.filter(g => g.park.lat && g.park.lon).map(g => ({
      id: g.park.name, styleId: 'park',
      position: new T.LatLng(g.park.lat, g.park.lon)
    }));
    /* 选中园区时，把该园区已精准定位的房源也标出来 */
    const ls = [];
    if (sel) {
      Api.db.listings.filter(l => l.parkName === sel && l.lat && l.lng).forEach(l => {
        ls.push({ id: l.id, styleId: 'listing', position: new T.LatLng(l.lat, l.lng) });
      });
    }
    const markers = new T.MultiMarker({
      map,
      styles: {
        park: new T.MarkerStyle({ width: 28, height: 36 }),
        listing: new T.MarkerStyle({ width: 20, height: 26 })
      },
      geometries: parks.concat(ls)
    });
    markers.on('click', evt => {
      const g = evt.geometry || {};
      if (g.styleId === 'listing') return openListing(g.id);
      try {
        const c0 = map.getCenter();
        State.tmapView = { lat: c0.getLat(), lng: c0.getLng(), zoom: map.getZoom() };
      } catch (e) { }
      State.mapPark = (State.mapPark === g.id ? '' : g.id);
      refresh();
    });
    /* 点击园区标记后展示信息卡片 */
    if (sel) {
      const g = groups.find(x => x.park.name === sel);
      const card = $('#tmapCard');
      if (g && card) {
        card.classList.remove('hide');
        card.innerHTML = `<b>${esc(g.park.name)}</b><span>${g.total} 套房源 · ${g.list.length} 套在租</span>
          <button class="op-btn" type="button" data-act="map:park" data-v="">取消</button>`;
      }
    }
    const ld = $('#mapLoading');
    if (ld) ld.remove();
  } catch (e) {
    console.warn('在线地图初始化失败，回退静态底图', e);
    const stage2 = $('#mapStage');
    if (stage2) stage2.classList.remove('is-online');
    try { refresh(); } catch (e2) { }
  }
}

function bindStaticMapGestures() {
  const stage = $('#mapStage'), inner = $('#mapInner');
  if (!stage || !inner) return;
  const apply = () => { inner.style.transform = `translate(${State.mapX}px,${State.mapY}px) scale(${State.mapScale})`; };
  let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
  stage.addEventListener('pointerdown', e => {
    if (e.target.closest('.marker') || e.target.closest('.marker-label') ||
      e.target.closest('.map-zoom') || e.target.closest('.map-back')) return;
    dragging = true; sx = e.clientX; sy = e.clientY; ox = State.mapX; oy = State.mapY;
    if (stage.setPointerCapture) { try { stage.setPointerCapture(e.pointerId); } catch (err) { } }
  });
  stage.addEventListener('pointermove', e => {
    if (!dragging) return;
    State.mapX = ox + (e.clientX - sx);
    State.mapY = oy + (e.clientY - sy);
    apply();
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => stage.addEventListener(ev, () => { dragging = false; }));
  stage.addEventListener('wheel', e => {
    e.preventDefault();
    State.mapScale = Math.min(2.4, Math.max(1, +(State.mapScale + (e.deltaY > 0 ? -0.15 : 0.15)).toFixed(2)));
    apply();
  }, { passive: false });
  let pd = 0;
  stage.addEventListener('touchmove', e => {
    if (e.touches.length === 2) {
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      if (pd) State.mapScale = Math.min(2.4, Math.max(1, +(State.mapScale * (d / pd)).toFixed(3)));
      pd = d; apply();
    }
  }, { passive: true });
  stage.addEventListener('touchend', () => { pd = 0; });
}

/* ---------------- 管理端：地图标注 ---------------- */
function adminMapBody() {
  const items = parksAll().map(p => ({
    p, c: Api.parkCoord(p.name),
    total: Api.db.listings.filter(l => l.parkName === p.name).length
  }));
  const custom = items.filter(i => i.c.custom).length;
  return `
  <div class="notice-bar">
    <span>📍</span>
    <span>园区标记已按<b>真实经纬度</b>标定在底图上（底图每像素约 12.3 米）。若某个园区与实际位置有偏差，直接<b>拖动标记</b>微调，松手即保存，游客端实时生效。</span>
  </div>

  <div class="chart-card" style="margin-top:12px">
    <h3>底图标注 <small>已手动校准 ${custom} / ${parksAll().length}</small></h3>
    <div class="anno-stage" id="annoStage">
      <img class="map-img" src="assets/songshanhu-map.jpg" alt="松山湖写字楼分布图" draggable="false">
      ${items.map(it => `
        <div class="marker anno ${it.c.custom ? 'is-custom' : ''}" style="left:${it.c.x}%;top:${it.c.y}%"
             data-park="${esc(it.p.name)}" data-x="${it.c.x}" data-y="${it.c.y}">
          <div class="marker-pin"><span>${it.total}</span></div>
        </div>
        <div class="marker-label plain" style="left:${it.c.x}%;top:${it.c.y}%">${esc(it.p.name.replace('松山湖', ''))}</div>`).join('')}
    </div>
    <div class="anno-hint">蓝色标记 = 内置标定坐标；橙色标记 = 已被管理员手动校准。拖动松手后写入本地数据。</div>
    <button class="btn ghost" style="margin-top:10px" type="button" data-act="admin:resetParkAll">恢复全部默认坐标</button>
  </div>

  <div class="chart-card">
    <h3>坐标明细</h3>
    <div style="margin:0 -14px">
      ${items.map(it => `
        <div class="anno-row">
          <div style="flex:1;min-width:0">
            <div class="anno-name">${esc(it.p.name)}
              ${it.c.custom ? '<span class="role-chip" style="background:#FFF1E6;color:#D97706">已校准</span>'
      : (it.p.precise ? '<span class="role-chip" style="background:#E8F2FF;color:#1677FF">精确坐标</span>'
        : '<span class="role-chip" style="background:#EEF1F6;color:#8794A6">估算坐标</span>')}
            </div>
            <div class="anno-meta">${esc(it.p.addr)}<br>
              经纬度 ${it.p.lat.toFixed(5)}, ${it.p.lon.toFixed(5)} · 底图 ${it.c.x}% / ${it.c.y}% · ${it.total} 套房源</div>
          </div>
          ${it.c.custom ? `<button class="op-btn" type="button" data-act="admin:resetPark" data-v="${esc(it.p.name)}">还原</button>` : ''}
        </div>`).join('')}
    </div>
  </div>
  <div style="height:10px"></div>`;
}

function bindAnnotateMap() {
  const stage = $('#annoStage');
  if (!stage) return;
  let drag = null;
  stage.addEventListener('pointerdown', e => {
    const m = e.target.closest('.marker.anno');
    if (!m) return;
    e.preventDefault();
    drag = { el: m, name: m.dataset.park };
    m.classList.add('dragging');
    if (stage.setPointerCapture) { try { stage.setPointerCapture(e.pointerId); } catch (err) { } }
  });
  stage.addEventListener('pointermove', e => {
    if (!drag) return;
    const r = stage.getBoundingClientRect();
    const x = Math.min(100, Math.max(0, (e.clientX - r.left) / r.width * 100));
    const y = Math.min(100, Math.max(0, (e.clientY - r.top) / r.height * 100));
    drag.el.style.left = x + '%';
    drag.el.style.top = y + '%';
    drag.x = x; drag.y = y;
  });
  ['pointerup', 'pointercancel'].forEach(ev => stage.addEventListener(ev, () => {
    if (!drag) return;
    const { name, el, x, y } = drag;
    drag = null;
    el.classList.remove('dragging');
    if (x == null || y == null) return;
    Api.setParkCoord(name, x, y);
    const body = $('#adminBody');
    if (body) { body.innerHTML = adminMapBody(); bindAnnotateMap(); }
    toast(name + ' 位置已更新');
  }));
}

function bindAdmin() {
  const kw = $('#adminKw');
  if (!kw) return;
  let t = null;
  kw.oninput = () => {
    clearTimeout(t);
    t = setTimeout(() => {
      State.adminKw = kw.value;
      const body = $('#adminBody');
      if (body) body.innerHTML = adminListingBody();
      const k2 = $('#adminKw');
      if (k2) { k2.focus(); k2.setSelectionRange(k2.value.length, k2.value.length); }
    }, 300);
  };
}

/* ---------------- 留言表单 ---------------- */
function sheetInquiry(listingId, type, prefill) {
  const l = findListing(listingId);
  if (!l) return toast('房源不存在');
  const v = State.session.visitor;
  const pf = prefill || {};
  const cur = type || pf.type || MSG_TYPES[0];
  openSheet(`
    <div class="sheet-head">
      <h3>在线留言咨询</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div style="background:#F7FAFF;border-radius:10px;padding:11px;font-size:12.5px;color:var(--text-2);line-height:1.65">
        <b style="color:var(--text)">${esc(l.parkName)} · ${esc(l.building)}</b><br>
        ${esc(l.floor)} · ${l.area}㎡ · ${esc(l.orientation)}向 · ${l.rent} 元/㎡·月
      </div>
      ${v ? '' : `<div class="gate-tip">
        <b>可保存访客资料</b>：留下称呼和手机号，方便招商顾问联系你。
        <button class="op-btn pri" type="button" data-act="open:login" style="margin-left:8px">填写资料</button>
      </div>`}
      <div class="field"><label>咨询类型</label>
        <div class="seg" id="inqType">
          ${MSG_TYPES.map(t => `<button type="button" class="${cur === t ? 'on' : ''}" data-v="${t}">${t}</button>`).join('')}
        </div>
      </div>
      <div class="field-row">
        <div class="field"><label>称呼<span class="req">*</span></label>
          <input type="text" id="inqName" value="${esc(v ? v.nick : (pf.name || ''))}" placeholder="怎么称呼您"></div>
        <div class="field"><label>手机号<span class="req">*</span></label>
          <input type="tel" id="inqPhone" value="${esc(v ? v.phone : (pf.phone || Api.getPhone()))}" placeholder="方便顾问联系"></div>
      </div>
      <div class="field"><label>留言内容<span class="req">*</span></label>
        <textarea id="inqContent" placeholder="例如：想约本周六上午看房，能否分租 150㎡？">${esc(pf.content || (cur === '预约看房' && !prefill ? '想预约看房，请安排招商顾问与我联系。' : ''))}</textarea>
      </div>
      <div style="font-size:11.5px;color:var(--text-3);line-height:1.7">
        提交后招商顾问将在工作时间内回复；也可直接拨打 ${esc(l.contact)} ${esc(l.phone)} 电话联系。
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="submit:inquiry" data-id="${listingId}">提交留言</button>
    </div>`);
  const seg = $('#inqType');
  if (seg) seg.onclick = e => {
    const b = e.target.closest('button');
    if (!b) return;
    $$('#inqType button').forEach(x => x.classList.remove('on'));
    b.classList.add('on');
  };
}

async function submitInquiry(listingId) {
  const name = (($('#inqName') || {}).value || '').trim();
  const phone = (($('#inqPhone') || {}).value || '').trim();
  const content = (($('#inqContent') || {}).value || '').trim();
  const typeEl = $('#inqType .on');
  const type = typeEl ? typeEl.dataset.v : '其他问题';
  if (!name) return toast('请填写称呼');
  if (!/^1[3-9]\d{9}$/.test(phone)) return toast('请填写正确的手机号');
  if (content.length < 4) return toast('留言内容至少 4 个字');
  const config = window.__SITE_BACKEND__ || {};
  if (!config.url || !config.key) return toast('留言服务尚未连接');
  const button = document.querySelector('[data-act="submit:inquiry"]');
  if (button) { button.disabled = true; button.textContent = '提交中…'; }
  try {
    const visitor = State.session.visitor;
    const response = await fetch(String(config.url).replace(/\/$/, '') + '/rest/v1/inquiries', {
      method: 'POST',
      headers: { apikey: config.key, Authorization: 'Bearer ' + config.key, 'Content-Type': 'application/json', Prefer: 'return=minimal' },
      body: JSON.stringify({ listing_id: listingId, company: visitor?.company?.name || '个人访客', contact: name, phone, request_text: '【' + type + '】' + content })
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const now = fmtDateTime(new Date());
    let v = visitor;
    if (!v) {
      v = { id: uid('V'), nick: name, phone, company: null, needs: [], createdAt: now, visits: 1 };
      Api.db.visitors.push(v); State.session.visitor = v; Api.setPhone(phone);
    }
    const message = { id: uid('M'), listingId, visitorId: v.id, name, phone, type, content, createdAt: now, status: 'pending', reply: '' };
    Api.db.messages.push(message); Api.save(); saveSession(); closeSheet();
    toast('留言已提交到招商后台'); setTimeout(refresh, 60);
  } catch (error) {
    console.error('提交留言失败', error); toast('提交失败，请检查网络后重试');
    if (button) { button.disabled = false; button.textContent = '提交留言'; }
  }
}

function clearCodeTimer() { if (codeTimer) { clearInterval(codeTimer); codeTimer = null; } }

function startCountdown(btn, sec) {
  if (!btn) return;
  let n = sec;
  clearCodeTimer();
  btn.disabled = true;
  btn.classList.add('disabled');
  btn.textContent = n + ' 秒后重发';
  codeTimer = setInterval(() => {
    n--;
    if (n <= 0) {
      clearCodeTimer();
      btn.disabled = false;
      btn.classList.remove('disabled');
      btn.textContent = '重新获取';
    } else btn.textContent = n + ' 秒后重发';
  }, 1000);
}

function sendVisitorCode() {
  const phone = (($('#lgPhone') || {}).value || '').trim();
  if (!/^1[3-9]\d{9}$/.test(phone)) { toast('请先填写正确的手机号'); return; }
  const r = Sms.send(phone);
  if (!r.ok) {
    if (r.wait) startCountdown($('#lgSend'), r.wait);
    toast(r.msg);
    return;
  }
  const demo = Sms.conf().demoShow && r.code;
  const hint = $('#lgHint');
  if (hint) {
    hint.innerHTML = `验证码已发送至 ${esc(maskPhone(phone))}，${Math.round(Sms.conf().ttlSec / 60)} 分钟内有效。` +
      (demo ? `<br><b style="color:var(--primary)">演示模式验证码：${r.code}</b>（已自动填入，正式接短信通道后不再显示）` : '');
  }
  if (demo) { const ci = $('#lgCode'); if (ci) ci.value = r.code; }
  toast(demo ? ('验证码已发送（演示：' + r.code + '）') : '验证码已发送，请注意查收');
  startCountdown($('#lgSend'), Sms.conf().cooldownSec);
}

function sheetVisitorLogin() {
  const v = State.session.visitor;
  openSheet(`
    <div class="sheet-head"><h3>本机访客资料</h3><button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body">
      <div class="field"><label>称呼<span class="req">*</span></label><input id="lgNick" value="${esc(v ? v.nick : '')}" placeholder="怎么称呼您"></div>
      <div class="field"><label>手机号<span class="req">*</span></label><input type="tel" id="lgPhone" maxlength="11" inputmode="numeric" value="${esc(v ? v.phone : Api.getPhone())}" placeholder="方便招商顾问联系"></div>
      <div class="code-hint">资料仅保存在当前浏览器，填写手机号不等于身份验证。提交咨询时，信息会发送到招商后台。</div>
    </div>
    <div class="sheet-foot"><button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button><button class="btn" type="button" data-act="submit:visitorLogin">保存资料</button></div>`);
}

function submitVisitorLogin() {
  const phone = (($('#lgPhone') || {}).value || '').trim();
  const nick = (($('#lgNick') || {}).value || '').trim();
  if (!nick) return toast('请填写称呼');
  if (!/^1[3-9]\d{9}$/.test(phone)) return toast('请填写正确的手机号');
  let v = State.session.visitor;
  if (!v) {
    v = { id: uid('V'), nick, phone, company: null, needs: [], createdAt: fmtDateTime(new Date()), visits: 1 };
    Api.db.visitors.push(v);
  } else { v.nick = nick; v.phone = phone; }
  State.session.visitor = v;
  Api.setPhone(phone);
  Api.save(); saveSession(); closeSheet(); toast('本机资料已保存'); refresh();
  if (State.pendingInquiry) {
    const pending = State.pendingInquiry; State.pendingInquiry = null;
    setTimeout(() => sheetInquiry(pending.listingId, pending.type, pending), 120);
  }
}

function reloadSession() {
  const s = Api.getSession();
  State.session = { visitor: s.visitor || null, admin: s.admin || null, viewed: s.viewed || [] };
}
function saveSession() {
  Api.setSession({ visitor: State.session.visitor, admin: State.session.admin, viewed: State.session.viewed || [] });
}

/* ---------------- 我的企业 / 我的需求 ----------------
 * 挂在访客（visitors 行）上：company = {name, industry, product, intro}
 * needs = [{nid, type, desc, at}]，随云端 visitors 表同步，换设备登录不丢 */
const INDUSTRY_OPTS = ['电子信息', '智能制造', '新材料', '新能源', '生物医药', '软件与信息服务', '数字经济', '现代服务业', '商贸物流', '金融投资', '其他'];
const NEED_TYPE_OPTS = ['办公场地', '研发场地', '厂房', '政策申报', '融资对接', '人才招聘', '供应链资源', '其他'];

/* 云端 pull 会整表替换 visitors，用 id 重新对齐当前会话的访客引用 */
function curVisitor() {
  const v = State.session.visitor;
  if (!v) return null;
  const rec = Api.db.visitors.find(x => x.id === v.id);
  if (rec) State.session.visitor = rec;
  return rec;
}

/* 未登录时弹登录，返回 false 表示流程中断 */
function ensureVisitor() {
  if (curVisitor()) return true;
  toast('请先登录后再填写');
  sheetVisitorLogin();
  return false;
}

function sheetMyCompany() {
  const v = curVisitor();
  if (!ensureVisitor()) return;
  const co = v.company || {};
  openSheet(`
    <div class="sheet-head">
      <h3>我的企业</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div class="field"><label>企业名称<span class="req">*</span></label>
        <input type="text" id="coName" maxlength="40" value="${esc(co.name || '')}" placeholder="请输入企业全称或简称"></div>
      <div class="field"><label>所属行业</label>
        <select id="coIndustry">
          <option value="">请选择行业</option>
          ${INDUSTRY_OPTS.map(o => `<option value="${o}" ${co.industry === o ? 'selected' : ''}>${o}</option>`).join('')}
        </select></div>
      <div class="field"><label>主营产品 / 服务</label>
        <textarea id="coProduct" maxlength="200" placeholder="如：自动化检测设备、企业级 SaaS 软件、精密零部件加工等">${esc(co.product || '')}</textarea></div>
      <div class="field"><label>企业简介</label>
        <textarea id="coIntro" maxlength="500" style="min-height:110px" placeholder="简要介绍企业规模、发展方向、落地需求等，便于招商顾问精准对接">${esc(co.intro || '')}</textarea></div>
      <div style="font-size:11.5px;color:var(--text-3);line-height:1.7;padding-top:6px">
        信息仅用于招商顾问为您提供精准对接服务，完善后顾问可主动为您匹配套牌政策与载体资源。</div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="submit:myCompany">保存企业信息</button>
    </div>`);
}

function submitMyCompany() {
  const v = curVisitor();
  if (!v) return toast('登录状态已失效，请重新登录');
  const name = (($('#coName') || {}).value || '').trim();
  if (!name) return toast('请输入企业名称');
  v.company = {
    name,
    industry: (($('#coIndustry') || {}).value || '').trim(),
    product: (($('#coProduct') || {}).value || '').trim(),
    intro: (($('#coIntro') || {}).value || '').trim()
  };
  v.companyAt = fmtDateTime(new Date());
  Api.save();
  Cloud.pushRow('visitors', v);
  saveSession();
  closeSheet();
  toast('企业信息已保存');
  refresh();
}

function sheetMyNeeds() {
  const v = curVisitor();
  if (!ensureVisitor()) return;
  const needs = v.needs || [];
  openSheet(`
    <div class="sheet-head">
      <h3>我的需求</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      ${needs.length ? needs.map((n, i) => `
        <div class="menu-item" style="padding:12px 4px">
          <div style="flex:1;min-width:0">
            <div style="font-size:14px;font-weight:600">${esc(n.type)}${n.at ? `<span style="font-weight:400;color:var(--text-3);font-size:11px;margin-left:8px">${esc(n.at)}</span>` : ''}</div>
            <div style="font-size:12.5px;color:var(--text-2);margin-top:3px;white-space:pre-wrap;word-break:break-all">${esc(n.desc || '')}</div>
          </div>
          <button class="btn sm ghost" style="color:var(--danger);flex:0 0 auto" type="button" data-act="del:myNeed" data-v="${i}">删除</button>
        </div>`).join('')
      : '<div class="empty">还没有登记需求，填写后招商顾问会主动与您对接</div>'}
      <div style="height:6px"></div>
      <div class="field"><label>需求类型<span class="req">*</span></label>
        <select id="ndType">
          ${NEED_TYPE_OPTS.map(o => `<option value="${o}">${o}</option>`).join('')}
        </select></div>
      <div class="field"><label>需求描述<span class="req">*</span></label>
        <textarea id="ndDesc" maxlength="300" placeholder="如：需要松山湖 200㎡ 左右办公室，可尽快入驻，关注租金补贴政策">${''}</textarea></div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">关闭</button>
      <button class="btn" type="button" data-act="add:myNeed">添加需求</button>
    </div>`);
}

function addMyNeed() {
  const v = curVisitor();
  if (!v) return toast('登录状态已失效，请重新登录');
  const type = (($('#ndType') || {}).value || '').trim();
  const desc = (($('#ndDesc') || {}).value || '').trim();
  if (!type) return toast('请选择需求类型');
  if (!desc) return toast('请填写需求描述');
  v.needs = (v.needs || []).concat([{ nid: uid('N'), type, desc, at: fmtDateTime(new Date()) }]);
  Api.save();
  Cloud.pushRow('visitors', v);
  saveSession();
  toast('需求已登记');
  refresh();
  sheetMyNeeds(); // 刷新面板展示新列表
}

function delMyNeed(i) {
  const v = curVisitor();
  if (!v) return;
  v.needs = (v.needs || []).filter((_, k) => k !== Number(i));
  Api.save();
  Cloud.pushRow('visitors', v);
  saveSession();
  toast('已删除');
  refresh();
  sheetMyNeeds();
}

/* ---------------- 管理端动作 ---------------- */
function adminLogin() {
  const u = (($('#admUser') || {}).value || '').trim();
  const p = (($('#admPwd') || {}).value || '').trim();
  if (!u) return toast('请输入管理员账号');
  if (!p) return toast('请输入登录密码');
  const a = Api.db.admins.find(x => x.username === u);
  if (!a || a.password !== p) return toast('账号或密码错误');
  if (!a.enabled) return toast('该账号已被停用');
  a.lastLogin = fmtDateTime(new Date());
  Api.save();
  State.session.admin = { id: a.id, username: a.username, name: a.name, role: a.role };
  saveSession();
  State.adminTab = 'listing';
  toast('登录成功');
  setView('admin', false);
  /* 登录后静默把历史 base64 照片搬到服务器，释放本机空间 */
  migratePhotosToServer().catch(e => console.warn('照片迁移跳过', e));
}

function listingFormHTML(l) {
  const d = l || {
    parkName: parksAll()[0].name, building: '', floor: '', area: '', orientation: OPT_ORIENT[0],
    decoration: '精装修', layout: '3+1', rent: '', propertyFee: '', contact: CONTACTS[0].name,
    phone: CONTACTS[0].phone, address: parksAll()[0].addr, desc: '', status: 'online', usage: '写字楼'
  };
  State.form.photos = (d.photos || []).slice(0, 3);
  State.form.replaceIdx = -1;
  /* 照片是否被本次编辑改动过：没动过就不覆盖云端大图，避免误删照片 */
  State.form.photosTouched = false;
  State.form.editId = l ? l.id : null;
  return `
    <div class="sheet-head">
      <h3>${l ? '编辑房源' : '新增房源'}</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div class="form-title">基础信息</div>
      <div class="field"><label>业态<span class="req">*</span></label>
        <select id="fUsage">
          ${['写字楼', '厂房'].map(o => `<option ${((d.usage || '写字楼')) === o ? 'selected' : ''}>${o}</option>`).join('')}
        </select>
      </div>
      <div class="field"><label>园区名称<span class="req">*</span></label>
        <select id="fPark">
          ${parksAll().map(p => `<option value="${esc(p.name)}" ${d.parkName === p.name ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}
        </select>
      </div>
      <div class="field-row">
        <div class="field"><label>楼栋 / 座<span class="req">*</span></label><input type="text" id="fBuilding" value="${esc(d.building)}" placeholder="如 A 栋"></div>
        <div class="field"><label>楼层<span class="req">*</span></label><input type="text" id="fFloor" value="${esc(d.floor)}" placeholder="如 12F/18F"></div>
      </div>
      <div class="field-row">
        <div class="field"><label>面积（㎡）<span class="req">*</span></label><input type="number" id="fArea" value="${esc(d.area)}" placeholder="如 320"></div>
        <div class="field"><label>朝向<span class="req">*</span></label>
          <select id="fOrientation">${OPT_ORIENT.map(o => `<option ${d.orientation === o ? 'selected' : ''}>${o}</option>`).join('')}</select>
        </div>
      </div>
      <div class="field-row">
        <div class="field"><label>装修<span class="req">*</span></label>
          <select id="fDecoration">${OPT_DECO.map(o => `<option ${d.decoration === o ? 'selected' : ''}>${o}</option>`).join('')}</select>
        </div>
        <div class="field"><label>格局<span class="req">*</span></label>
          <select id="fLayout">${OPT_LAYOUT.map(o => `<option ${d.layout === o ? 'selected' : ''}>${o}</option>`).join('')}</select>
        </div>
      </div>
      <div class="field-row">
        <div class="field"><label>租金（元/㎡·月）<span class="req">*</span></label><input type="number" id="fRent" value="${esc(d.rent)}" placeholder="如 68"></div>
        <div class="field"><label>物业费（元/㎡·月）<span class="req">*</span></label><input type="number" id="fPropertyFee" value="${esc(d.propertyFee)}" placeholder="如 16"></div>
      </div>
      <div class="field"><label>详细地址</label><input type="text" id="fAddress" value="${esc(d.address)}" placeholder="园区详细地址"></div>
      <div class="field">
        <label>精准定位 <span style="color:var(--text-3);font-weight:400">（在线地图选点，用于地图页房源标记）</span></label>
        <div class="loc-row">
          <input type="text" id="fLatLng" readonly value="${d.lat && d.lng ? (+d.lat).toFixed(6) + ', ' + (+d.lng).toFixed(6) : ''}" placeholder="未定位（可选）">
          <button class="op-btn" type="button" data-act="pick:loc">地图选点</button>
          <button class="op-btn" type="button" data-act="pick:parkLoc">用园区坐标</button>
        </div>
        <input type="hidden" id="fLat" value="${d.lat || ''}">
        <input type="hidden" id="fLng" value="${d.lng || ''}">
        <div class="loc-hint" id="locHint">${d.lat && d.lng ? '已定位，地图页会按此坐标显示该房源标记' : '未定位的房源在地图页按园区大致位置展示'}</div>
      </div>

      <div class="form-title">房源照片（4:3，最多 3 张）</div>
      <div class="upload-grid" id="uploadGrid"></div>
      <input type="file" id="photoInput" accept="image/*" style="display:none">
      <div style="font-size:11px;color:var(--text-3);margin-top:7px;line-height:1.6">
        建议尺寸 1200×900（4:3）。未上传照片时系统自动生成示意图占位。
      </div>

      <div class="form-title">联系方式与介绍</div>
      <div class="field-row">
        <div class="field"><label>联系人<span class="req">*</span></label><input type="text" id="fContact" value="${esc(d.contact)}" placeholder="如 李经理"></div>
        <div class="field"><label>联系电话<span class="req">*</span></label><input type="tel" id="fPhone" value="${esc(d.phone)}" placeholder="手机号"></div>
      </div>
      <div class="field"><label>房源介绍</label><textarea id="fDesc" placeholder="房源亮点、配套、交通、政策等">${esc(d.desc)}</textarea></div>
      <div class="field"><label>推荐标签 <span style="color:var(--text-3);font-weight:400">（人工设置，列表页展示）</span></label>
        <div class="seg" id="fTag">
          ${['', '特价', '热门', '新上'].map(t => `<button type="button" class="${(d.tag || '') === t ? 'on' : ''}" data-v="${t}">${t || '无标签'}</button>`).join('')}
        </div>
      </div>
      <div class="field"><label>上架状态</label>
        <div class="seg" id="fStatus">
          <button type="button" class="${d.status === 'online' ? 'on' : ''}" data-v="online">立即上架</button>
          <button type="button" class="${d.status === 'offline' ? 'on' : ''}" data-v="offline">暂不上架</button>
        </div>
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="admin:save" data-id="${l ? l.id : ''}">${l ? '保存修改' : '创建房源'}</button>
    </div>`;
}

function bindListingForm() {
  renderUploadGrid();
  const segBind = (sel, def) => {
    const el = $(sel);
    if (el) el.onclick = e => {
      const b = e.target.closest('button');
      if (!b) return;
      $$(sel + ' button').forEach(x => x.classList.remove('on'));
      b.classList.add('on');
    };
  };
  segBind('#fStatus');
  segBind('#fTag');
  const inp = $('#photoInput');
  if (inp) inp.onchange = e => { readPhoto(e.target); inp.value = ''; };
}

function renderUploadGrid() {
  const g = $('#uploadGrid');
  if (!g) return;
  const ph = State.form.photos;
  g.innerHTML = ph.map((src, i) => `
    <div class="upload-cell">
      <img src="${photoURL(src)}" alt="">
      <span class="chg" data-act="admin:chgPhoto" data-i="${i}">更换</span>
      <span class="del" data-act="admin:rmPhoto" data-i="${i}">✕</span>
    </div>`).join('') + (ph.length < 3 ? `
    <div class="upload-cell" data-act="admin:addPhoto">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>
      添加照片
    </div>` : '');
}

/* 表单里的照片既可能是刚选的 data URL（还没上传），也可能是已上传的服务器地址；
   表单内已有服务器地址时说明本次照片已改动，需要落盘 */
function formHasUploaded() {
  return (State.form.photos || []).some(p => /^\/api\/photo\//.test(p));
}

/* 把表单里的照片提交到服务器独立存储（不再塞进 localStorage，解决手机空间不足） */
async function uploadFormPhotos(listingId) {
  const prev = (findListing(listingId) || {}).photos || [];
  const out = [];
  for (let i = 0; i < State.form.photos.length; i++) {
    const p = State.form.photos[i];
    if (/^\/api\/photo\//.test(p)) { out.push(p); continue; }
    if (!/^data:image\//.test(p)) { out.push(p); continue; }
    try {
      const blob = await (await fetch(p)).blob();
      const r = await fetch('/api/photo/' + encodeURIComponent(listingId) + '/' + i + '?t=' + Date.now(), {
        method: 'POST',
        headers: { 'Content-Type': blob.type || 'image/jpeg' },
        body: blob
      });
      const j = await r.json();
      out.push(j && j.url ? j.url : '');
    } catch (e) {
      console.warn('照片上传失败', e);
      out.push('');
    }
  }
  const clean = out.filter(Boolean);
  /* 全部上传失败时保留原有照片，绝不清空 */
  if (!clean.length && prev.length) return prev.slice(0, 3);
  return clean.slice(0, 3);
}

/* 读取照片：addPhoto 追加，chgPhoto 替换指定位置（第一张即封面）
   压缩后先只留在表单里（data URL），点保存时才上传到服务器 */
function readPhoto(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!/^image\//.test(file.type)) return toast('请选择图片文件');
  const replaceIdx = State.form.replaceIdx;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const maxW = 1200;
      const scale = Math.min(1, maxW / img.width);
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const cv = document.createElement('canvas');
      cv.width = w; cv.height = h;
      const ctx = cv.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);
      let q = 0.78, out = cv.toDataURL('image/jpeg', q);
      while (out.length > 420000 && q > 0.32) { q -= 0.12; out = cv.toDataURL('image/jpeg', q); }
      if (replaceIdx >= 0 && replaceIdx < State.form.photos.length) State.form.photos[replaceIdx] = out;
      else State.form.photos.push(out);
      State.form.replaceIdx = -1;
      State.form.photosTouched = true;
      renderUploadGrid();
      toast(replaceIdx >= 0 ? '已更换照片' : '已添加照片');
    };
    img.onerror = () => toast('图片解析失败');
    img.src = reader.result;
  };
  reader.onerror = () => toast('图片读取失败');
  reader.readAsDataURL(file);
}

function saveListing(id) {
  return doSaveListing(id).catch(e => {
    console.warn('保存房源失败', e);
    setSavingPhotos(false);
    toast('保存失败，请重试');
  });
}

/* 保存过程中禁用按钮，避免照片还没传完就重复提交 */
function setSavingPhotos(on) {
  const el = document.querySelector('[data-act="admin:save"]');
  if (!el) return;
  const orig = el.dataset.origText || (el.dataset.origText = el.textContent.trim());
  el.disabled = !!on;
  el.style.opacity = on ? '0.6' : '';
  el.textContent = on ? '上传照片中…' : orig;
}

async function doSaveListing(id) {
  const g = k => { const e = $('#' + k); return e ? e.value.trim() : ''; };
  const parkName = g('fPark'), building = g('fBuilding'), floor = g('fFloor');
  const area = num(g('fArea')), rent = num(g('fRent')), propertyFee = num(g('fPropertyFee'));
  const statusEl = $('#fStatus .on');
  const status = statusEl ? statusEl.dataset.v : 'online';
  const tagEl = $('#fTag .on');
  const tag = tagEl ? (tagEl.dataset.v || '') : '';
  if (!building) return toast('请填写楼栋');
  if (!floor) return toast('请填写楼层');
  if (!area) return toast('请填写面积');
  if (!rent) return toast('请填写租金');
  if (!propertyFee) return toast('请填写物业费');
  const contact = g('fContact'), phone = g('fPhone');
  if (!contact) return toast('请填写联系人');
  if (!/^1[3-9]\d{9}$/.test(phone) && !/^0\d{2,3}-?\d{7,8}$/.test(phone)) return toast('请填写正确的联系电话');

  const park = parksAll().find(p => p.name === parkName) || parksAll()[0];
  const seedIdx = Api.db.listings.length % PHOTO_SETS.length;
  const prev = id ? findListing(id) : null;

  /* 新增房源先定 id，照片才能按 id 存到服务器独立目录 */
  const newId = id || uid('L');
  const touched = State.form.photosTouched;

  /* 照片落盘策略：
     ① 表单里有照片 → 上传到服务器（返回 /api/photo/... 地址），本机只留地址不存 base64
     ② 编辑且表单为空 → 保留原有照片（照片没加载完/被用户清空时绝不用演示图覆盖）
     ③ 新增且没传图 → 用演示图占位（只存短标记，渲染时展开，不占本机空间）
     上传过程失败会返回原有照片，保证不会出现照片被清空的意外 */
  const demoSet = () => PHOTO_SETS[seedIdx].map((t, k) => demoPhoto(t, seedIdx + k));
  let photos, demoPhotos;
  if (State.form.photos.length || touched) {
    if (typeof uploadFormPhotos === 'function') setSavingPhotos(true);
    photos = await uploadFormPhotos(newId).finally(() => setSavingPhotos(false));
    demoPhotos = false;
    if (!photos.length) {
      photos = (prev && (prev.photos || []).length) ? prev.photos.slice(0, 3) : demoSet();
      demoPhotos = !(prev && (prev.photos || []).length);
    }
  } else {
    photos = (prev && (prev.photos || []).length) ? prev.photos.slice(0, 3) : demoSet();
    demoPhotos = !(prev && (prev.photos || []).length);
  }
  /* 表单里的照片如果本身就是演示图（用户没换图），保持演示标记，避免展开成大图存回去 */
  if (!State.form.photosTouched && prev && prev.demoPhotos) { photos = prev.photos.slice(0, 3); demoPhotos = true; }

  const payload = {
    parkName, building, floor, area, rent, propertyFee,
    usage: (g('fUsage') === '厂房' ? '厂房' : '写字楼'),
    orientation: g('fOrientation'), decoration: g('fDecoration'), layout: g('fLayout'),
    address: g('fAddress') || park.addr, contact, phone, desc: g('fDesc'), status, tag, photos,
    demoPhotos,
    /* 照片完整性标记：只有确认手里是完整照片组时才允许覆盖云端照片大图。
       照片已改存服务器，本机不再保留 base64，photosLoaded 仅作历史兼容标记 */
    photosLoaded: id ? (touched || !!(prev && prev.photosLoaded)) : true,
    coord: { x: park.x, y: park.y },
    /* 精准定位（可选）：在线地图选点得到的 GCJ-02 经纬度 */
    lat: round6(num(g('fLat'))), lng: round6(num(g('fLng'))),
    updatedAt: new Date().toISOString()
  };

  if (id) {
    const l = findListing(id);
    if (!l) return toast('房源不存在');
    Object.assign(l, payload);
    Api.save();
    Cloud.pushRow('listings', l);
    toast('房源已保存' + (netOk() ? '，已同步到云端' : '，联网后自动同步'));
  } else {
    const nl = Object.assign({
      id: newId, views: 0, createdAt: new Date().toISOString(),
      __local: true   /* 本机新建：允许回推云端（其他设备的历史缓存不会被回推） */
    }, payload);
    Api.db.listings.unshift(nl);
    Api.save();
    Cloud.pushRow('listings', nl);
    toast('房源创建成功' + (netOk() ? '，已同步到云端' : '，联网后自动同步'));
  }
  closeSheet();
  if (State.view === 'admin') {
    const body = $('#adminBody');
    if (body) body.innerHTML = State.adminTab === 'listing' ? adminListingBody() : renderAdminBody();
  }
  if (State.view === 'home' || State.view === 'map') refresh();
}

function netOk() { return typeof navigator === 'undefined' || navigator.onLine !== false; }

/* ---------------- 房源精准定位（在线地图选点） ----------------
   使用腾讯位置服务 GL JS 选点，得到 GCJ-02 经纬度后存到房源 lat/lng。
   未配置 Key 时不阻断流程，仅提示到后台配置。 */
const PICK = { map: null, marker: null, lat: 0, lng: 0 };

function sheetPickLoc() {
  if (!MapKit.has()) {
    dialog({
      title: '需要先配置在线地图',
      text: '精准定位使用腾讯位置服务在线地图。请到「管理后台 → 登录验证与分享」填入腾讯位置服务 Key（lbs.qq.com 免费申请，并把本站域名加入白名单）。未配置时房源仍按所属园区位置展示，不影响其他功能。',
      okText: '知道了', onOk: () => { }
    });
    return;
  }
  const a = $('#fLat'), b = $('#fLng');
  PICK.lat = a ? num(a.value) : 0;
  PICK.lng = b ? num(b.value) : 0;
  openSheet(`
    <div class="sheet-head">
      <h3>地图选点</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div class="pick-search">
        <input type="text" id="pickKw" placeholder="搜索园区 / 地址，如 光大We谷">
        <button class="op-btn pri" type="button" data-act="pick:search">搜索</button>
      </div>
      <div class="pick-results" id="pickResults"></div>
      <div class="pick-map" id="pickMap"></div>
      <div class="pick-coord" id="pickCoord">${PICK.lat ? PICK.lat.toFixed(6) + ', ' + PICK.lng.toFixed(6) : '点击地图选点'}</div>
      <div class="pick-tip">直接点击底图即可选点；选好后点「使用该位置」保存到本套房源。</div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="pick:ok">使用该位置</button>
    </div>`);
  MapKit.load().then(ok => { if (ok) mountPickMap(); });
}

function mountPickMap() {
  const el = $('#pickMap');
  if (!el) return;
  try {
    const T = MapKit.T;
    const c = MapKit.center();
    const pn = (($('#fPark') || {}).value) || '';
    const p = parksAll().find(x => x.name === pn);
    let fresh = false;
    if (!PICK.lat && p && p.lat && p.lon) { PICK.lat = p.lat; PICK.lng = p.lon; }
    if (!PICK.lat) { PICK.lat = c.lat; PICK.lng = c.lng; fresh = true; }
    const map = new T.Map(el, { center: new T.LatLng(PICK.lat, PICK.lng), zoom: fresh ? 13 : 16 });
    const mk = new T.MultiMarker({
      map,
      styles: { default: new T.MarkerStyle({ width: 30, height: 38 }) },
      geometries: [{ id: 'pick', styleId: 'default', position: new T.LatLng(PICK.lat, PICK.lng) }]
    });
    PICK.map = map; PICK.marker = mk;
    map.on('click', evt => {
      const ll = evt.latLng;
      if (!ll) return;
      setPickPoint(ll.getLat(), ll.getLng());
      try { mk.updateGeometries([{ id: 'pick', styleId: 'default', position: ll }]); } catch (e) { }
    });
  } catch (e) {
    console.warn('选点地图初始化失败', e);
    const el2 = $('#pickMap');
    if (el2) el2.innerHTML = '<div class="pick-err">地图加载失败，请检查 Key 是否已开通「WebServiceAPI / JS API」并加入本站域名白名单</div>';
  }
}

function setPickPoint(lat, lng) {
  PICK.lat = +(+lat).toFixed(6);
  PICK.lng = +(+lng).toFixed(6);
  const c = $('#pickCoord');
  if (c) c.textContent = PICK.lat.toFixed(6) + ', ' + PICK.lng.toFixed(6);
}

function pickSearch() {
  const kwEl = $('#pickKw');
  const kw = kwEl ? kwEl.value.trim() : '';
  const box = $('#pickResults');
  if (!kw) return toast('请输入要搜索的地点');
  const tip = html => { if (box) box.innerHTML = `<div class="pick-err">${html}</div>`; };
  try {
    const T = MapKit.T;
    if (!T || !T.service || !T.service.Suggestion) return tip('当前地图未开通搜索能力，请直接在地图上点选');
    const sug = new T.service.Suggestion({ pageSize: 6, region: '东莞' });
    sug.getSuggestions({ keyword: kw }).then(res => {
      const raw = res && (res.data || res.result || res.pois);
      const list = Array.isArray(raw) ? raw.slice(0, 6) : [];
      if (!list.length) return tip('没有找到「' + esc(kw) + '」，换个关键词或直接点地图选点');
      box.innerHTML = list.map((it, i) => {
        const loc = it.location || it.latLng || {};
        return `<button class="pick-item" type="button" data-act="pick:item" data-lat="${loc.lat || ''}" data-lng="${loc.lng || ''}">
          <b>${esc(it.title || it.name || '')}</b><span>${esc(it.address || '')}</span></button>`;
      }).join('');
    }).catch(() => tip('搜索失败，请直接在地图上点选'));
  } catch (e) {
    tip('搜索不可用，请直接在地图上点选');
  }
}

function pickItem(btn) {
  const lat = num(btn.dataset.lat), lng = num(btn.dataset.lng);
  if (!lat || !lng) return toast('该结果没有坐标，请在地图上点选');
  setPickPoint(lat, lng);
  if (PICK.map) {
    PICK.map.setCenter(new MapKit.T.LatLng(lat, lng));
    PICK.map.setZoom(16);
  }
  try { PICK.marker.updateGeometries([{ id: 'pick', styleId: 'default', position: new MapKit.T.LatLng(lat, lng) }]); } catch (e) { }
}

function applyPickLoc() {
  if (!PICK.lat || !PICK.lng) return toast('请先在地图上选点');
  const a = $('#fLat'), b = $('#fLng'), t = $('#fLatLng'), h = $('#locHint');
  if (a) a.value = String(PICK.lat);
  if (b) b.value = String(PICK.lng);
  if (t) t.value = PICK.lat.toFixed(6) + ', ' + PICK.lng.toFixed(6);
  if (h) h.textContent = '已定位，地图页会按此坐标显示该房源标记';
  closeSheet();
  toast('已记录精准位置');
}

function useParkLoc() {
  const pn = (($('#fPark') || {}).value) || '';
  const p = parksAll().find(x => x.name === pn);
  if (!p || !p.lat || !p.lon) return toast('该园区暂无经纬度，请用「地图选点」手动定位');
  const a = $('#fLat'), b = $('#fLng'), t = $('#fLatLng'), h = $('#locHint');
  if (a) a.value = String(p.lat);
  if (b) b.value = String(p.lon);
  if (t) t.value = (+p.lat).toFixed(6) + ', ' + (+p.lon).toFixed(6);
  if (h) h.textContent = '已按园区坐标定位，可再用「地图选点」精调';
  toast('已填入「' + pn + '」园区坐标');
}

function renderAdminBody() {
  return State.adminTab === 'listing' ? adminListingBody()
    : State.adminTab === 'message' ? adminMessageBody()
      : State.adminTab === 'dashboard' ? adminDashboardBody()
        : State.adminTab === 'map' ? adminMapBody()
          : State.adminTab === 'parks' ? adminParksBody() : adminSystemBody();
}

/* ---------------- 管理后台 · 园区管理 ---------------- */
function adminParksBody() {
  const parks = parksAll();
  return `
  <div class="notice-bar">
    <span>ℹ️</span>
    <span>园区列表会同步到房源表单、地图找房和筛选器。填写经纬度（GCJ-02，如从腾讯地图获取）会自动定位到底图；也可在「地图标注」里拖动微调。</span>
  </div>
  <div class="chart-card" style="margin-top:12px">
    <h3>产业园区 <small>${parks.length} 个</small></h3>
    <div style="margin:0 -14px">
      ${parks.map(p => {
        const cnt = Api.db.listings.filter(l => l.parkName === p.name).length;
        const cc = Api.parkCoord(p.name);
        return `
        <div class="admin-row">
          <div class="admin-avatar" style="background:var(--primary-l);color:var(--primary)">${esc(p.name.replace('松山湖', '').slice(0, 1) || '园')}</div>
          <div class="admin-info">
            <div class="admin-uname">${esc(p.name)}
              <span class="role-chip" style="background:#EEF1F6;color:var(--text-3)">${cnt} 套房源</span>
              ${cc.custom ? '<span class="role-chip">已校准</span>' : (p.precise ? '<span class="role-chip" style="background:var(--success-l);color:var(--success)">精确坐标</span>' : '<span class="role-chip" style="background:#FFF3E4;color:#D97706">估算坐标</span>')}
            </div>
            <div class="admin-meta">${esc(p.addr || '未填地址')}</div>
            <div class="admin-meta">经纬度 ${p.lat && p.lon ? p.lat + ', ' + p.lon : '未填'} · 底图位置 ${cc.x}, ${cc.y}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;flex:0 0 auto">
            <button class="op-btn on" type="button" data-act="admin:editPark" data-v="${esc(p.name)}">编辑</button>
            <button class="op-btn del" type="button" data-act="admin:delPark" data-v="${esc(p.name)}" ${cnt > 0 ? 'disabled style="opacity:.4"' : ''}>删除</button>
          </div>
        </div>`;
      }).join('')}
    </div>
    <button class="btn" style="margin-top:14px" type="button" data-act="admin:newPark">+ 新增园区</button>
  </div>
  <div style="height:10px"></div>`;
}

function parkFormSheet(name) {
  const p = name ? Api.park(name) : null;
  openSheet(`
    <div class="sheet-head">
      <h3>${p ? '编辑园区' : '新增园区'}</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div class="field"><label>园区名称<span class="req">*</span></label>
        <input type="text" id="pName" value="${esc(p ? p.name : '')}" placeholder="如 松山湖XX产业园"></div>
      <div class="field"><label>详细地址</label>
        <input type="text" id="pAddr" value="${esc(p ? p.addr : '')}" placeholder="如 松山湖园区XX路X号"></div>
      <div class="field-row">
        <div class="field"><label>纬度</label>
          <input type="text" id="pLat" value="${p && p.lat ? p.lat : ''}" placeholder="22.9xxxxx"></div>
        <div class="field"><label>经度</label>
          <input type="text" id="pLon" value="${p && p.lon ? p.lon : ''}" placeholder="113.8xxxxx"></div>
      </div>
      <div style="font-size:11.5px;color:var(--text-3);line-height:1.7;margin-top:4px">
        经纬度可在腾讯地图（map.qq.com）上右键目标位置获取，坐标系为 GCJ-02。填写后自动定位到底图；不填则默认在图中央，可在「地图标注」里拖动。
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="admin:savePark" data-id="${esc(p ? p.name : '')}">${p ? '保存修改' : '创建园区'}</button>
    </div>`);
}

function saveParkSheet(oldName) {
  const g = k => { const e = $('#' + k); return e ? e.value.trim() : ''; };
  const o = { name: g('pName'), addr: g('pAddr'), lat: g('pLat'), lon: g('pLon') };
  const r = oldName ? Api.updatePark(oldName, o) : Api.addPark(o);
  if (!r.ok) return toast(r.msg);
  closeSheet();
  toast(oldName ? '园区已保存，房源与地图已同步' : '园区已创建');
  State.adminTab = 'parks';
  setView('admin', false);
}

function adminReplySheet(mid) {
  const m = Api.db.messages.find(x => x.id === mid);
  if (!m) return;
  const l = findListing(m.listingId);
  openSheet(`
    <div class="sheet-head">
      <h3>回复访客留言</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div style="background:#F7FAFF;border-radius:10px;padding:11px;font-size:12.5px;line-height:1.7;color:var(--text-2)">
        <b style="color:var(--text)">${esc(m.name)} · ${esc(m.phone)}</b><br>
        ${l ? esc(l.parkName + ' · ' + l.building) : '房源已删除'} · ${esc(m.createdAt)}<br>
        <span style="color:var(--text)">【${esc(m.type)}】${esc(m.content)}</span>
      </div>
      <div class="field"><label>回复内容<span class="req">*</span></label>
        <textarea id="replyText" placeholder="请输入回复内容">${esc(m.reply || '')}</textarea></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${['您好，房源仍在租，可以安排带看，请问您方便的时间？',
      '已为您预留房源，稍后招商顾问将电话与您确认细节。',
      '该房源支持分租，具体价格可根据租赁年限协商。'].map(t =>
        `<button class="op-btn" type="button" data-act="reply:quick" data-v="${esc(t)}">快捷语</button>`).join('')}
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="admin:doReply" data-id="${mid}">发送回复</button>
    </div>`);
  const box = $('#replyText');
  if (box) box.focus();
}

function newAdminSheet() {
  const db = Api.db;
  if (db.admins.length >= db.settings.maxAdmins) {
    return dialog({
      title: '已达管理员上限',
      text: `当前管理员数量已达上限 ${db.settings.maxAdmins} 人，请先在「设置」中调整上限或删除已有管理员账号。`,
      cancelText: ''
    });
  }
  openSheet(`
    <div class="sheet-head"><h3>新增管理员</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body">
      <div class="field"><label>姓名 / 备注<span class="req">*</span></label><input type="text" id="naName" placeholder="如 招商部 · 黄小姐"></div>
      <div class="field"><label>登录账号<span class="req">*</span></label><input type="text" id="naUser" placeholder="英文或数字，用于登录"></div>
      <div class="field"><label>登录密码<span class="req">*</span></label><input type="text" id="naPwd" placeholder="至少 6 位，创建后可在后台修改" autocomplete="new-password"></div>
      <div class="field"><label>手机号</label><input type="tel" id="naPhone" placeholder="选填"></div>
      <div class="notice-bar" style="margin:8px 0 0">
        <span>ℹ️</span><span>新增管理员拥有房源上下架与留言处理权限，但不能管理其他管理员账号。上限 ${db.settings.maxAdmins} 人，当前 ${db.admins.length} 人。</span>
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="admin:doNewAdmin">创建账号</button>
    </div>`);
}

function sheetResetPwd(id) {
  const a = Api.db.admins.find(x => x.id === id);
  if (!a) return toast('账号不存在');
  openSheet(`
    <div class="sheet-head"><h3>修改密码 · ${esc(a.name)}</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body">
      <div class="field"><label>新密码<span class="req">*</span></label><input type="password" id="rpPwd" placeholder="至少 6 位" autocomplete="new-password"></div>
      <div class="field"><label>确认新密码<span class="req">*</span></label><input type="password" id="rpPwd2" placeholder="再输入一次" autocomplete="new-password"></div>
      <div class="notice-bar" style="margin:8px 0 0"><span>ℹ️</span><span>修改后该账号下次登录需使用新密码。</span></div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="close:sheet">取消</button>
      <button class="btn" type="button" data-act="admin:doResetPwd" data-id="${id}">确认修改</button>
    </div>`);
}

function doResetPwd(id) {
  const p = (($('#rpPwd') || {}).value || '').trim();
  const p2 = (($('#rpPwd2') || {}).value || '').trim();
  if (p.length < 6) return toast('密码至少 6 位');
  if (p !== p2) return toast('两次输入的密码不一致');
  const a = Api.db.admins.find(x => x.id === id);
  if (!a) return toast('账号不存在');
  a.password = p;
  Api.save();
  /* 记入待同步并立即上云：管理员账号原来只存本机，会被其他设备的旧设置覆盖 */
  Cloud.markDirty('admins', a.id);
  Cloud.pushAdmins();
  closeSheet();
  toast('密码已更新，请妥善保管');
}

function doNewAdmin() {
  const db = Api.db;
  const name = (($('#naName') || {}).value || '').trim();
  const username = (($('#naUser') || {}).value || '').trim();
  const password = (($('#naPwd') || {}).value || '').trim();
  const phone = (($('#naPhone') || {}).value || '').trim();
  if (!name) return toast('请填写姓名 / 备注');
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return toast('账号需为 3-16 位英文、数字或下划线');
  if (password.length < 6) return toast('密码至少 6 位');
  if (db.admins.some(a => a.username === username)) return toast('该账号已存在');
  if (db.admins.length >= db.settings.maxAdmins) return toast('已达管理员数量上限');
  db.admins.push({
    id: uid('A'), username, password, name, phone, role: 'admin', enabled: true,
    createdAt: fmtDateTime(new Date()), lastLogin: ''
  });
  Api.save();
  /* 新账号要同步到云端，否则任何一次合并都会把它冲掉（其他设备登录也看不到） */
  Cloud.markDirty('admins', db.admins[db.admins.length - 1].id);
  Cloud.pushAdmins();
  closeSheet();
  toast('管理员「' + name + '」创建成功');
  const body = $('#adminBody');
  if (body) body.innerHTML = renderAdminBody();
}

/* ---------------- CSV 导出 ---------------- */
function downloadCSV(filename, rows) {
  const csv = '\ufeff' + rows.map(r => r.map(c => {
    const s = String(c == null ? '' : c).replace(/"/g, '""');
    return /[",\n]/.test(s) ? '"' + s + '"' : s;
  }).join(',')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 600);
  toast('已导出 ' + filename);
}

function exportListings() {
  const rows = [['房源编号', '园区名称', '楼栋', '楼层', '面积(㎡)', '朝向', '装修', '格局', '租金(元/㎡·月)', '物业费(元/㎡·月)', '状态', '浏览量', '联系人', '联系电话', '挂牌时间']];
  Api.db.listings.forEach(l => rows.push([l.id, l.parkName, l.building, l.floor, l.area, l.orientation,
    l.decoration, l.layout, l.rent, l.propertyFee, l.status === 'online' ? '在租' : '已下架',
    l.views, l.contact, l.phone, fmtDate(new Date(l.createdAt))]));
  downloadCSV('松山湖房源清单_' + today() + '.csv', rows);
}

function exportVisitors() {
  const rows = [['留言编号', '称呼', '手机号', '咨询类型', '关联房源', '留言内容', '留言时间', '处理状态', '回复内容']];
  Api.db.messages.forEach(m => {
    const l = findListing(m.listingId);
    rows.push([m.id, m.name, m.phone, m.type, l ? l.parkName + ' ' + l.building : '已删除',
      m.content, m.createdAt, m.status === 'pending' ? '待回复' : '已回复', m.reply || '']);
  });
  rows.push([]);
  rows.push(['登记访客', '称呼', '手机号', '首次访问时间', '访问次数']);
  Api.db.visitors.forEach(v => rows.push([v.id, v.nick, v.phone, v.createdAt, v.visits || 1]));
  rows.push([]);
  rows.push(['近 7 日访客趋势', '日期', '访客数']);
  Api.db.visitLog.slice(-7).forEach(v => rows.push(['', v.d, v.v]));
  rows.push([]);
  rows.push(['汇总', '累计访客', Api.db.stats.visitors, '累计浏览', Api.db.stats.views,
    '房源总数', Api.db.listings.length, '留言总数', Api.db.messages.length]);
  downloadCSV('松山湖访客与留言数据_' + today() + '.csv', rows);
}

/* ---------------- 弹层选择器 ---------------- */
function sheetFilter() {
  const f = State.filters;
  const chipRow = (key, opts, labelMap) => `
    <div class="field"><label>${labelMap}</label>
      <div class="seg" data-filter="${key}">
        ${opts.map(o => `<button type="button" class="${f[key] === o ? 'on' : ''}" data-v="${esc(o)}">${esc(o === '全部' ? '不限' : o + (key === 'area' || key === 'rent' ? ' 元' : ''))}</button>`).join('')}
      </div>
    </div>`;
  openSheet(`
    <div class="sheet-head"><h3>筛选房源</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body">
      <div class="field"><label>园区</label>
        <div class="seg" data-filter="park">
          ${['全部'].concat(parksAll().map(p => p.name)).map(o =>
    `<button type="button" class="${f.park === o ? 'on' : ''}" data-v="${esc(o)}">${esc(o === '全部' ? '不限' : o)}</button>`).join('')}
        </div>
      </div>
      ${chipRow('rent', RENT_OPTS, '租金区间（元/㎡·月）')}
      ${chipRow('area', AREA_OPTS, '面积区间（㎡）')}
      ${chipRow('orientation', ['全部'].concat(OPT_ORIENT), '朝向')}
      ${chipRow('decoration', ['全部'].concat(OPT_DECO), '装修')}
      ${chipRow('layout', ['全部'].concat(OPT_LAYOUT), '格局')}
      <div class="field"><label>排序</label>
        <div class="seg" data-filter="sort">
          ${SORT_OPTS.map(s => `<button type="button" class="${f.sort === s.k ? 'on' : ''}" data-v="${s.k}">${s.t}</button>`).join('')}
        </div>
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" style="flex:0 0 96px" type="button" data-act="filters:reset">重置</button>
      <button class="btn" type="button" data-act="filters:apply">查看结果</button>
    </div>`);
}

function sheetSinglePicker(key, opts, title) {
  const f = State.filters;
  openSheet(`
    <div class="sheet-head"><h3>${esc(title)}</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body">
      <div class="seg" data-filter="${key}">
        ${opts.map(o => `<button type="button" class="${f[key] === o ? 'on' : ''}" data-v="${esc(o)}">${esc(o === '全部' ? '不限' : o)}</button>`).join('')}
      </div>
    </div>
    <div class="sheet-foot"><button class="btn" type="button" data-act="filters:apply">确定</button></div>`);
}

function sheetViewed() {
  const ids = State.session.viewed || [];
  const list = ids.map(findListing).filter(Boolean);
  openSheet(`
    <div class="sheet-head"><h3>浏览记录</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body">
      ${list.length ? list.map(l => `
        <div style="display:flex;gap:10px;padding:9px 0;border-bottom:1px solid var(--line)" data-act="open:listing" data-id="${l.id}">
          <img src="${photoURL(l.photos && l.photos[0])}" style="width:70px;height:53px;object-fit:cover;border-radius:8px;flex:0 0 70px">
          <div style="flex:1;min-width:0">
            <div style="font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(l.parkName)} · ${esc(l.building)}</div>
            <div style="font-size:11.5px;color:var(--text-3);margin-top:4px">${l.area}㎡ · ${esc(l.layout)} · ${l.rent} 元/㎡·月</div>
          </div>
        </div>`).join('') : '<div class="empty">暂无浏览记录</div>'}
    </div>`);
}

function sheetAbout() {
  openSheet(`
    <div class="sheet-head"><h3>关于平台</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button></div>
    <div class="sheet-body" style="padding-bottom:18px">
      <div style="background:linear-gradient(135deg,#1677FF,#4FA4FF);border-radius:12px;padding:16px;color:#fff">
        <div style="font-size:17px;font-weight:700">松山湖产业招商</div>
        <div style="font-size:12px;opacity:.9;margin-top:6px;line-height:1.7">
          覆盖松山湖高新区 12 个重点产业园，提供房源展示、在线咨询、预约看房与招商数据管理服务。
        </div>
      </div>
      <div style="font-size:13px;color:var(--text-2);line-height:2;margin-top:14px">
        <div>招商热线：${esc(Api.db.settings.hotline)}</div>
        <div>服务时间：周一至周六 9:00 - 18:00</div>
        <div>入驻服务：工商注册 · 政策申报 · 装修设计 · 人才招聘</div>
        <div style="margin-top:10px;font-size:11.5px;color:var(--text-3)">
          房源与访客数据已接入云端数据库，多设备实时同步。
        </div>
        <div style="margin-top:6px;font-size:11.5px;color:var(--text-3)">
          版本 v${APP_VER}${Cloud.ready ? ' · 云端已连接' : ' · 本地模式'} · 升级版本不改动房源/管理员等已有数据
        </div>
      </div>
    </div>`);
}

/* ============================================================
 * 微信分享 / 转发
 * ------------------------------------------------------------
 * 纯 H5 无法直接调起微信转发（需公众号 JS-SDK 且域名通过校验），
 * 因此这里提供三条可用路径：
 *   1) 复制带参数的链接（好友点开直接落到对应房源/园区）
 *   2) 生成分享海报（含二维码，长按即可发送给微信好友）
 *   3) 微信内右上角「···」引导层
 * 若已配置公众号 appId，WxShare.setup() 会自动接入原生分享。
 * ============================================================ */
const IS_WECHAT = /MicroMessenger/i.test(navigator.userAgent);
const IS_QQ = /\sQQ/i.test(navigator.userAgent) || /QQBrowser/i.test(navigator.userAgent);
/* 每次发布递增：分享链接自动带上 v=APP_VER，URL 变化可击穿微信 webview 的页面缓存 */
const APP_VER = '20261007c';

/* 唯一可信的分享域名。
 * 背景：曾用 location.origin 动态取域名，若页面从旧入口/失效域名打开，
 * 海报二维码和分享卡片就会编码成死链（扫码显示"链接已失效"）。
 * 现固定为正式发布域名：无论从哪个入口打开，分享出去的链接全部落在这里。 */
const SHARE_BASE = location.origin + ((window.__SITE_BACKEND__ || {}).basePath || '') + '/experience';

function shareLink(params) {
  const base = SHARE_BASE + '/';
  const p = Object.assign({ v: APP_VER }, params || {});
  const q = Object.keys(p)
    .filter(k => p[k] !== undefined && p[k] !== null && p[k] !== '')
    .map(k => k + '=' + encodeURIComponent(p[k])).join('&');
  return base + '?' + q;
}

function copyText(txt) {
  return new Promise(resolve => {
    const fb = () => {
      try {
        const ta = document.createElement('textarea');
        ta.value = txt; ta.style.position = 'fixed'; ta.style.top = '-1000px'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.focus(); ta.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        resolve(ok);
      } catch (e) { resolve(false); }
    };
    if (navigator.clipboard && /^https?:/.test(location.protocol)) {
      navigator.clipboard.writeText(txt).then(() => resolve(true)).catch(fb);
    } else fb();
  });
}

/* ---------- 二维码 ---------- */
/* 内部 3 倍超采样渲染 + 整数模块尺寸：手机高分屏下二维码清晰、模块不粘连，扫码成功率高 */
function qrCanvas(text, size) {
  const SS = 3;
  const px = Math.round(size * SS);
  const cv = document.createElement('canvas');
  cv.width = cv.height = px;
  const g = cv.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, px, px);
  try {
    const qr = qrcode(0, 'M');
    qr.addData(text);
    qr.make();
    const n = qr.getModuleCount();
    const pad = Math.round(px * 0.06);
    const cell = Math.max(1, Math.floor((px - pad * 2) / n));
    const off = Math.round((px - cell * n) / 2);
    g.fillStyle = '#16202E';
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (qr.isDark(r, c)) g.fillRect(off + c * cell, off + r * cell, cell, cell);
      }
    }
  } catch (e) { console.warn('二维码生成失败', e); }
  return cv;
}

function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}

const FONT = '"PingFang SC","Microsoft YaHei",sans-serif';
function fitText(g, text, maxW, base) {
  let s = base;
  while (s > 12) {
    g.font = `600 ${s}px ${FONT}`;
    if (g.measureText(text).width <= maxW) break;
    s -= 2;
  }
  return s;
}

function drawCover(g, im, x, y, w, h) {
  g.save();
  roundRect(g, x, y, w, h, 14); g.clip();
  if (!im || !im.width) {
    g.fillStyle = '#DCE6F2'; g.fillRect(x, y, w, h);
  } else {
    const s = Math.max(w / im.width, h / im.height);
    const dw = im.width * s, dh = im.height * s;
    g.drawImage(im, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  }
  g.restore();
}

/* 生成分享海报（返回 dataURL） */
/* 海报缓存：保存图片时用 canvas 原件生成 Blob，避免超长 data URL 被浏览器/微信拦截 */
const POSTER = { cv: null, blobUrl: null };

function revokePosterBlob() {
  try { if (POSTER.blobUrl) { URL.revokeObjectURL(POSTER.blobUrl); POSTER.blobUrl = null; } } catch (e) { }
}

function buildPoster(kind, l, done) {
  const W = 750, H = kind === 'site' ? 1240 : 1210;
  const cv = document.createElement('canvas');
  cv.width = W; cv.height = H;
  const g = cv.getContext('2d');
  g.fillStyle = '#EEF3F9'; g.fillRect(0, 0, W, H);
  roundRect(g, 22, 22, W - 44, H - 44, 26);
  g.fillStyle = '#fff'; g.fill();

  const url = kind === 'site' ? shareLink({ src: 'poster' }) : shareLink({ id: l.id, src: 'poster' });
  const coverSmall = kind === 'site'
    ? ((Api.db.settings.share && Api.db.settings.share.img) || 'assets/songshanhu-map.jpg')
    : photoURL((l.photos && l.photos[0]) || photoURI('facade', 0));

  const img = new Image();
  let called = false;
  function finish() {
    if (called) return; called = true;
    const im = img.complete && img.naturalWidth ? img : null;
    // 封面
    drawCover(g, im, 44, 44, W - 88, 430);

    if (kind === 'site') {
      const st = Api.db.settings.share || {};
      g.fillStyle = '#16202E';
      g.font = `700 ${fitText(g, st.title || '松山湖产业招商', W - 130, 40)}px ${FONT}`;
      g.fillText(st.title || '松山湖产业招商', 56, 540);
      g.fillStyle = '#6B7A8D';
      g.font = `400 24px ${FONT}`;
      g.fillText(st.desc || '12 个产业园 · 写字楼 / 厂房在租实盘 · 产业资源对接', 56, 582);
    } else {
      g.fillStyle = '#16202E';
      const t = l.parkName + ' · ' + l.building;
      g.font = `700 ${fitText(g, t, W - 130, 38)}px ${FONT}`;
      g.fillText(t, 56, 542);
      g.fillStyle = '#E8542B';
      g.font = `700 46px ${FONT}`;
      g.fillText(String(l.rent), 56, 604);
      g.fillStyle = '#16202E';
      g.font = `400 22px ${FONT}`;
      g.fillText('元/㎡·月', 56 + g.measureText(String(l.rent)).width + 82, 602);
      g.fillStyle = '#6B7A8D';
      g.font = `400 22px ${FONT}`;
      g.fillText(`物业费 ${l.propertyFee} 元/㎡·月 · 月租约 ¥${money(Math.round(l.area * (l.rent + l.propertyFee)))}`, 56, 644);
    }

    // 参数区
    const items = kind === 'site'
      ? [['覆盖园区', new Set(Api.db.listings.map(x => x.parkName)).size + ' 个'], ['在租房源', Api.db.listings.filter(x => x.status === 'online').length + ' 套'],
      ['热门面积', '100-800㎡'], ['招商热线', Api.db.settings.hotline]]
      : [['楼层', l.floor], ['面积', l.area + ' ㎡'], ['朝向', l.orientation],
      ['装修', l.decoration], ['格局', l.layout], ['物业费', l.propertyFee + ' 元/㎡·月']];
    const gy = kind === 'site' ? 640 : 700;
    items.forEach((it, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const bx = 56 + col * 320, by = gy + row * 78;
      g.fillStyle = '#F4F7FB';
      roundRect(g, bx, by, 300, 62, 12); g.fill();
      g.fillStyle = '#8794A6'; g.font = `400 21px ${FONT}`;
      g.fillText(it[0], bx + 18, by + 26);
      g.fillStyle = '#16202E'; g.font = `600 ${fitText(g, String(it[1]), 170, 24)}px ${FONT}`;
      g.fillText(String(it[1]), bx + 18, by + 52);
    });

    const qy = kind === 'site' ? 1000 : 966;
    // 分割线
    g.strokeStyle = '#E7ECF3'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(56, qy - 34); g.lineTo(W - 56, qy - 34); g.stroke();

    // 二维码（放大到 190，手机端更易识别）
    const qs = 190;
    const qc = qrCanvas(url, qs);
    g.drawImage(qc, 56, qy - 12, qs, qs);
    g.fillStyle = '#16202E'; g.font = `600 27px ${FONT}`;
    g.fillText(kind === 'site' ? '扫码查看招商网站' : '长按识别 · 查看房源详情', 268, qy + 52);
    g.fillStyle = '#8794A6'; g.font = `400 22px ${FONT}`;
    g.fillText(kind === 'site'
      ? '看园区地图 · 查在租房源 · 留言咨询'
      : (l.parkName + ' · ' + l.building + ' ' + l.floor), 268, qy + 88);
    g.fillText('招商顾问：' + (kind === 'site' ? Api.db.settings.hotline : l.contact + ' ' + l.phone), 268, qy + 126);

    g.fillStyle = '#B7C2D0'; g.font = `400 20px ${FONT}`;
    g.fillText(Api.db.settings.siteName + ' · 本信息由招商方发布', 56, H - 48);

    POSTER.cv = cv;
    let out = '';
    try {
      out = cv.toDataURL('image/jpeg', 0.92);
    } catch (e) {
      // 画布被跨域图片污染时的降级：不再带封面，只保留文字与二维码
      try {
        const c2 = document.createElement('canvas');
        c2.width = W; c2.height = H;
        const g2 = c2.getContext('2d');
        g2.fillStyle = '#fff'; g2.fillRect(0, 0, W, H);
        g2.fillStyle = '#16202E'; g2.font = `700 40px ${FONT}`;
        g2.fillText(kind === 'site' ? '松山湖产业招商' : (l.parkName + ' · ' + l.building), 56, 120);
        g2.drawImage(qrCanvas(url, 200), 56, 200, 200, 200);
        POSTER.cv = c2;
        out = c2.toDataURL('image/jpeg', 0.92);
      } catch (e2) { out = ''; }
    }
    done(out);
  }

  img.onload = finish;
  img.onerror = finish;
  img.src = coverSmall;
}

function openPoster(dataUrl) {
  if (!dataUrl) { toast('海报生成失败，请改用「复制链接」分享'); return; }
  const im = $('#posterImg');
  if (im) im.src = dataUrl;
  const tik = $('#posterMask');
  if (tik) tik.classList.add('show');
}
function closePoster() {
  const m = $('#posterMask');
  if (m) m.classList.remove('show');
  revokePosterBlob();
}

/* 保存海报：
   微信/QQ 内置浏览器不支持 <a download>，只能长按图片保存；
   普通浏览器用 canvas 生成 Blob 再下载，避免超长 data URL 被拦截。 */
function savePoster() {
  const im = $('#posterImg');
  if (!im || !im.src) { toast('海报尚未生成，请稍后再试'); return; }

  if (IS_WECHAT || IS_QQ) {
    toast('请长按上方海报图片 →「保存图片」，然后到微信里发送给好友');
    return;
  }

  const name = '松山湖产业招商_' + Date.now() + '.jpg';
  const cv = POSTER.cv;

  const fire = href => {
    const a = document.createElement('a');
    a.href = href; a.download = name;
    a.rel = 'noopener'; a.target = '_blank';
    document.body.appendChild(a); a.click();
    setTimeout(() => { try { document.body.removeChild(a); } catch (e) { } }, 400);
  };

  if (cv && typeof cv.toBlob === 'function') {
    cv.toBlob(blob => {
      if (!blob) { fire(im.src); return; }
      revokePosterBlob();
      POSTER.blobUrl = URL.createObjectURL(blob);
      fire(POSTER.blobUrl);
      setTimeout(revokePosterBlob, 60000);
      toast('图片已保存到下载目录');
    }, 'image/jpeg', 0.92);
    return;
  }
  fire(im.src);
  toast('图片已保存到下载目录');
}

/* ---------- 分享面板 ---------- */
function shareCtx(kind, id) {
  if (kind === 'listing') {
    const l = findListing(id);
    if (!l) return null;
    return {
      kind, l,
      title: `${l.parkName} · ${l.building} ${l.area}㎡ ${l.rent}元/㎡·月`,
      desc: `${l.floor} · ${l.orientation}向 · ${l.decoration} · ${l.layout}，物业费 ${l.propertyFee} 元/㎡·月`,
      url: shareLink({ id: l.id }),
      /* 卡片缩略图：服务端把该房源首图转成公网图片（微信要求 http(s) 地址） */
      imgUrl: (l.photos || [])[0] || SHARE_BASE + '/assets/songshanhu-map.jpg'
    };
  }
  return {
    kind: 'site',
    l: null,
    title: (Api.db.settings.share && Api.db.settings.share.title) || '松山湖产业招商网站',
    desc: (Api.db.settings.share && Api.db.settings.share.desc) || '地图找房、筛选比价、在线留言，招商顾问一对一对接',
    url: shareLink({}),
    imgUrl: ''
  };
}

function sheetShare(kind, id) {
  const c = shareCtx(kind, id);
  if (!c) return toast('房源不存在');
  State.share = c;
  openSheet(`
    <div class="sheet-head">
      <h3>分享转发</h3>
      <button class="sheet-close" type="button" data-act="close:sheet">✕</button>
    </div>
    <div class="sheet-body">
      <div class="share-card">
        <div class="share-thumb">${c.kind === 'site'
      ? '<img src="assets/songshanhu-map.jpg" alt="">'
      : `<img src="${photoURL((c.l.photos && c.l.photos[0]) || photoURI('facade', 0))}" alt="">`}</div>
        <div class="share-meta">
          <div class="share-title">${esc(c.title)}</div>
          <div class="share-desc">${esc(c.desc)}</div>
        </div>
      </div>

      <div class="share-grid">
        <button class="share-btn" type="button" data-act="share:wx">
          <span class="sb-ico wx"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 4C5.1 4 2 6.6 2 9.8c0 1.8 1 3.4 2.6 4.5l-.7 2.1 2.4-1.2c.9.3 1.8.4 2.7.4h.6a5.9 5.9 0 01-.2-1.5C9.4 10.7 12.6 8 16.7 8h.7C16.8 5.7 13.2 4 9 4z"/><path d="M22 14.2c0-2.7-2.6-4.9-5.8-4.9s-5.8 2.2-5.8 4.9 2.6 4.9 5.8 4.9c.7 0 1.4-.1 2-.3l1.9 1-.5-1.7c1.5-.9 2.4-2.2 2.4-3.9z"/></svg></span>
          <span class="sb-t">微信好友</span>
        </button>
        <button class="share-btn" type="button" data-act="share:copy">
          <span class="sb-ico link"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M10 13a5 5 0 007 0l3-3a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-3 3a5 5 0 007 7l1-1"/></svg></span>
          <span class="sb-t">复制链接</span>
        </button>
        <button class="share-btn" type="button" data-act="share:poster">
          <span class="sb-ico poster"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 15l3-3 3 3 2-2 3 3"/><circle cx="8.5" cy="8.5" r="1.5"/></svg></span>
          <span class="sb-t">分享海报</span>
        </button>
        <button class="share-btn" type="button" data-act="share:more">
          <span class="sb-ico more"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg></span>
          <span class="sb-t">更多方式</span>
        </button>
      </div>

      <div class="share-link-row">
        <input type="text" id="shareUrlBox" readonly value="${esc(c.url)}">
        <button class="op-btn pri" type="button" data-act="share:copy">复制</button>
      </div>
      <div class="share-tip">
        ${IS_WECHAT
      ? '点「微信好友」会直接弹出微信转发面板，选择好友发送即可（如未弹出，点右上角 <b>···</b> 选「发送给朋友」）。'
      : '上方链接就是这套房源的专属页面：复制后粘贴到微信 / QQ，卡片会显示房源标题、参数和实景图；也可以直接保存海报发出去。'}
      </div>
    </div>
    <div class="sheet-foot">
      <button class="btn gray" type="button" data-act="close:sheet">关闭</button>
    </div>`);
}

/* 未配置公众号时的原生转发：WeixinJSBridge 直接唤起微信转发面板（无需 JS-SDK 签名）。
   仅在微信 webview 中可用；返回 false 或通道报错时调用方回退到右上角引导。 */
function wxBridgeShare(c) {
  try {
    const B = window.WeixinJSBridge;
    if (!B || typeof B.invoke !== 'function') return false;
    let img = '';
    const p = c.imgUrl || (c.l && c.l.photos && c.l.photos[0]) || '';
    if (/^https?:/i.test(p)) img = p;
    else if (p && p.indexOf('data:') !== 0) img = SHARE_BASE + '/' + String(p).replace(/^\.\//, '');
    B.invoke('sendAppMessage', {
      appid: '', type: 'link',
      title: c.title, desc: c.desc, link: c.url, img_url: img
    }, function (res) {
      /* 新版本微信已弃用该 bridge 方法：报错时回退到右上角引导，避免"点了没反应" */
      const msg = (res && res.err_msg) || '';
      if (/fail|not_exist|invalid|unavailable/i.test(msg)) showWxGuide();
    });
    return true;
  } catch (e) { return false; }
}

/* 右下角"点击右上角 ···"引导层 */
function showWxGuide(withCopy) {
  const g = $('#wxGuide');
  if (!g) return;
  const t = g.querySelector('.wx-text');
  if (t) t.innerHTML = withCopy
    ? '<b>点击右上角 ●···</b><span>选「发送给朋友」即可把当前内容直接发给微信好友（链接已复制，发送后也可粘贴给其他好友）</span>'
    : '<b>点击右上角 ●···</b><span>选「发送给朋友」，即可把这套房源发给微信好友，好友打开就是房源页面</span>';
  g.classList.add('show');
}

function doShareWx(withCopy) {
  const c = State.share;
  if (!c) return;
  /* 分享前再同步一次卡片数据（房源标题/描述/首图），已配置公众号时立即生效 */
  try { WxShare.update(c); } catch (e) { }
  if (IS_WECHAT) {
    if (withCopy) { try { copyText(c.url); } catch (e) { } }
    if (wxBridgeShare(c)) {
      closeSheet();
      toast('已唤起微信转发，选择好友发送即可');
      return;
    }
    /* 转发唤起失败：保留分享面板，在其上方显示右上角引导 */
    showWxGuide(withCopy);
  } else {
    toast('请在微信中打开本页，点右上角「···」→「发送给朋友」即可转发');
  }
}

function doShareCopy() {
  const c = State.share;
  if (!c) return;
  copyText(c.url).then(ok => toast(ok ? '链接已复制，粘贴给微信好友即可' : '复制失败，请长按上方链接手动复制'));
}

function doSharePoster() {
  const c = State.share;
  if (!c) return;
  toast('正在生成海报…');
  buildPoster(c.kind, c.l, url => { closeSheet(); openPoster(url); });
}

function doShareMore() {
  const c = State.share;
  if (!c) return;
  if (navigator.share) {
    navigator.share({ title: c.title, text: c.desc, url: c.url }).catch(() => { });
  } else {
    doShareCopy();
  }
}

/* ---------- 公众号 JS-SDK 接入（可选） ---------- */
const WxShare = {
  ready: false,
  started: false,
  pending: null, /* 最近一次要应用的分享数据（页面切换会不断更新，就绪后自动生效） */
  setup(data) {
    if (data) this.pending = data;
    const conf = (Api.db.settings.wx) || {};
    if (!conf.appId || !IS_WECHAT || this.started) return false;
    this.started = true;
    const script = document.createElement('script');
    script.src = 'https://res.wx.qq.com/open/js/jweixin-1.6.0.js';
    script.onload = () => {
      // 正式环境：签名需由后端接口返回（基于当前 URL 调用公众号 jssdk 接口）
      // 未部署签名接口时会自动跳过，不影响其余分享方式
      fetch('/api/wx/jssdk?url=' + encodeURIComponent(location.href.split('#')[0]))
        .then(r => (r.ok ? r.json() : Promise.reject(new Error('HTTP ' + r.status))))
        .then(sig => {
          if (!window.wx) return;
          window.wx.config({
            debug: false, appId: conf.appId, timestamp: sig.timestamp, nonceStr: sig.nonceStr,
            signature: sig.signature, jsApiList: conf.jsApiList || []
          });
          window.wx.ready(() => {
            WxShare.ready = true;
            WxShare.update(WxShare.pending || data);
          });
        })
        .catch(e => console.warn('微信 JS-SDK 签名获取失败，已回退到引导分享', e));
    };
    script.onerror = () => console.warn('微信 JS-SDK 加载失败');
    document.head.appendChild(script);
    return true;
  },
  update(data) {
    if (data) this.pending = data;            /* 先记住最新数据（可能在就绪前调用） */
    if (!this.ready || !window.wx || !this.pending) return;
    const data2 = this.pending;
    /* 缩略图必须是公网可访问的 http(s) URL：
       房源优先用该房源首图（服务端 /api/photo 转出），否则回退到共享封面 / 站点图 */
    let img = data2.imgUrl || (Api.db.settings.share && Api.db.settings.share.img) || '';
    if (!/^https?:\/\//.test(img)) img = SHARE_BASE + '/assets/songshanhu-map.jpg';
    const d = { title: data2.title, desc: data2.desc, link: data2.url, imgUrl: img };
    window.wx.updateAppMessageShareData && window.wx.updateAppMessageShareData(d);
    window.wx.updateTimelineShareData && window.wx.updateTimelineShareData(d);
    window.wx.onMenuShareAppMessage && window.wx.onMenuShareAppMessage(d);
    window.wx.onMenuShareTimeline && window.wx.onMenuShareTimeline(d);
  }
};

/* ---------------- 全局事件委托 ---------------- */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const act = el.dataset.act;
  const v = el.dataset.v;
  const id = el.dataset.id;

  /* 房源精准定位（地图选点） */
  if (act === 'pick:loc') { sheetPickLoc(); return; }
  if (act === 'pick:parkLoc') { useParkLoc(); return; }
  if (act === 'pick:ok') { applyPickLoc(); return; }
  if (act === 'pick:search') { pickSearch(); return; }
  if (act === 'pick:item') { pickItem(el); return; }

  switch (act) {
    /* 导航 */
    case 'tab': setView(v, false); break;
    case 'detail:retry': {
      /* 带新参数整页刷新：既重拉云端数据，也击穿微信 webview 的页面缓存 */
      const rsp = new URLSearchParams(location.search);
      rsp.set('r', String(Date.now()));
      location.href = location.pathname + '?' + rsp.toString();
      break;
    }
    case 'goto:admin': setView('admin', true); break;
    case 'nav:back': back(); break;
    case 'close:sheet': clearCodeTimer(); closeSheet(); break;
    case 'dlg:cancel': $('#dialogMask').classList.remove('show'); break;

    /* 分享 */
    /* 分享：手机端与电脑端统一弹出「分享转发」面板（房源卡片 + 微信好友/复制链接/海报）；
       面板内点「微信好友」再尝试直接唤起微信转发，失败时回退右上角引导 */
    case 'open:share': {
      const sid = id || (v === 'site' ? '' : State.params.id);
      if (v !== 'site' && sid) sheetShare('listing', sid);
      else sheetShare('site', '');
      break;
    }
    case 'share:wx': doShareWx(); break;
    case 'share:copy': doShareCopy(); break;
    case 'share:poster': doSharePoster(); break;
    case 'share:more': doShareMore(); break;
    case 'close:poster': closePoster(); break;
    case 'save:poster': savePoster(); break;
    case 'close:wxGuide': { const g = $('#wxGuide'); if (g) g.classList.remove('show'); break; }

    /* 房源 */
    case 'open:listing':
      openListing(id);
      break;

    /* 搜索与筛选 */
    case 'hot:chip':
      if (el.dataset.range === '1') { State.filters.area = v; State.filters.kw = ''; }
      else { State.filters.kw = v; State.filters.area = '全部'; }
      refresh();
      break;
    case 'set:sort':
      State.filters.sort = State.filters.sort === v ? 'default' : v;
      refresh();
      break;
    case 'open:filter': sheetFilter(); break;
    case 'open:parkPicker':
      sheetSinglePicker('park', ['全部'].concat(parksAll().map(p => p.name)), '选择园区');
      break;
    case 'open:rentPicker': sheetSinglePicker('rent', RENT_OPTS, '选择租金区间（元/㎡·月）'); break;
    case 'filters:reset':
      State.filters = { kw: '', park: '全部', rent: '全部', area: '全部', orientation: '全部', decoration: '全部', layout: '全部', sort: 'default' };
      closeSheet(); refresh(); toast('筛选已重置');
      break;
    case 'filters:apply':
      closeSheet(); refresh();
      break;

    /* 弹层内选项（seg） */
    case 'opt:seg': break;

    /* 地图 */
    case 'map:park': {
      State.mapPark = v || null;
      if (v) State.tmapFocus = v;             // 在线地图下把视图移到该园区
      if (State.view !== 'map') { State.stack = []; setView('map', false); }
      else render();
      if (!v) { State.mapScale = 1; State.mapX = 0; State.mapY = 0; State.tmapView = null; applyMapTransform(); }
      else centerOnPark(v);
      break;
    }
    /* 在线地图（腾讯 GL JS）控件 */
    case 'map:zoomin':
      if (State.tmap) State.tmap.setZoom(State.tmap.getZoom() + 1);
      break;
    case 'map:zoomout':
      if (State.tmap) State.tmap.setZoom(State.tmap.getZoom() - 1);
      break;
    case 'map:recenter': {
      const c = MapKit.center();
      if (State.tmap) { State.tmap.setCenter(new MapKit.T.LatLng(c.lat, c.lng)); State.tmap.setZoom(13); }
      break;
    }
    case 'map:locate': {
      State.mapPark = v || null;
      if (v) State.tmapFocus = v;             // 在线地图下聚焦该园区
      State.stack = [];
      setView('map', false);
      if (v) centerOnPark(v);
      break;
    }
    case 'map:zoom': {
      const d = Number(v);
      State.mapScale = Math.min(2.4, Math.max(1, +(State.mapScale + d * 0.25).toFixed(2)));
      const inner = $('#mapInner');
      if (inner) inner.style.transform = `translate(${State.mapX}px,${State.mapY}px) scale(${State.mapScale})`;
      break;
    }
    case 'map:reset':
      State.mapScale = 1; State.mapX = 0; State.mapY = 0; render();
      break;

    /* 联系 */
    case 'call': {
      const phone = v;
      if (!phone || !/^[0-9-]{7,}$/.test(phone)) { toast('电话待补充，请在线留言'); break; }
      dialog({
        title: '拨打电话', text: phone, okText: '立即拨打', onOk: () => { window.location.href = 'tel:' + phone; }
      });
      break;
    }

    /* 留言 / 登录 */
    case 'open:inquiry': sheetInquiry(id, el.dataset.type); break;
    case 'submit:inquiry': submitInquiry(id); break;
    case 'open:login': sheetVisitorLogin(); break;
    case 'send:code': sendVisitorCode(); break;
    case 'submit:visitorLogin': submitVisitorLogin(); break;
    case 'visitor:logout':
      dialog({
        title: '退出登录', text: '退出后需重新登录才能留言，确定退出吗？', danger: true, onOk: () => {
          State.session.visitor = null; saveSession(); toast('已退出游客登录'); refresh();
        }
      });
      break;
    case 'open:viewed': sheetViewed(); break;
    case 'open:about': sheetAbout(); break;

    /* 首页三入口 */
    case 'entry:usage': {
      State.filters.usage = (v === '写字楼' || v === '厂房') ? v : '全部';
      if (State.view !== 'home') setView('home', true);
      else { const hv = $('#view-home'); if (hv) hv.scrollTop = 0; render(); }
      break;
    }
    case 'set:usage': {
      State.filters.usage = State.filters.usage === '全部' ? '写字楼' : (State.filters.usage === '写字楼' ? '厂房' : '全部');
      render();
      break;
    }
    case 'open:resources': setView('resources', true); break;
    case 'open:indResForm': sheetIndRes(); break;
    case 'submit:indRes': submitIndRes(); break;
    case 'del:indRes': delIndRes(id); break;

    /* 我的企业 / 我的需求 */
    case 'open:myCompany': sheetMyCompany(); break;
    case 'submit:myCompany': submitMyCompany(); break;
    case 'open:myNeeds': sheetMyNeeds(); break;
    case 'add:myNeed': addMyNeed(); break;
    case 'del:myNeed': delMyNeed(v); break;

    /* AI 找房助手 */
    case 'open:aiMatch': sheetAiMatch(); break;
    case 'ai:quick': aiAsk(el.dataset.v); break;
    case 'ai:ask': aiAsk(); break;

    /* 管理端 */
    case 'open:adminLogin': window.location.href = ((window.__SITE_BACKEND__ || {}).basePath || '') + '/admin/'; break;
    case 'admin:login': window.location.href = ((window.__SITE_BACKEND__ || {}).basePath || '') + '/admin/'; break;
    case 'admin:logout':
      dialog({
        title: '退出管理后台', text: '退出后需重新输入账号密码，确定退出吗？', danger: true, onOk: () => {
          State.session.admin = null; saveSession(); State.stack = [];
          toast('已退出管理后台'); setView('mine', false);
        }
      });
      break;
    case 'admin:tab':
      State.adminTab = v;
      render();
      break;
    case 'admin:filter':
      State.adminListFilter = v;
      render();
      break;
    case 'admin:new':
      openSheet(listingFormHTML(null));
      bindListingForm();
      break;
    case 'admin:edit': {
      const l = findListing(id);
      if (!l) return toast('房源不存在');
      const open = () => { openSheet(listingFormHTML(l)); bindListingForm(); };
      /* 先把该房源的照片大图补全再打开表单：否则保存时会用"只有封面"的照片组覆盖云端，导致照片被删 */
      if (!l.photosLoaded && Cloud.ready && Cloud.client) {
        toast('正在读取该房源照片…');
        ensureListingPhotos(id).then(open).catch(open);
      } else open();
      break;
    }
    case 'admin:toggle': {
      const l = findListing(id);
      if (!l) return;
      const willOnline = l.status !== 'online';
      l.status = willOnline ? 'online' : 'offline';
      l.updatedAt = new Date().toISOString();
      Api.save();
      Cloud.pushRow('listings', l);
      toast(willOnline ? '房源已上架，游客端立即可见' : '房源已下架，游客端不再展示');
      const b2 = $('#adminBody');
      if (b2) b2.innerHTML = renderAdminBody();
      renderTabbar();
      break;
    }
    case 'admin:del': {
      const l = findListing(id);
      if (!l) return;
      dialog({
        title: '删除房源', text: `确定删除「${l.parkName} · ${l.building}」吗？该操作不可恢复。`,
        danger: true, okText: '确认删除', onOk: () => {
          Api.db.listings = Api.db.listings.filter(x => x.id !== id);
          Api.save();
          /* 记墓碑再删：其他设备（含客户手机上的旧缓存）同步时会按墓碑清理，
             不会再把这条已删除的房源推回云端复活 */
          Cloud.markDeleted('listings', id);
          /* 顺手清掉该房源的服务器独立照片，避免磁盘/云端堆积废图 */
          fetch('/api/photo/' + encodeURIComponent(id), { method: 'DELETE' }).catch(() => { });
          State.session.viewed = (State.session.viewed || []).filter(x => x !== id);
          saveSession();
          toast('房源已删除，云端已同步');
          const body = $('#adminBody');
          if (body) body.innerHTML = renderAdminBody();
          renderTabbar();
        }
      });
      break;
    }
    case 'admin:save': saveListing(id || null); break;

    /* 园区管理 */
    case 'admin:newPark': parkFormSheet(null); break;
    case 'admin:editPark': parkFormSheet(v); break;
    case 'admin:delPark': {
      const p = Api.park(v);
      if (!p) return;
      dialog({
        title: '删除园区', text: `确定删除「${p.name}」吗？该园区下暂无房源时才可删除。`,
        danger: true, okText: '确认删除', onOk: () => {
          const r = Api.deletePark(v);
          toast(r.ok ? '园区已删除' : r.msg);
          const body = $('#adminBody');
          if (body) body.innerHTML = renderAdminBody();
        }
      });
      break;
    }
    case 'admin:savePark': saveParkSheet(id || null); break;

    /* 转发卡片自定义 */
    case 'admin:pickShareImg': pickShareImage(); break;
    case 'admin:clearShareImg': {
      if (!State.shareDraft) State.shareDraft = {};
      State.shareDraft.img = '';
      Api.db.settings.share.img = '';
      Api.save();
      const prev = $('#shareImgPrev');
      if (prev) prev.style.backgroundImage = 'none';
      const body = $('#adminBody');
      if (body) body.innerHTML = renderAdminBody();
      toast('已清除自定义封面');
      break;
    }
    case 'admin:saveShare': saveShareSettings(); break;

    case 'admin:addPhoto': {
      State.form.replaceIdx = -1;
      const inp = $('#photoInput');
      if (inp) inp.click();
      break;
    }
    case 'admin:chgPhoto': {
      State.form.replaceIdx = Number(el.dataset.i);
      const inp = $('#photoInput');
      if (inp) inp.click();
      break;
    }
    case 'admin:rmPhoto': {
      const i = Number(el.dataset.i);
      State.form.photos.splice(i, 1);
      State.form.photosTouched = true;
      renderUploadGrid();
      break;
    }
    case 'admin:export': exportListings(); break;
    case 'admin:exportVisitors': exportVisitors(); break;

    /* 留言处理 */
    case 'admin:reply': adminReplySheet(id); break;
    case 'reply:quick': {
      const box = $('#replyText');
      if (box) box.value = v;
      break;
    }
    case 'admin:doReply': {
      const m = Api.db.messages.find(x => x.id === id);
      if (!m) return;
      const txt = (($('#replyText') || {}).value || '').trim();
      if (!txt) return toast('请输入回复内容');
      m.reply = txt;
      m.status = 'done';
      Api.save();
      Cloud.pushRow('messages', m);
      closeSheet();
      toast('回复已发送，访客可在「我的留言」中查看');
      const body = $('#adminBody');
      if (body) body.innerHTML = renderAdminBody();
      renderTabbar();
      break;
    }
    case 'admin:delMsg': {
      const m = Api.db.messages.find(x => x.id === id);
      if (!m) return;
      dialog({
        title: '删除留言', text: '确定删除这条访客留言吗？', danger: true, okText: '删除', onOk: () => {
          Api.db.messages = Api.db.messages.filter(x => x.id !== id);
          Api.save();
          Cloud.markDeleted('messages', id);
          toast('留言已删除');
          const body = $('#adminBody');
          if (body) body.innerHTML = renderAdminBody();
          renderTabbar();
        }
      });
      break;
    }

    /* 管理员账号管理 */
    case 'admin:newAdmin': newAdminSheet(); break;
    case 'admin:doNewAdmin': doNewAdmin(); break;
    case 'admin:resetPwd': sheetResetPwd(id); break;
    case 'admin:doResetPwd': doResetPwd(id); break;
    case 'admin:toggleAdmin': {
      const a = Api.db.admins.find(x => x.id === id);
      if (!a || a.role === 'super') return;
      a.enabled = !a.enabled;
      Api.save();
      Cloud.markDirty('admins', a.id);
      Cloud.pushAdmins();
      toast(a.enabled ? '账号已启用' : '账号已停用');
      const body = $('#adminBody');
      if (body) body.innerHTML = renderAdminBody();
      break;
    }
    case 'admin:delAdmin': {
      const a = Api.db.admins.find(x => x.id === id);
      if (!a || a.role === 'super') return;
      dialog({
        title: '删除管理员', text: `确定删除管理员「${a.name}」（账号 ${a.username}）吗？`, danger: true, okText: '删除', onOk: () => {
          Api.db.admins = Api.db.admins.filter(x => x.id !== id);
          Api.save();
          /* 墓碑 + 上云：否则其他设备的旧账号列表会把它同步回来 */
          Cloud.markDeleted('admins', id);
          Cloud.pushAdmins();
          toast('管理员已删除');
          const body = $('#adminBody');
          if (body) body.innerHTML = renderAdminBody();
        }
      });
      break;
    }
    case 'admin:saveSettings': {
      const name = (($('#setSiteName') || {}).value || '').trim();
      const hot = (($('#setHotline') || {}).value || '').trim();
      const max = Number((($('#setMaxAdmins') || {}).value) || 5);
      if (!name) return toast('请填写平台名称');
      if (!hot) return toast('请填写招商热线');
      if (!max || max < 1 || max > 20) return toast('管理员上限需在 1-20 之间');
      if (max < Api.db.admins.length) return toast('上限不能小于当前管理员数量 ' + Api.db.admins.length);
      Api.db.settings.siteName = name;
      Api.db.settings.hotline = hot;
      Api.db.settings.maxAdmins = max;
      Api.save();
      Cloud.markDirtyKeys(['siteName', 'hotline', 'maxAdmins']);
      Cloud.pushMeta();
      toast('设置已保存，已同步到云端');
      const body = $('#adminBody');
      if (body) body.innerHTML = renderAdminBody();
      break;
    }
    case 'admin:saveIntegrations': {
      const s = Api.db.settings.sms || (Api.db.settings.sms = {});
      const ttl = Number((($('#setSmsTtl') || {}).value) || 300);
      const cd = Number((($('#setSmsCd') || {}).value) || 60);
      const mx = Number((($('#setSmsMax') || {}).value) || 5);
      if (ttl < 60 || ttl > 1800) return toast('验证码有效期需在 60-1800 秒之间');
      if (cd < 30 || cd > 300) return toast('发送间隔需在 30-300 秒之间');
      if (mx < 3 || mx > 10) return toast('最大尝试次数需在 3-10 次之间');
      s.ttlSec = ttl; s.cooldownSec = cd; s.maxTry = mx;
      s.demoShow = !!($('#setSmsDemo') || {}).checked;
      Api.db.settings.wx = Api.db.settings.wx || {};
      Api.db.settings.wx.appId = (($('#setWxAppId') || {}).value || '').trim();
      Api.db.settings.wx.appSecret = (($('#setWxSecret') || {}).value || '').trim();
      Api.db.settings.tmapKey = (($('#setTmapKey') || {}).value || '').trim();
      Api.save();
      Cloud.markDirtyKeys(['sms', 'wx', 'tmapKey']);
      Cloud.pushMeta();
      MapKit.T = null; MapKit.loading = null;   // Key 变化后允许重新加载地图 SDK
      toast('设置已保存，已同步到云端');
      const b = $('#adminBody');
      if (b) b.innerHTML = renderAdminBody();
      break;
    }
    case 'admin:resetPark': {
      Api.resetParkCoord(v);
      const body = $('#adminBody');
      if (body) { body.innerHTML = adminMapBody(); bindAnnotateMap(); }
      toast('已恢复「' + v + '」的默认坐标');
      break;
    }
    case 'admin:resetParkAll':
      dialog({
        title: '恢复默认坐标',
        text: '将清空全部手动校准记录，所有园区标记回到按经纬度标定的初始位置。',
        danger: true, okText: '确认恢复', onOk: () => {
          Api.db.settings.parkCoords = {};
          Api.save();
          const body = $('#adminBody');
          if (body) { body.innerHTML = adminMapBody(); bindAnnotateMap(); }
          toast('已恢复全部默认坐标');
        }
      });
      break;
    case 'admin:backupNow':
      Api.backupNow();
      refreshBackupList();
      toast('已备份当前数据快照');
      break;
    case 'admin:restoreBackup': {
      const bi = parseInt(el && el.dataset.i, 10);
      dialog({
        title: '恢复备份', text: '将把房源、园区、留言、管理员等数据恢复到所选快照（恢复前会再自动备份一次当前数据），确定继续吗？',
        danger: true, okText: '确认恢复', onOk: async () => {
          const r = await Api.restoreBackup(bi);
          if (!r.ok) return toast(r.msg || '恢复失败');
          toast('已恢复所选备份，云端同步中…');
          render(); renderTabbar();
        }
      });
      break;
    }
    case 'admin:reset':
      dialog({
        title: '恢复演示数据', text: '将自动备份你当前的数据（可在上方"备份与恢复"找回），然后还原初始房源、留言与访客示例。确定继续吗？',
        danger: true, okText: '确认恢复', onOk: () => {
          Api.reset();
          Api.logVisit();
          toast('已恢复演示数据，云端同步中…');
          Cloud.reconcile('listings', Api.db.listings);
          Cloud.reconcile('parks', Api.db.parks);
          Cloud.reconcile('messages', Api.db.messages);
          Cloud.reconcile('visitors', Api.db.visitors);
          Cloud.pushMeta();
          render(); renderTabbar();
        }
      });
      break;
    case 'admin:clearAll':
      dialog({
        title: '清空本机缓存', text: '只清空本机浏览器缓存，云端数据保持不变；重新打开页面会自动从云端恢复数据。确定继续吗？',
        danger: true, okText: '确认清空', onOk: () => {
          localStorage.removeItem(DB_KEY);
          localStorage.removeItem(SES_KEY);
          Api.load();
          reloadSession();
          toast('本机缓存已清空，正在从云端恢复…');
          /* 注意：只清本机，绝不能把本机数据"对账"推回云端——
             那会把云端真实房源覆盖成演示数据、并删掉云端房源 */
          Cloud.pull().then(() => { State.stack = []; setView('home', false); render(); });
        }
      });
      break;
  }
});

/* 弹层内 seg 选择（筛选器 / 表单状态） */
document.addEventListener('click', e => {
  const seg = e.target.closest('.seg[data-filter]');
  if (!seg) return;
  const btn = e.target.closest('button');
  if (!btn) return;
  const key = seg.dataset.filter;
  State.filters[key] = btn.dataset.v;
  $$('button', seg).forEach(b => b.classList.toggle('on', b === btn));
});

/* 遮罩点击关闭 */
$('#sheetMask').addEventListener('click', e => { if (e.target.id === 'sheetMask') closeSheet(); });
$('#dialogMask').addEventListener('click', e => { if (e.target.id === 'dialogMask') $('#dialogMask').classList.remove('show'); });

/* 导航返回按钮 */
document.addEventListener('DOMContentLoaded', () => {
  const nb = $('#navBack');
  if (nb) nb.onclick = back;
});

/* 服务端注入的房源首屏数据（/l/<id> 或 /?id=<id> 分享页）：
   好友点开链接先立刻看到房源详情，不必等云端同步；只补缺，不覆盖本地已有数据 */
function applyDeepListing() {
  const d = window.__DEEP_LISTING__;
  if (!d || !d.id) return null;
  try {
    if (!Api.db.listings) Api.db.listings = [];
    const i = Api.db.listings.findIndex(x => x && x.id === d.id);
    if (i < 0) {
      Api.db.listings.unshift(d);
    } else {
      const cur = Api.db.listings[i];
      Object.keys(d).forEach(k => {
        const v = d[k];
        if (v === undefined || v === null || v === '') return;
        if (cur[k] === undefined || cur[k] === null || cur[k] === '') cur[k] = v;
      });
      if ((d.photos || []).length && !(cur.photos || []).length) cur.photos = d.photos;
    }
  } catch (e) { }
  return findListing(d.id);
}

/* ---------------- 启动 ---------------- */
function boot() {
  Api.load();
  reloadSession();
  State.session.admin = null;
  Api.logVisit();
  applyDeepListing();
  applyShareMeta();
  if (State.session.admin) State.adminTab = 'listing';

  /* 云端同步：先渲染本地缓存保证秒开，随后拉云端合并；本端独有数据自动回推 */
  Cloud.init();
  const deepOpenFound = l => {
    State.deepPending = null;
    State.session.viewed = [l.id].concat((State.session.viewed || []).filter(x => x !== l.id)).slice(0, 20);
    Api.logView(l.id);
    saveSession();
    State.params.id = l.id;
    document.title = l.parkName + ' ' + l.area + '㎡ ' + l.rent + '元/㎡·月 · 松山湖产业招商';
    if (State.view === 'detail' && State.params.id === l.id) render();
    else setView('detail', true);
  };
  if (Cloud.ready) {
    Cloud.pull().then(async r => {
      applyShareMeta();
      curVisitor(); /* pull 整表替换 visitors 后重新对齐会话访客引用 */
      if (!State.deepPending) render();
      if (r && r.ok && !r.inited) await Cloud.seedIfEmpty();
      /* 云端连上后自动把本机历史 base64 照片搬到服务器，并把空间真正腾出来。
         不区分管理员/访客——照片占的是**这台设备**的空间，谁打开谁受益 */
      migratePhotosToServer().catch(e => console.warn('照片迁移跳过', e));
      /* 深链房源：本地没有的话，云端拉完再判一次（可能刚同步进来） */
      if (State.deepPending) {
        const did = State.deepPending;
        if (findListing(did)) { deepOpenFound(findListing(did)); return; }
        const again = await Cloud.pull();
        if (again && again.ok && findListing(did)) deepOpenFound(findListing(did));
        else { State.deepPending = null; render(); setTimeout(() => toast('未找到链接中的房源，可能已被删除'), 400); }
      }
    }).catch(() => { });
    setInterval(() => { Cloud.pull().then(ok => { if (ok && ok.ok && !State.deepPending) { curVisitor(); render(); } }).catch(() => { }); }, 30000);
  }

  // 状态栏时间
  const setTime = () => {
    const d = new Date();
    const el = $('#sbTime');
    if (el) el.textContent = pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  };
  setTime();
  setInterval(setTime, 20000);

  /* 分享链接深链：?id=L1001 或 /l/L1001 直接打开房源，?park=园区名 打开地图并定位 */
  const sp = new URLSearchParams(location.search);
  const pathM = /^\/l\/([^/]+)\/?$/.exec(location.pathname || '');
  let deepId = sp.get('id') || '';
  if (!deepId && pathM) { try { deepId = decodeURIComponent(pathM[1]); } catch (e) { deepId = pathM[1]; } }
  const deepPark = sp.get('park');
  const l = deepId ? findListing(deepId) : null;

  if (l) {
    deepOpenFound(l);
  } else if (deepId) {
    /* 本地暂无该房源：先进详情页"云端加载中"状态，等 pull 完成后判定（见上方 pull 回调） */
    State.params.id = deepId;
    State.deepPending = deepId;
    setView('detail', false);
  } else if (deepPark && parksAll().some(p => p.name === deepPark)) {
    State.mapPark = deepPark;
    setView('map', false);
    centerOnPark(deepPark);
  } else {
    setView('home', false);
  }

  /* 微信原生分享（在 settings.wx.appId 中配置公众号后自动生效）。
     注意：必须在深链解析后再取分享上下文，否则分享出去的卡片会退回"站点"信息 */
  try {
    const cur = (State.view === 'detail' && State.params.id && findListing(State.params.id))
      ? shareCtx('listing', State.params.id)
      : shareCtx('site');
    WxShare.setup(cur);
  } catch (e) { /* 未配置公众号时静默回退到引导分享 */ }
}

boot();
