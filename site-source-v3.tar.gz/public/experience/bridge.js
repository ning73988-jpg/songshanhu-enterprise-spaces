/* Public read adapter for the existing Songshanhu Supabase project.
   This file intentionally carries no service-role credential and never writes listings. */
(function () {
  const config = window.__SITE_BACKEND__ || {};
  const url = String(config.url || '').replace(/\/$/, '');
  const key = String(config.key || '');
  const notice = text => {
    const slot = document.querySelector('#view-home');
    if (slot) slot.insertAdjacentHTML('afterbegin', `<div class="port-notice">${text}</div>`);
  };
  if (!url || !key) {
    Api.db.listings = [];
    render();
    notice('网站数据服务尚未连接，房源功能暂不可用。');
    return;
  }
  const mapRow = row => ({
    id: row.id,
    parkName: row.park || '园区待补充',
    building: row.unit || row.title || '房源',
    floor: row.floor || '楼层待补充',
    area: Number(row.area) || 0,
    orientation: row.facing || '待补充',
    decoration: row.decoration || '待补充',
    layout: row.layout || '待补充',
    rent: row.price == null ? null : Number(row.price),
    propertyFee: row.fee == null ? null : Number(row.fee),
    photos: Array.isArray(row.images) ? row.images : [],
    photosLoaded: true,
    status: 'online',
    usage: row.category || '写字楼',
    contact: row.contact_name || '招商顾问',
    phone: row.contact_phone || '',
    address: row.address || '',
    desc: row.description || '',
    tag: row.tag || '',
    views: Number(row.views) || 0,
    lat: Number(row.latitude) || 0,
    lng: Number(row.longitude) || 0,
    createdAt: row.created_at || new Date().toISOString(),
    updatedAt: row.updated_at || row.created_at || new Date().toISOString()
  });
  async function refreshListings() {
    try {
      const response = await fetch(`${url}/rest/v1/public_listings?select=*&order=created_at.desc`, {
        headers: { apikey: key, Authorization: `Bearer ${key}` }, cache: 'no-store'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const rows = await response.json();
      Api.db.listings = rows.map(mapRow);
      // Only coordinates explicitly entered by the operator are shown as markers.
      const liveNames = new Set(Api.db.listings.map(item => item.parkName));
      Api.db.parks = PARKS.filter(park => liveNames.has(park.name));
      for (const row of rows) {
        if (!row.park || Api.db.parks.some(park => park.name === row.park)) continue;
        if (!row.latitude || !row.longitude) continue;
        const projected = projectToMap(Number(row.latitude), Number(row.longitude));
        Api.db.parks.push({ name: row.park, addr: row.address || '', lat: Number(row.latitude), lon: Number(row.longitude), x: projected.x, y: projected.y, precise: true });
      }
      if (State.deepPending) {
        const item = findListing(State.deepPending);
        State.deepPending = null;
        if (item) {
          State.params.id = item.id;
          setView('detail', false);
        } else render();
      } else render();
    } catch (error) {
      console.error('读取已发布房源失败', error);
      Api.db.listings = [];
      render();
      notice('房源暂时加载失败，请稍后刷新页面。');
    }
  }
  window.refreshSiteListings = refreshListings;
  refreshListings();
})();
