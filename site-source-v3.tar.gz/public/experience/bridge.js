/* Public read adapter for the existing Songshanhu Supabase project.
   This file intentionally carries no service-role credential and never writes listings. */
(function () {
  const config = window.__SITE_BACKEND__ || {};
  const url = String(config.url || '').replace(/\/$/, '');
  const key = String(config.key || '');
  const notice = text => {
    const slot = document.querySelector('#view-home');
    if (slot) slot.insertAdjacentHTML('afterbegin', `<div class="port-notice">${text}</div>`);
  };
  if (!url || !key) {
    State.listingsLoading = false;
    State.listingsError = true;
    Api.db.listings = [];
    render();
    notice('网站数据服务尚未连接，房源功能暂不可用。');
    return;
  }
  const mapRow = row => ({
    id: row.id,
    parkName: row.park || '园区待补充',
    building: row.unit || row.title || '房源',
    floor: row.floor || '楼层待补充',
    area: Number(row.area) || 0,
    orientation: row.facing || '待补充',
    decoration: row.decoration || '待补充',
    layout: row.layout || '待补充',
    rent: row.price == null ? null : Number(row.price),
    propertyFee: row.fee == null ? null : Number(row.fee),
    photos: Array.isArray(row.images) ? row.images : [],
    photosLoaded: true,
    videos: Array.isArray(row.videos) ? row.videos : [],
    status: 'online',
    usage: row.category || '写字楼',
    contact: row.contact_name || '招商顾问',
    phone: row.contact_phone || '',
    address: row.address || '',
    desc: row.description || '',
    tag: row.tag || '',
    views: Number(row.views) || 0,
    lat: Number(row.latitude) || 0,
    lng: Number(row.longitude) || 0,
    createdAt: row.created_at || new Date().toISOString(),
    updatedAt: row.updated_at || row.created_at || new Date().toISOString()
  });
  async function refreshListings() {
    try {
      const response = await fetch(`${url}/rest/v1/public_listings?select=*&order=created_at.desc`, {
        headers: { apikey: key, Authorization: `Bearer ${key}` }, cache: 'no-store'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const rows = await response.json();
      State.listingsLoading = false;
      State.listingsError = false;
      Api.db.listings = rows.map(mapRow);
      const parks = new Map();
      for (const item of Api.db.listings) {
        if (!item.parkName || item.parkName === '园区待补充') continue;
        const existing = parks.get(item.parkName);
        if (!existing || (!existing.lat && item.lat && item.lng)) {
          parks.set(item.parkName, {name:item.parkName, addr:item.address || '', lat:item.lat || 0, lon:item.lng || 0, x:50, y:50, precise:!!(item.lat && item.lng)});
        }
      }
      Api.db.parks = Array.from(parks.values());
      if (State.deepPending) {
        const item = findListing(State.deepPending);
        State.deepPending = null;
        if (item) {
          State.params.id = item.id;
          setView('detail', false);
        } else render();
      } else render();
    } catch (error) {
      State.listingsLoading = false;
      State.listingsError = true;
      console.error('读取已发布房源失败', error);
      Api.db.listings = [];
      render();
      notice('房源暂时加载失败，请稍后刷新页面。');
    }
  }
  window.refreshSiteListings = refreshListings;
  refreshListings();
})();
