/* The JS API Key is public. securityJsCode must stay in the proxy's secrets. */
(function () {
  let loading = null, instance = null, generation = 0;
  let previousCenter = null, previousZoom = 13;
  const config = () => (window.__SITE_BACKEND__ || {}).amap || {};
  const hasPosition = item => Number.isFinite(Number(item.lat)) && Number.isFinite(Number(item.lng))
    && Number(item.lat) > 0 && Number(item.lat) <= 90 && Number(item.lng) > 0 && Number(item.lng) <= 180;

  function load() {
    if (window.AMap) return Promise.resolve(window.AMap);
    if (loading) return loading;
    const c = config();
    if (!c.key || !/^https:\/\//.test(c.serviceHost || '') || !c.serviceHost.endsWith('/_AMapService')) {
      return Promise.reject(new Error('地图服务尚未完成配置，房源列表仍可正常使用。'));
    }
    window._AMapSecurityConfig = { serviceHost: c.serviceHost };
    loading = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      let settled = false;
      const finish = error => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (error) { script.remove(); loading = null; reject(error); }
        else resolve(window.AMap);
      };
      const timer = setTimeout(() => finish(new Error('高德地图加载超时，请检查网络后重试。')), 20000);
      script.src = 'https://webapi.amap.com/maps?v=2.0&key=' + encodeURIComponent(c.key);
      script.onload = () => finish(window.AMap ? null : new Error('高德地图加载失败，请稍后重试。'));
      script.onerror = () => finish(new Error('无法连接高德地图，请检查网络后重试。'));
      document.head.appendChild(script);
    });
    return loading;
  }

  function destroy() {
    generation++;
    if (!instance) return;
    try {
      const center = instance.getCenter();
      previousCenter = [center.lng, center.lat];
      previousZoom = instance.getZoom();
      instance.destroy();
    } catch (_) { /* A removed container must not interrupt navigation. */ }
    instance = null;
  }

  async function mount(host, items, onSelect, detail) {
    if (!host) return;
    destroy();
    const ticket = generation;
    const status = document.createElement('div');
    status.className = 'amap-status';
    status.setAttribute('role', 'status');
    status.textContent = '正在加载高德地图…';
    host.replaceChildren(status);
    try {
      const A = await load();
      if (ticket !== generation || !host.isConnected) return;
      const positioned = items.filter(hasPosition);
      const canvas = document.createElement('div');
      canvas.className = 'amap-canvas';
      canvas.setAttribute('aria-label', detail ? '房源位置地图' : '地图找房，可拖动和缩放');
      host.replaceChildren(canvas, status);
      instance = new A.Map(canvas, {
        viewMode: '2D', zoom: detail ? 16 : previousZoom,
        center: detail && positioned[0] ? [Number(positioned[0].lng), Number(positioned[0].lat)] : previousCenter || [113.8884, 22.9165],
        scrollWheel: !detail, keyboardEnable: true
      });
      const activeMap = instance;
      activeMap.on('complete', () => { if (ticket === generation) status.remove(); });
      const slowTimer = setTimeout(() => {
        if (ticket === generation && status.isConnected) {
          status.textContent = '地图响应较慢，请检查网络或服务配置；房源列表仍可浏览。';
        }
      }, 15000);
      activeMap.on('complete', () => clearTimeout(slowTimer));
      const markers = positioned.map(item => {
        const label = document.createElement('button');
        label.type = 'button';
        label.className = 'amap-listing-marker';
        label.textContent = item.rent == null ? '面议' : item.rent + '元/㎡';
        label.setAttribute('aria-label', '查看 ' + item.parkName + ' ' + item.building);
        label.onclick = event => { event.stopPropagation(); if (onSelect) onSelect(item.id); };
        const marker = new A.Marker({
          position: [Number(item.lng), Number(item.lat)], content: label, anchor: 'bottom-center'
        });
        return marker;
      });
      activeMap.add(markers);
      if (!detail && !previousCenter && markers.length) activeMap.setFitView(markers, false, [60, 40, 60, 40], 16);
      A.plugin(['AMap.Scale', 'AMap.ToolBar'], () => {
        if (ticket !== generation) return;
        activeMap.addControl(new A.Scale());
        activeMap.addControl(new A.ToolBar({ position: 'RB' }));
      });
    } catch (error) {
      if (ticket !== generation || !host.isConnected) return;
      status.textContent = error.message || '地图暂时无法加载。';
      const retry = document.createElement('button');
      retry.type = 'button'; retry.className = 'result-reset'; retry.textContent = '重试地图';
      retry.onclick = () => mount(host, items, onSelect, detail);
      status.append(document.createElement('br'), retry);
    }
  }
  window.SiteMap = { mount, destroy, hasPosition, configured: () => !!(config().key && config().serviceHost) };
})();
