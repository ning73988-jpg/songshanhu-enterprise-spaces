# 松山湖产业招商网站

网站：https://ning73988-jpg.github.io/songshanhu-enterprise-spaces/

## 当前版本

- 电脑端使用宽屏导航、搜索和房源网格；手机端使用小程序风格与底部导航。同一套真实房源数据，不包含模拟手机时间、电量或设备边框。
- 房源读取 Supabase 已发布公开视图；园区、地址、招商联系人和电话由发布方决定填写。内部编号、底价和跟进备注保持后台权限控制。
- 支持关键词、园区、业态、租金、面积等筛选，详情相册展示全部照片，并展示已上传视频。支持分享链接与海报生成。
- 管理后台 `/admin/` 使用已授权 Supabase 账号，支持照片/视频上传、草稿、发布和咨询列表。
- 智能找房采用预算、面积、装修等条件解析；尚未连接外部大模型。访客资料、企业资料与需求保存在当前浏览器，未提供跨设备访客登录。
- 地图按用户要求暂缓接入，当前仅显示明确的调整说明，不使用静态图片作为地图。

## 发布与数据

线上工作流从仓库根目录 `site-source-v3.tar.gz` 解包完整源码，然后构建 GitHub Pages。不要只修改外层页面而忽略源码包。当前源码和线上仓库历史不同，不要强制推送覆盖线上历史。

`NEXT_PUBLIC_SUPABASE_URL` 和 `NEXT_PUBLIC_SUPABASE_ANON_KEY` 由 GitHub Actions Secrets 提供，不在源码中保存管理凭据。

已有 Supabase 项目已经执行 `supabase/port_workbuddy.sql`，支持公开园区、地址、联系电话及至少一张房源照片的发布规则。新项目参见 `supabase/README.md`。

## 开发

Node.js 22，执行 `npm ci`、`npm run dev`。配置上述公开环境变量后构建；不要使用 service_role 凭据作为前端配置。
